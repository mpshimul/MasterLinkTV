plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.parcelize)
    alias(libs.plugins.chaquopy.python)
    alias(libs.plugins.google.services)
    alias(libs.plugins.firebase.crashlytics)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.shimulfp.bdixlivetv"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shimulfp.bdixlivetv"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk {
            abiFilters.addAll(listOf("armeabi-v7a", "arm64-v8a"))
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes.addAll(setOf(
                "kotlin/coroutines/coroutines.kotlin_builtins",
                "META-INF/*",
                "META-INF/INDEX.LIST",
                "META-INF/DEPENDENCIES",
                "/META-INF/{AL2.0,LGPL2.1}",
                "**/*.kotlin_builtins"
            ))
            merges.add("META-INF/native-image/**")
        }
        jniLibs {
            pickFirsts.addAll(listOf(
                "**/libc++_shared.so",
                "**/libvlc.so",
                "**/libvlcjni.so"
            ))
        }
    }

    lint {
        abortOnError = false
        warningsAsErrors = false
    }
}

chaquopy {
    defaultConfig {
        version = "3.11"

        pip {
            install("requests")
            install("beautifulsoup4")
            install("pyjwt")
        }
    }
}

dependencies {
    // ========== CORE ANDROID ==========
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.process)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.startup.runtime)

    // ========== COMPOSE BOM ==========
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.animation)
    implementation(libs.androidx.compose.material3)
    androidTestImplementation(platform(libs.androidx.compose.bom))

    // ========== COMPOSE LIBRARIES ==========
    implementation(libs.bundles.compose)
    implementation(libs.androidx.compose.material3.explicit)
    implementation(libs.androidx.compose.foundation.explicit)
    implementation(libs.androidx.compose.animation.explicit)
    implementation(libs.androidx.compose.runtime.explicit)

    // ========== TV ==========
    implementation(libs.androidx.tv.foundation)
    implementation(libs.androidx.tv.material)
    implementation(libs.androidx.leanback)
    implementation(libs.androidx.leanback.preference)

    // ========== MEDIA3 ==========
    implementation(libs.bundles.media3)

    // ========== VLC ==========
    implementation(libs.vlc.all)

    // ========== NETWORKING ==========
    implementation(libs.okhttp)
    implementation(libs.coil.compose)
    implementation(libs.coil.gif)
    implementation(libs.cronet.embedded)

    // ========== FIREBASE ==========
    implementation(platform(libs.firebase.bom))
    implementation(libs.bundles.firebase)

    // ========== UTILITIES ==========
    implementation(libs.gson)
    implementation(libs.androidx.security.crypto)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.localbroadcastmanager)

    // ========== COROUTINES ==========
    implementation(libs.bundles.coroutines)

    // ========== TESTING ==========
    testImplementation(libs.bundles.test)
    androidTestImplementation(libs.bundles.androidTest)
    debugImplementation(libs.compose.ui.tooling)
    debugImplementation(libs.compose.ui.test.manifest)
}
