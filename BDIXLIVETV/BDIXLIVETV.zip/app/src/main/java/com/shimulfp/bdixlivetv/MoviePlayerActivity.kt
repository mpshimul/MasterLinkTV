package com.shimulfp.bdixlivetv

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.util.Log
import android.util.Rational
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.shimulfp.bdixlivetv.data.MovieRepository
import com.shimulfp.bdixlivetv.models.StreamUrl
import kotlinx.coroutines.launch
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.concurrent.TimeUnit
import kotlin.math.abs

@UnstableApi
class MoviePlayerActivity : ComponentActivity() {

    private lateinit var playerManager: PlayerManager

    private lateinit var exoPlayerView: PlayerView
    private lateinit var vlcVideoLayout: VLCVideoLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var titleText: TextView
    private lateinit var qualityText: TextView
    private lateinit var timeText: TextView
    private lateinit var durationText: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var controlsContainer: View
    private lateinit var serverButton: Button
    private lateinit var audioButton: Button
    private lateinit var backButton: ImageButton
    private lateinit var playPauseButton: ImageButton
    private lateinit var rewindButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var bufferingText: TextView
    private lateinit var codecInfoText: TextView
    private lateinit var pipButton: ImageButton
    private lateinit var playerModeText: TextView  // Hidden, used internally only
    private lateinit var vlcSwitchButton: Button  // Hidden, auto-switched by codecs
    private lateinit var exoSwitchButton: Button  // Hidden, not shown
    private lateinit var seekTestButton: Button // Hidden, not shown
    private lateinit var speedButton: ImageButton  // NEW: Speed control
    private lateinit var subtitleButton: ImageButton  // NEW: Subtitle control

    // Gesture controls
    private lateinit var gestureOverlay: View
    private lateinit var brightnessSideIndicator: RelativeLayout
    private lateinit var volumeSideIndicator: RelativeLayout
    private lateinit var brightnessIcon: ImageView
    private lateinit var volumeIcon: ImageView
    private lateinit var brightnessText: TextView
    private lateinit var volumeText: TextView
    private lateinit var brightnessBarFill: View
    private lateinit var volumeBarFill: View

    private lateinit var audioManager: AudioManager
    private var maxVolume = 0
    private var currentBrightness = 0.5f
    private val windowManager = WindowManager.LayoutParams()

    private var movieUrl: String = ""
    private var movieTitle: String = ""
    private var movieId: String = ""
    private var movieQuality: String = ""
    private var streamUrls: List<StreamUrl> = emptyList()
    private var currentServerIndex: Int = 0

    // Series/Episode info
    private var isSeries = false
    private var seriesId: String = ""
    private var seriesTitle: String = ""
    private var seriesPosterUrl: String = ""  // Series poster for episode thumbnails
    private var seasonNumber: Int = 0
    private var episodeNumber: Int = 0
    private var allEpisodes: List<com.shimulfp.bdixlivetv.models.Episode> = emptyList()
    private var currentEpisodeIndex: Int = 0

    // Next Episode Button (for series)
    private lateinit var nextEpisodeButton: ImageButton

    // Episodes Ribbon
    private lateinit var episodesRibbonContainer: FrameLayout
    private lateinit var episodesRibbonContent: LinearLayout
    private lateinit var episodesList: LinearLayout
    private lateinit var episodesRibbonTitle: TextView

    // Ribbon state
    private var ribbonExpanded = false
    private var ribbonPeeking = false
    private val RIBBON_PEEK_HEIGHT_DP = 12
    private val RIBBON_FULL_HEIGHT_DP = 140
    private var lastFocusedEpisodeIndex: Int = -1

    private var controlsVisible = true
    private var resumePosition: Long = 0
    private var isUserSeeking = false
    private var isBuffering = false
    private var isSeekable = true

    // Gesture variables
    private var startX = 0f
    private var startY = 0f
    private var previousX = 0f
    private var previousY = 0f
    private var isBrightnessControl = false
    private var isVolumeControl = false
    private var gestureStartTime = 0L
    private var volumeAccumulator = 0f // Volume accumulator for smooth control
    private var displayBrightness = 0.5f
    private var displayVolume = 0.5f
    private val GESTURE_THRESHOLD = 50f // pixels
    private val GESTURE_THRESHOLD_RATIO = 1.2f // Better ratio detection
    private val SENSITIVITY = 0.003f

    // Controls bounds for touch passthrough
    private var controlsBounds: android.graphics.Rect = android.graphics.Rect()

    private val hideHandler = Handler(Looper.getMainLooper())
    private val updateHandler = Handler(Looper.getMainLooper())

    private var isPipSupported = false
    private var isInPipMode = false
    private var shouldRestorePlayback = true

    private val hideControlsRunnable = Runnable { hideControls() }
    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            updateHandler.postDelayed(this, 1000)
        }
    }

    companion object {
        private const val TAG = "MoviePlayer"
        private const val HIDE_DELAY = 3000L
        private const val SEEK_INCREMENT = 10000L
        private const val PREFS_NAME = "MoviePlayerPrefs"
        private const val PREF_AUTO_PLAY_NEXT = "auto_play_next_episode"
        private const val NEXT_EPISODE_SHOW_TIME_MS = 60000L // Show button 1 minute before end
    }

    private var autoPlayNextEpisode: Boolean = true
    private var hasShownNextEpisodeButton = false
    private var hasAutoPlayedNext = false
    private var currentPlaybackSpeed: Float = 1.0f  // NEW: Speed control
    private val SPEED_OPTIONS = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)  // NEW: Speed options

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setRealFullscreen()
        setContentView(R.layout.activity_movie_player)

        isPipSupported = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        } else false

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        // Load preferences
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        autoPlayNextEpisode = prefs.getBoolean(PREF_AUTO_PLAY_NEXT, true)

        initViews()
        extractIntentData()
        setupListeners()
        initPlayerManager()
        lifecycleScope.launch {
            loadResumePosition()
        }
        loadMovie()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && isPipSupported) {
            buildPipParams()?.let { params ->
                setPictureInPictureParams(params)
            }
        }
    }

    private fun setRealFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Initialize brightness from PlayerActivity
        val layoutParams = window.attributes
        val screenBrightness = layoutParams.screenBrightness

        if (screenBrightness > 0) {
            currentBrightness = screenBrightness
        } else {
            currentBrightness = getBrightness()
        }
    }

    // ===== BRIGHTNESS & VOLUME FUNCTIONS (From PlayerActivity) =====

    private fun isTouchInControls(x: Float, y: Float): Boolean {
        return controlsBounds.contains(x.toInt(), y.toInt())
    }

    private fun setBrightness(brightness: Float) {
        val layoutParams = window.attributes
        layoutParams.screenBrightness = brightness.coerceIn(0.01f, 1f)
        window.attributes = layoutParams
        currentBrightness = layoutParams.screenBrightness
    }

    private fun getBrightness(): Float {
        val brightness = window.attributes.screenBrightness
        return if (brightness < 0) {
            try {
                Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
            } catch (e: Exception) {
                0.5f
            }
        } else {
            brightness
        }
    }

    private fun initViews() {
        exoPlayerView = findViewById(R.id.movie_player_view)
        vlcVideoLayout = findViewById(R.id.movie_vlc_view)
        progressBar = findViewById(R.id.movie_progress_bar)
        errorText = findViewById(R.id.movie_error_text)
        titleText = findViewById(R.id.movie_title_text)
        qualityText = findViewById(R.id.movie_quality_text)
        timeText = findViewById(R.id.movie_time_text)
        durationText = findViewById(R.id.movie_duration_text)
        seekBar = findViewById(R.id.movie_seek_bar)
        controlsContainer = findViewById(R.id.movie_controls_container)
        serverButton = findViewById(R.id.movie_server_button)
        audioButton = findViewById(R.id.movie_audio_button)
        backButton = findViewById(R.id.movie_back_button)
        playPauseButton = findViewById(R.id.movie_play_pause_button)
        rewindButton = findViewById(R.id.movie_rewind_button)
        forwardButton = findViewById(R.id.movie_forward_button)
        bufferingText = findViewById(R.id.movie_buffering_text)
        codecInfoText = findViewById(R.id.movie_codec_info)
        pipButton = findViewById(R.id.movie_pip_button)
        playerModeText = findViewById(R.id.movie_player_mode_text)
        vlcSwitchButton = findViewById(R.id.movie_vlc_switch_button)
        exoSwitchButton = findViewById(R.id.movie_exo_switch_button)
        seekTestButton = findViewById(R.id.movie_seek_test_button)
        speedButton = findViewById(R.id.movie_speed_button)
        subtitleButton = findViewById(R.id.movie_subtitle_button)

        // Episodes Ribbon
        episodesRibbonContainer = findViewById(R.id.episodes_ribbon_container)
        episodesRibbonContent = findViewById(R.id.episodes_ribbon_content)
        episodesList = findViewById(R.id.episodes_list)
        episodesRibbonTitle = findViewById(R.id.episodes_ribbon_title)

        // Next Episode button (center controls)
        nextEpisodeButton = findViewById(R.id.next_episode_button)

        // Gesture controls
        gestureOverlay = findViewById(R.id.gesture_overlay)
        brightnessSideIndicator = findViewById(R.id.brightness_side_indicator)
        volumeSideIndicator = findViewById(R.id.volume_side_indicator)
        brightnessIcon = findViewById(R.id.brightness_side_icon)
        volumeIcon = findViewById(R.id.volume_side_icon)
        brightnessText = findViewById(R.id.brightness_side_text)
        volumeText = findViewById(R.id.volume_side_text)
        brightnessBarFill = findViewById(R.id.brightness_bar_fill)
        volumeBarFill = findViewById(R.id.volume_bar_fill)

        codecInfoText.visibility = View.GONE
        bufferingText.visibility = View.GONE
        exoSwitchButton.visibility = View.GONE
        vlcSwitchButton.visibility = View.GONE // Hide VLC/EXO switch buttons
        seekTestButton.visibility = View.GONE // Hide Test Seek button
        playerModeText.visibility = View.GONE // Hide player mode text from UI
        brightnessSideIndicator.visibility = View.GONE
        volumeSideIndicator.visibility = View.GONE

        // Show/hide Next Episode button only for series
        nextEpisodeButton.visibility = if (isSeries) View.VISIBLE else View.GONE

        if (!isPipSupported) {
            pipButton.visibility = View.GONE
        }

        // Make buttons clickable
        playPauseButton.isFocusable = true
        playPauseButton.isClickable = true
        playPauseButton.requestFocus()

        // Update controls bounds for gesture detection
        controlsContainer.viewTreeObserver.addOnGlobalLayoutListener(
            object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    controlsContainer.getGlobalVisibleRect(controlsBounds)
                    controlsContainer.viewTreeObserver.removeOnGlobalLayoutListener(this)
                }
            }
        )

        // Initialize UI with actual values
        updateBrightnessUI()
        updateVolumeUI()
    }

    private fun extractIntentData() {
        movieId = intent.getStringExtra("MOVIE_ID") ?: ""
        movieTitle = intent.getStringExtra("MOVIE_TITLE") ?: "Movie"
        movieUrl = intent.getStringExtra("MOVIE_URL") ?: ""
        movieQuality = intent.getStringExtra("MOVIE_QUALITY") ?: "HD"

        // Series/Episode info
        isSeries = intent.getBooleanExtra("IS_SERIES", false)
        seriesId = intent.getStringExtra("SERIES_ID") ?: ""
        seriesTitle = intent.getStringExtra("SERIES_TITLE") ?: ""
        seriesPosterUrl = intent.getStringExtra("SERIES_POSTER") ?: ""  // Get series poster URL
        seasonNumber = intent.getIntExtra("SEASON_NUMBER", 0)
        episodeNumber = intent.getIntExtra("EPISODE_NUMBER", 0)

        Log.d(TAG, "📺 Series Info - isSeries: $isSeries, seriesTitle: $seriesTitle, episodeNumber: $episodeNumber")

        // Parse all episodes from JSON string
        val episodesJson = intent.getStringExtra("ALL_EPISODES")
        if (!episodesJson.isNullOrEmpty() && episodesJson != "null") {
            try {
                val gson = com.google.gson.Gson()
                val listType = object : com.google.gson.reflect.TypeToken<List<com.shimulfp.bdixlivetv.models.Episode>>() {}.type
                allEpisodes = gson.fromJson(episodesJson, listType) ?: emptyList()

                // Find current episode index
                currentEpisodeIndex = allEpisodes.indexOfFirst { it.episodeNumber == episodeNumber }
                if (currentEpisodeIndex < 0) currentEpisodeIndex = 0

                Log.d(TAG, "📋 Episodes loaded: ${allEpisodes.size}, Current index: $currentEpisodeIndex, Auto-play next: $autoPlayNextEpisode")

                // Update title for series episodes
                if (isSeries) {
                    val currentEpisode = allEpisodes.getOrNull(currentEpisodeIndex)
                    if (currentEpisode != null) {
                        titleText.text = "${seriesTitle} - ${currentEpisode.getFormattedName()}"
                        if (currentEpisode.title.isNotEmpty()) {
                            qualityText.text = currentEpisode.title
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error parsing episodes: ${e.message}")
            }
        } else {
            Log.w(TAG, "⚠️ No episodes data found - episodesJson: $episodesJson")
        }

        @Suppress("DEPRECATION")
        streamUrls = intent.getParcelableArrayListExtra("STREAM_URLS") ?: emptyList()

        titleText.text = movieTitle
        qualityText.text = movieQuality

        if (streamUrls.isNotEmpty()) {
            currentServerIndex = streamUrls.indexOfFirst { it.url == movieUrl }.takeIf { it >= 0 } ?: 0
            serverButton.text = "Server ${currentServerIndex + 1}/${streamUrls.size}"
            serverButton.visibility = if (streamUrls.size > 1) View.VISIBLE else View.GONE
        } else {
            serverButton.visibility = View.GONE
        }
    }

    private fun setupListeners() {
        backButton.setOnClickListener {
            lifecycleScope.launch {
                saveCurrentProgress()
            }
            finish()
        }

        playPauseButton.setOnClickListener {
            togglePlayPause()
            // Don't hide controls immediately after button press
            showControls()
            scheduleHideControls()
        }

        rewindButton.setOnClickListener {
            safeSeekBy(-SEEK_INCREMENT)
            showControls()  // Show controls when clicking UI button
            scheduleHideControls()
        }

        forwardButton.setOnClickListener {
            safeSeekBy(SEEK_INCREMENT)
            showControls()  // Show controls when clicking UI button
            scheduleHideControls()
        }

        nextEpisodeButton.setOnClickListener {
            playEpisodeAtIndex(currentEpisodeIndex + 1)
            showControls()
            scheduleHideControls()
        }

        serverButton.setOnClickListener {
            showServerDialog()
            showControls()
            scheduleHideControls()
        }

        audioButton.setOnClickListener {
            showAudioTrackDialog()
            showControls()
            scheduleHideControls()
        }

        pipButton.setOnClickListener {
            if (isPipSupported) {
                enterPictureInPicture()
            }
            showControls()
            scheduleHideControls()
        }

        vlcSwitchButton.setOnClickListener {
            showVLCSwitchDialog()
            showControls()
            scheduleHideControls()
        }

        exoSwitchButton.setOnClickListener {
            showExoSwitchDialog()
            showControls()
            scheduleHideControls()
        }

        seekTestButton.setOnClickListener {
            testSeekFunctionality()
            showControls()
            scheduleHideControls()
        }

        speedButton.setOnClickListener {
            showSpeedDialog()
            showControls()
            scheduleHideControls()
        }

        subtitleButton.setOnClickListener {
            showSubtitleDialog()
            showControls()
            scheduleHideControls()
        }

        // Single tap on video toggles controls
        exoPlayerView.setOnClickListener {
            if (!isBrightnessControl && !isVolumeControl) {
                toggleControls()
            }
        }

        vlcVideoLayout.setOnClickListener {
            if (!isBrightnessControl && !isVolumeControl) {
                toggleControls()
            }
        }

        // Setup gesture overlay - initially disabled since controls are visible
        gestureOverlay.isClickable = false
        gestureOverlay.isFocusable = false
        gestureOverlay.setOnTouchListener(null)

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val duration = playerManager.getDuration()
                    if (duration > 0) {
                        val position = (duration * progress) / 100
                        timeText.text = formatTime(position)
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = true
                cancelHideControls()
                showControls()
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = false
                val duration = playerManager.getDuration()
                if (duration > 0 && isSeekable) {
                    val position = (duration * (seekBar?.progress ?: 0)) / 100
                    playerManager.seekTo(position)
                }
                scheduleHideControls()
            }
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleGesture(event: MotionEvent): Boolean {
        val screenWidth = resources.displayMetrics.widthPixels

        // If controls are visible and touch is within controls area, pass through
        if (controlsVisible && isTouchInControls(event.x, event.y)) {
            return false // Pass to controls so buttons work
        }

        // Handle all other touches (gestures when hidden, toggle anywhere)
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                previousX = event.x
                previousY = event.y
                gestureStartTime = System.currentTimeMillis()
                isBrightnessControl = false
                isVolumeControl = false
                volumeAccumulator = 0f
                cancelHideControls()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - startX
                val dy = event.y - startY
                val dragAmountX = event.x - previousX
                val dragAmountY = event.y - previousY

                // Update previous position
                previousX = event.x
                previousY = event.y

                // Determine gesture direction
                if (!isBrightnessControl && !isVolumeControl) {
                    if (abs(dy) > GESTURE_THRESHOLD && abs(dy) > abs(dx) * GESTURE_THRESHOLD_RATIO) {
                        // LEFT SIDE = BRIGHTNESS
                        if (startX < screenWidth * 0.35f) {
                            isBrightnessControl = true
                            showBrightnessSideIndicator()
                            displayBrightness = currentBrightness
                        } else if (startX > screenWidth * 0.65f) {
                            // RIGHT SIDE = VOLUME
                            isVolumeControl = true
                            showVolumeSideIndicator()
                            val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                            displayVolume = currentVol.toFloat() / maxVolume.toFloat()
                        }
                    }
                }

                // Handle brightness adjustment (LEFT SIDE!)
                if (isBrightnessControl) {
                    val delta = -dragAmountY * SENSITIVITY
                    adjustBrightness(delta)
                }

                // Handle volume adjustment (RIGHT SIDE!)
                if (isVolumeControl) {
                    val delta = -dragAmountY * SENSITIVITY
                    adjustVolume(delta)
                }

                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isBrightnessControl || isVolumeControl) {
                    hideSideIndicators()
                    scheduleHideControls()
                    isBrightnessControl = false
                    isVolumeControl = false
                    volumeAccumulator = 0f
                    return true
                } else {
                    // Check for single tap
                    val elapsedTime = System.currentTimeMillis() - gestureStartTime
                    val movedDistance = abs(event.x - startX) + abs(event.y - startY)
                    val dy = event.y - startY

                    if (elapsedTime < 300 && movedDistance < 20) {
                        // Single tap - toggle controls
                        toggleControls()
                    } else if (isSeries && ribbonPeeking) {
                        // Check for swipe gestures on ribbon
                        if (dy < -100 && !ribbonExpanded) {
                            // Swipe up on peeking ribbon -> Expand
                            expandEpisodesRibbon()
                        } else if (dy > 100 && ribbonExpanded) {
                            // Swipe down on expanded ribbon -> Collapse
                            collapseEpisodesRibbon()
                        }
                    }
                }
                return true
            }
        }
        return true
    }

    private fun adjustBrightness(delta: Float) {
        val newBrightness = (displayBrightness + delta).coerceIn(0.01f, 1.0f)
        displayBrightness = newBrightness

        // Update actual brightness
        try {
            val layoutParams = window.attributes
            layoutParams.screenBrightness = newBrightness
            window.attributes = layoutParams
            currentBrightness = newBrightness

            updateBrightnessUI()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to adjust brightness", e)
        }
    }

    private fun adjustVolume(delta: Float) {
        volumeAccumulator += delta
        displayVolume = (displayVolume + delta).coerceIn(0f, 1f)

        val stepSize = 1f / maxVolume.toFloat()
        val stepsToChange = (volumeAccumulator / stepSize).toInt()

        if (stepsToChange != 0) {
            val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            val newVolume = (currentVolume + stepsToChange).coerceIn(0, maxVolume)

            if (newVolume != currentVolume) {
                audioManager.setStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    newVolume,
                    0 // Don't show system UI
                )
                updateVolumeUI()
            }
            volumeAccumulator = 0f
        }
    }

    private fun showBrightnessSideIndicator() {
        brightnessSideIndicator.visibility = View.VISIBLE
        updateBrightnessUI()
    }

    private fun showVolumeSideIndicator() {
        volumeSideIndicator.visibility = View.VISIBLE
        updateVolumeUI()
    }

    private fun updateBrightnessUI() {
        val percentage = (currentBrightness * 100).toInt()
        brightnessText.text = "$percentage%"

        // Update icon
        val iconRes = when {
            percentage > 66 -> R.drawable.ic_brightness_high
            percentage > 33 -> R.drawable.ic_brightness_medium
            else -> R.drawable.ic_brightness_low
        }
        brightnessIcon.setImageResource(iconRes)

        // Update bar - assuming parent is 100dp
        val barHeight = (percentage / 100f) * resources.getDimension(R.dimen.gesture_bar_max_height)
        val layoutParams = brightnessBarFill.layoutParams
        layoutParams.height = barHeight.toInt()
        brightnessBarFill.layoutParams = layoutParams
    }

    private fun updateVolumeUI() {
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val percentage = (currentVolume * 100 / maxVolume)
        volumeText.text = "$percentage%"

        // Update icon
        val iconRes = when {
            currentVolume == 0 -> R.drawable.ic_volume_off
            currentVolume < maxVolume / 3 -> R.drawable.ic_volume_down
            else -> R.drawable.ic_volume_up
        }
        volumeIcon.setImageResource(iconRes)

        // Update bar
        val barHeight = (percentage / 100f) * resources.getDimension(R.dimen.gesture_bar_max_height)
        val layoutParams = volumeBarFill.layoutParams
        layoutParams.height = barHeight.toInt()
        volumeBarFill.layoutParams = layoutParams
    }

    private fun hideSideIndicators() {
        brightnessSideIndicator.visibility = View.GONE
        volumeSideIndicator.visibility = View.GONE
    }

    // ===== PLAYER MANAGER INITIALIZATION =====

    private fun initPlayerManager() {
        playerManager = PlayerManager(
            context = this,
            exoPlayerView = exoPlayerView,
            vlcVideoLayout = vlcVideoLayout,
            listener = object : PlayerManager.PlayerListener {
                override fun onPlayerReady() {
                    progressBar.visibility = View.GONE
                    errorText.visibility = View.GONE
                    updateDuration()
                    updatePlayPauseButton()

                    val playerType = playerManager.getPlayerType()
                    playerModeText.text = when (playerType) {
                        PlayerManager.PlayerType.EXOPLAYER -> "ExoPlayer"
                        PlayerManager.PlayerType.VLC -> "VLC"
                    }
                    playerModeText.setTextColor(
                        if (playerType == PlayerManager.PlayerType.VLC)
                            0xFFFF9800.toInt() else 0xFF4CAF50.toInt()
                    )

                    if (playerType == PlayerManager.PlayerType.VLC) {
                        vlcSwitchButton.visibility = View.GONE
                        exoSwitchButton.visibility = View.VISIBLE
                    } else {
                        vlcSwitchButton.visibility = View.VISIBLE
                        exoSwitchButton.visibility = View.GONE
                    }

                    if (resumePosition > 0 && playerManager.isSeekable() && shouldRestorePlayback) {
                        playerManager.seekTo(resumePosition)
                        resumePosition = 0
                        Toast.makeText(
                            this@MoviePlayerActivity,
                            "Resuming playback",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    showCodecInfo()
                    scheduleHideControls()
                }

                override fun onPlayerError(error: String, isFatal: Boolean) {
                    if (isFatal) {
                        progressBar.visibility = View.GONE
                        errorText.visibility = View.VISIBLE
                        errorText.text = error

                        if (streamUrls.size > 1) {
                            errorText.append("\n\nTrying next server...")
                            Handler(Looper.getMainLooper()).postDelayed({
                                tryNextServer()
                            }, 2000)
                        }
                    } else {
                        Toast.makeText(this@MoviePlayerActivity, error, Toast.LENGTH_LONG).show()

                        val playerType = playerManager.getPlayerType()
                        if (playerType == PlayerManager.PlayerType.VLC) {
                            vlcSwitchButton.visibility = View.GONE
                            exoSwitchButton.visibility = View.VISIBLE
                        } else {
                            vlcSwitchButton.visibility = View.VISIBLE
                            exoSwitchButton.visibility = View.GONE
                        }
                    }
                }

                override fun onBuffering(isBuffering: Boolean, percentage: Int) {
                    this@MoviePlayerActivity.isBuffering = isBuffering
                    progressBar.visibility = if (isBuffering) View.VISIBLE else View.GONE
                    bufferingText.visibility = if (isBuffering) View.VISIBLE else View.GONE

                    if (isBuffering && percentage > 0) {
                        bufferingText.text = "Buffering... $percentage%"
                    } else if (isBuffering) {
                        bufferingText.text = "Buffering..."
                    }

                    if (!isBuffering) {
                        scheduleHideControls()
                    }
                }

                override fun onPlaybackStateChanged(isPlaying: Boolean) {
                    updatePlayPauseButton()
                    if (isPlaying) {
                        scheduleHideControls()
                    } else {
                        cancelHideControls()
                        showControls()
                    }
                }

                override fun onDurationChanged(duration: Long) {
                    updateDuration()
                }

                override fun onPositionChanged(position: Long) {
                    // Handled in updateProgress()
                }

                override fun onSeekableChanged(isSeekable: Boolean) {
                    this@MoviePlayerActivity.isSeekable = isSeekable
                    seekBar.isEnabled = isSeekable

                    val duration = playerManager.getDuration()
                    val playerType = playerManager.getPlayerType()

                    Log.d(TAG, "Seekable changed: $isSeekable, Duration: $duration, Player: $playerType")

                    if (!isSeekable && duration > 0) {
                        Log.w(TAG, "⚠️ Video has duration but marked as unseekable!")

                        if (playerType == PlayerManager.PlayerType.EXOPLAYER) {
                            Handler(Looper.getMainLooper()).postDelayed({
                                showNonSeekableDialog()
                            }, 2000)
                        }
                    } else if (!isSeekable && duration <= 0) {
                        Toast.makeText(
                            this@MoviePlayerActivity,
                            "Live stream - seeking unavailable",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onTracksChanged() {
                    val audioTracks = playerManager.getAvailableAudioTracks()
                    audioButton.visibility = if (audioTracks.size > 1) View.VISIBLE else View.GONE
                    if (audioTracks.size > 1) {
                        audioButton.text = "Audio (${audioTracks.size})"
                    }
                }

                override fun onProblematicCodecDetected(codecInfo: String) {
                    Log.w(TAG, "Problematic codec detected: $codecInfo")

                    Handler(Looper.getMainLooper()).postDelayed({
                        if (playerManager.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
                            showAC3DetectedDialog(codecInfo)
                        }
                    }, 1000)
                }
            }
        )
    }

    // ===== VIDEO LOADING =====

    private fun loadMovie(url: String = movieUrl) {
        // Reset next episode flags for new content
        hasShownNextEpisodeButton = false
        hasAutoPlayedNext = false

        if (url.isEmpty()) {
            errorText.visibility = View.VISIBLE
            errorText.text = "No video URL provided"
            return
        }

        errorText.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        shouldRestorePlayback = true

        val urlLower = url.lowercase()
        val forceVLC = (urlLower.contains(".mkv") &&
                (urlLower.contains("ac3") ||
                        urlLower.contains("dts") ||
                        urlLower.contains("dd5.1") ||
                        urlLower.contains("dd+") ||
                        urlLower.contains("eac3"))) ||
                urlLower.contains(".avi") ||
                        urlLower.contains(".hevc") ||
                        urlLower.contains("h265") ||
                        urlLower.contains("x265")

        if (forceVLC) {
            Log.d(TAG, "⚠️ Auto-forcing VLC for: $url")
            Toast.makeText(
                this,
                "Using VLC player for better format support",
                Toast.LENGTH_LONG
            ).show()
        }

        playerManager.load(url, autoPlay = true, forceVLC = forceVLC)
    }

    private fun showCodecInfo() {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
            playerManager.getExoPlayer()?.let { p ->
                val videoFormat = p.videoFormat
                val audioFormat = p.audioFormat

                if (videoFormat != null) {
                    val codecInfo = buildString {
                        append("Video: ${videoFormat.sampleMimeType ?: "Unknown"}")
                        append(" ${videoFormat.width}x${videoFormat.height}")
                        if (videoFormat.frameRate > 0) append(" ${videoFormat.frameRate.toInt()}fps")

                        if (audioFormat != null) {
                            append("\nAudio: ${audioFormat.sampleMimeType ?: "Unknown"}")
                            if (audioFormat.channelCount > 0) append(" ${audioFormat.channelCount}ch")
                            if (audioFormat.sampleRate > 0) append(" ${audioFormat.sampleRate}Hz")
                        }
                    }

                    codecInfoText.text = codecInfo
                    codecInfoText.visibility = View.VISIBLE

                    Handler(Looper.getMainLooper()).postDelayed({
                        codecInfoText.visibility = View.GONE
                    }, 5000)
                }
            }
        } else {
            codecInfoText.text = "VLC Player - All codecs supported"
            codecInfoText.visibility = View.VISIBLE
            Handler(Looper.getMainLooper()).postDelayed({
                codecInfoText.visibility = View.GONE
            }, 3000)
        }
    }

    // ===== DIALOGS =====

    private fun showAudioTrackDialog() {
        val audioTracks = playerManager.getAvailableAudioTracks()

        if (audioTracks.isEmpty()) {
            Toast.makeText(this, "No audio tracks available", Toast.LENGTH_SHORT).show()
            return
        }

        if (audioTracks.size == 1) {
            Toast.makeText(this, "Only one audio track available", Toast.LENGTH_SHORT).show()
            return
        }

        val trackLabels = audioTracks.map { track ->
            buildString {
                append(track.label)
                if (track.language.isNotEmpty() && track.language != "und" && track.language != "Unknown") {
                    append(" [${track.language}]")
                }
                if (track.channels > 0 && track.channels != 2) {
                    append(" - ${track.channels}ch")
                }
                if (track.isSelected) {
                    append(" ✓")
                }
            }
        }.toTypedArray()

        val selectedIndex = audioTracks.indexOfFirst { it.isSelected }.takeIf { it >= 0 } ?: 0

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Select Audio Track")
            .setSingleChoiceItems(trackLabels, selectedIndex) { dialog, which ->
                if (which != selectedIndex && which < audioTracks.size) {
                    val success = playerManager.setAudioTrack(audioTracks[which].trackIndex)
                    if (success) {
                        Toast.makeText(this, "Audio track switched", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Failed to switch audio track", Toast.LENGTH_SHORT).show()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun showServerDialog() {
        if (streamUrls.isEmpty() || streamUrls.size == 1) {
            Toast.makeText(this, "No alternative servers available", Toast.LENGTH_SHORT).show()
            return
        }

        val serverNames = streamUrls.mapIndexed { index, url ->
            buildString {
                append("Server ${index + 1}")
                if (url.server.isNotEmpty()) append(" - ${url.server}")
                if (url.quality.isNotEmpty()) append(" (${url.quality})")
                if (index == currentServerIndex) append(" ✓")
            }
        }.toTypedArray()

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Select Server")
            .setSingleChoiceItems(serverNames, currentServerIndex) { dialog, which ->
                if (which != currentServerIndex && which < streamUrls.size) {
                    switchToServer(which)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun switchToServer(serverIndex: Int) {
        if (serverIndex < 0 || serverIndex >= streamUrls.size) return

        val currentPos = playerManager.getCurrentPosition()
        currentServerIndex = serverIndex

        serverButton.text = "Server ${serverIndex + 1}/${streamUrls.size}"
        qualityText.text = streamUrls[serverIndex].quality

        movieUrl = streamUrls[serverIndex].url
        loadMovie(movieUrl)

        resumePosition = currentPos
        shouldRestorePlayback = true
    }

    private fun tryNextServer() {
        if (streamUrls.size <= 1) return

        val nextIndex = (currentServerIndex + 1) % streamUrls.size
        Toast.makeText(this, "Trying server ${nextIndex + 1}...", Toast.LENGTH_SHORT).show()
        switchToServer(nextIndex)
    }

    private fun testSeekFunctionality() {
        val duration = playerManager.getDuration()
        val currentPosition = playerManager.getCurrentPosition()
        val isSeekable = playerManager.isSeekable()
        val playerType = playerManager.getPlayerType()

        val message = """
            Seek Test Results:
            Player: $playerType
            Duration: ${formatTime(duration)}
            Current: ${formatTime(currentPosition)}
            Seekable: $isSeekable
            Live Stream: ${duration <= 0}
        """.trimIndent()

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Seek Test")
            .setMessage(message)
            .setPositiveButton("Test Seek Forward") { _, _ ->
                playerManager.seekBy(30000) // 30 seconds forward
            }
            .setNegativeButton("Test Seek Back") { _, _ ->
                playerManager.seekBy(-15000) // 15 seconds back
            }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun showAC3DetectedDialog(codecInfo: String) {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.VLC) {
            return
        }

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("⚠️ AC3/DTS Audio Detected")
            .setMessage("$codecInfo\n\n" +
                    "This audio format may not play correctly with ExoPlayer.\n\n" +
                    "Switch to VLC player for full compatibility?")
            .setPositiveButton("Switch to VLC") { _, _ ->
                val currentPos = playerManager.getCurrentPosition()
                playerManager.switchToVLC(movieUrl, currentPos, autoSwitch = false)
            }
            .setNegativeButton("Continue with ExoPlayer") { _, _ ->
                Toast.makeText(
                    this,
                    "Audio may not play. Use 'Use VLC' button if needed.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .setCancelable(true)
            .show()
    }

    private fun showNonSeekableDialog() {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.VLC) {
            return
        }

        if (!isSeekable) {
            android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("⚠️ Seeking Not Available")
                .setMessage("This video doesn't support seeking with ExoPlayer.\n\n" +
                        "VLC player may provide better seeking support.\n\n" +
                        "Switch to VLC?")
                .setPositiveButton("Switch to VLC") { _, _ ->
                    val currentPos = playerManager.getCurrentPosition()
                    playerManager.switchToVLC(movieUrl, currentPos, autoSwitch = false)
                }
                .setNegativeButton("Continue", null)
                .setCancelable(true)
                .show()
        }
    }

    private fun showVLCSwitchDialog() {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.VLC) {
            Toast.makeText(this, "Already using VLC player", Toast.LENGTH_SHORT).show()
            return
        }

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Switch to VLC Player")
            .setMessage("VLC player supports:\n\n" +
                    "✓ AC3/DTS audio\n" +
                    "✓ Better seeking\n" +
                    "✓ All video formats\n" +
                    "✓ Better network handling\n\n" +
                    "Current position will be preserved.")
            .setPositiveButton("Switch to VLC") { _, _ ->
                val currentPos = playerManager.getCurrentPosition()
                playerManager.switchToVLC(movieUrl, currentPos, autoSwitch = false)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExoSwitchDialog() {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
            Toast.makeText(this, "Already using ExoPlayer", Toast.LENGTH_SHORT).show()
            return
        }

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Switch to ExoPlayer")
            .setMessage("ExoPlayer supports:\n\n" +
                    "✓ Better battery efficiency\n" +
                    "✓ Smoother UI integration\n" +
                    "✓ Native Android features\n" +
                    "✓ Better HLS/DASH streaming\n" +
                    "Current position will be preserved.")
            .setPositiveButton("Switch to ExoPlayer") { _, _ ->
                val currentPos = playerManager.getCurrentPosition()
                playerManager.switchToExoPlayer(movieUrl, currentPos)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ===== SPEED CONTROL =====

    private fun showSpeedDialog() {
        val speedLabels = SPEED_OPTIONS.map { "${(it * 100).toInt()}%" }.toTypedArray()
        val currentIndex = SPEED_OPTIONS.indexOfFirst { it == currentPlaybackSpeed }.takeIf { it >= 0 } ?: 2

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Playback Speed")
            .setSingleChoiceItems(speedLabels, currentIndex) { dialog, which ->
                if (which != currentIndex && which < SPEED_OPTIONS.size) {
                    setPlaybackSpeed(SPEED_OPTIONS[which])
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setPlaybackSpeed(speed: Float) {
        currentPlaybackSpeed = speed

        when (playerManager.getPlayerType()) {
            PlayerManager.PlayerType.EXOPLAYER -> {
                playerManager.getExoPlayer()?.setPlaybackSpeed(speed)
            }
            PlayerManager.PlayerType.VLC -> {
                playerManager.getVLCPlayer()?.setRate(speed)
            }
        }

        Toast.makeText(this, "Speed: ${(speed * 100).toInt()}%", Toast.LENGTH_SHORT).show()
    }

    // ===== SUBTITLE CONTROL =====

    private fun showSubtitleDialog() {
        // TODO: Implement subtitle track selection dialog
        // Currently simplified to avoid compilation issues
        Toast.makeText(this, "Subtitle feature coming soon", Toast.LENGTH_SHORT).show()
    }

    private fun turnOnSubtitles(trackIndex: Int) {
        // TODO: Implement subtitle track selection
        // Currently simplified to avoid compilation issues
        Toast.makeText(this, "Subtitle feature coming soon", Toast.LENGTH_SHORT).show()
    }

    private fun turnOffSubtitles() {
        // TODO: Implement subtitle track disabling
        // Currently simplified to avoid compilation issues
        Toast.makeText(this, "Subtitle feature coming soon", Toast.LENGTH_SHORT).show()
    }

    private fun togglePlayPause() {
        if (playerManager.isPlaying()) {
            playerManager.pause()
        } else {
            playerManager.play()
        }
        updatePlayPauseButton()
    }

    private fun updatePlayPauseButton() {
        playPauseButton.setImageResource(
            if (playerManager.isPlaying()) android.R.drawable.ic_media_pause
            else android.R.drawable.ic_media_play
        )
    }

    private fun safeSeekBy(incrementMs: Long) {
        if (!playerManager.isSeekable()) {
            Toast.makeText(this, "Seeking not supported", Toast.LENGTH_SHORT).show()
            return
        }

        playerManager.seekBy(incrementMs)
        // Don't show controls - let caller decide
        // This allows left/right DPAD to seek without opening controls
    }

    private fun toggleControls() {
        if (isInPipMode) return

        if (controlsVisible) {
            hideControls()
        } else {
            showControls()
            scheduleHideControls()
        }
    }

    private fun showControls() {
        if (isInPipMode) return
        controlsContainer.visibility = View.VISIBLE
        controlsVisible = true
        cancelHideControls()
        // Disable gesture overlay so TV remote can access controls
        gestureOverlay.isClickable = false
        gestureOverlay.isFocusable = false
        gestureOverlay.setOnTouchListener(null)

        // Show episodes ribbon ONLY if playing series
        if (isSeries) {
            showEpisodesRibbon()
        }
    }

    private fun hideControls() {
        if (playerManager.isPlaying() && !isBuffering && !isInPipMode) {
            controlsContainer.visibility = View.GONE
            controlsVisible = false
            // Enable gesture overlay for volume/brightness gestures when controls are hidden
            gestureOverlay.isClickable = true
            gestureOverlay.isFocusable = true
            gestureOverlay.setOnTouchListener { v, event -> handleGesture(event) }

            // Hide episodes ribbon
            hideEpisodesRibbon()
        }
    }

    private fun scheduleHideControls() {
        if (isInPipMode) return
        cancelHideControls()
        if (playerManager.isPlaying() && !isBuffering) {
            hideHandler.postDelayed(hideControlsRunnable, HIDE_DELAY)
        }
    }

    private fun cancelHideControls() {
        hideHandler.removeCallbacks(hideControlsRunnable)
    }

    // ===== EPISODES RIBBON FUNCTIONS =====

    private fun showEpisodesRibbon() {
        if (!isSeries || allEpisodes.isEmpty()) return

        episodesRibbonContainer.visibility = View.VISIBLE
        if (!ribbonExpanded) {
            // Show in peek mode
            episodesRibbonContainer.translationY = (RIBBON_FULL_HEIGHT_DP - RIBBON_PEEK_HEIGHT_DP).toFloat() * resources.displayMetrics.density
        } else {
            episodesRibbonContainer.translationY = 0f
        }
        ribbonPeeking = true

        // Disable gesture overlay when ribbon is visible
        gestureOverlay.isClickable = false
        gestureOverlay.isFocusable = false
        gestureOverlay.setOnTouchListener(null)

        // Populate episodes if not already populated
        if (episodesList.childCount == 0) {
            populateEpisodesRibbon()
        }
    }

    private fun hideEpisodesRibbon() {
        episodesRibbonContainer.visibility = View.GONE
        episodesRibbonContainer.translationY = 0f
        ribbonPeeking = false
        ribbonExpanded = false
    }

    private fun expandEpisodesRibbon() {
        if (!isSeries || allEpisodes.isEmpty()) return

        episodesRibbonContainer.visibility = View.VISIBLE
        episodesRibbonContainer.animate()
            .translationY(0f)
            .setDuration(250)
            .start()
        ribbonExpanded = true
        ribbonPeeking = true

        // Focus first episode if not already focused
        if (episodesList.childCount > 0) {
            val firstEpisode = episodesList.getChildAt(0)
            firstEpisode.requestFocus()
            updateEpisodeHighlight(currentEpisodeIndex)
        }
    }

    private fun collapseEpisodesRibbon() {
        if (!ribbonPeeking) return

        episodesRibbonContainer.animate()
            .translationY((RIBBON_FULL_HEIGHT_DP - RIBBON_PEEK_HEIGHT_DP).toFloat() * resources.displayMetrics.density)
            .setDuration(200)
            .start()
        ribbonExpanded = false

        // Return focus to controls
        if (controlsVisible) {
            playPauseButton.requestFocus()
        }
    }

    private fun populateEpisodesRibbon() {
        episodesList.removeAllViews()

        allEpisodes.forEachIndexed { index, episode ->
            val episodeView = createEpisodeView(episode, index)
            episodesList.addView(episodeView)
        }

        updateEpisodeHighlight(currentEpisodeIndex)
    }

    private fun createEpisodeView(episode: com.shimulfp.bdixlivetv.models.Episode, index: Int): View {
        val view = layoutInflater.inflate(R.layout.episode_ribbon_item, episodesList, false)

        val thumbnail = view.findViewById<ImageView>(R.id.episode_thumbnail)
        val episodeNumber = view.findViewById<TextView>(R.id.episode_number)
        val title = view.findViewById<TextView>(R.id.episode_title)
        val watchedIndicator = view.findViewById<ImageView>(R.id.episode_watched)
        val currentIndicator = view.findViewById<View>(R.id.current_episode_indicator)

        // Set episode data
        episodeNumber.text = String.format("E%02d", episode.episodeNumber)
        title.text = if (episode.title.isNotEmpty()) episode.title else "Episode ${episode.episodeNumber}"

        // Load thumbnail - use series poster for all episodes
        if (seriesPosterUrl.isNotEmpty()) {
            // Load series poster as thumbnail for all episodes
            // You would use Coil or Glide here to load image
            // For now, using a placeholder color
            thumbnail.setBackgroundColor(0xFF333333.toInt())
        } else if (episode.poster.isNotEmpty()) {
            // Fall back to episode poster if series poster is not available
            thumbnail.setBackgroundColor(0xFF333333.toInt())
        } else {
            // No poster available, use default background
            thumbnail.setBackgroundColor(0xFF222222.toInt())
        }

        // Mark current episode
        if (index == currentEpisodeIndex) {
            currentIndicator.setBackgroundColor(0x809C27B0.toInt())
            currentIndicator.visibility = View.VISIBLE
        }

        // Mark watched episodes (based on watch progress)
        if (episode.watchProgress > 0.9f) {
            watchedIndicator.visibility = View.VISIBLE
        }

        // Set click listener
        view.setOnClickListener {
            playEpisodeAtIndex(index)
        }

        view.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                lastFocusedEpisodeIndex = index
                // Don't hide controls while navigating through episodes
                cancelHideControls()
            }
        }

        return view
    }

    private fun updateEpisodeHighlight(index: Int) {
        for (i in 0 until episodesList.childCount) {
            val episodeView = episodesList.getChildAt(i)
            val currentIndicator = episodeView.findViewById<View>(R.id.current_episode_indicator)

            if (i == index) {
                currentIndicator.setBackgroundColor(0x809C27B0.toInt())
                currentIndicator.visibility = View.VISIBLE
            } else {
                currentIndicator.visibility = View.GONE
            }
        }

        // Scroll to current episode
        if (index >= 0 && index < episodesList.childCount) {
            val episodeView = episodesList.getChildAt(index)
            // Scroll to make episode visible
            val scrollX = episodeView.left - (episodesList.width / 2)
            val scrollY = 0
            episodesList.scrollTo(scrollX, scrollY)
        }
    }

    private fun playEpisodeAtIndex(index: Int) {
        if (index < 0 || index >= allEpisodes.size) return

        val episode = allEpisodes[index]

        // Save current episode progress
        lifecycleScope.launch {
            saveCurrentProgress()
        }

        // Update current episode info
        currentEpisodeIndex = index
        episodeNumber = episode.episodeNumber

        // Get stream URL
        val url = episode.getBestStreamUrl()
        if (url != null) {
            // Load episode
            movieUrl = url
            movieTitle = "${seriesTitle} - ${episode.getFormattedName()}"
            playerManager.load(url)

            // Update UI
            titleText.text = movieTitle
            qualityText.text = episode.title.ifEmpty { episode.quality }

            // Update episode highlight
            updateEpisodeHighlight(index)

            Log.d(TAG, "▶️ Playing episode: ${episode.getFormattedName()} (Index: $index)")
        }
    }

    private fun updateProgress() {
        if (!isUserSeeking) {
            val duration = playerManager.getDuration()
            if (duration > 0) {
                val position = playerManager.getCurrentPosition()
                val progress = ((position * 100) / duration).toInt()

                seekBar.progress = progress
                timeText.text = formatTime(position)

                val bufferedPosition = playerManager.getBufferedPosition()
                val bufferedProgress = ((bufferedPosition * 100) / duration).toInt()
                seekBar.secondaryProgress = bufferedProgress

                // Auto-play next episode when current one ends
                if (isSeries && allEpisodes.isNotEmpty() && autoPlayNextEpisode && !hasAutoPlayedNext) {
                    val timeRemaining = duration - position

                    // Auto-play when less than 1 second remaining
                    if (timeRemaining <= 1000 && timeRemaining >= 0 && currentEpisodeIndex + 1 < allEpisodes.size) {
                        Log.d(TAG, "🎬 Auto-playing next episode")
                        hasAutoPlayedNext = true
                        playEpisodeAtIndex(currentEpisodeIndex + 1)
                    }
                }
            }
        }
    }

    private fun updateDuration() {
        val duration = playerManager.getDuration()
        if (duration > 0) {
            durationText.text = formatTime(duration)
            seekBar.max = 100
        }
    }

    private fun formatTime(ms: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(ms)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    private fun enterPictureInPicture() {
        if (!isPipSupported) {
            Log.w(TAG, "PiP not supported on this device")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = buildPipParams()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to enter PiP mode", e)
            }
        }
    }

    private fun buildPipParams(): PictureInPictureParams {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            throw IllegalStateException("PiP not supported below API 26")
        }

        val builder = PictureInPictureParams.Builder()

        // Set aspect ratio for flexibility (allows resizing)
        builder.setAspectRatio(Rational(16, 9))

        // Android 12+ (API 31): Enable seamless resize and auto-enter
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setSeamlessResizeEnabled(true)
            builder.setAutoEnterEnabled(true)
        }

        return builder.build()
    }

    private suspend fun loadResumePosition() {
        movieId.takeIf { it.isNotEmpty() }?.let { id ->
            try {
                val prefs = getSharedPreferences("watch_progress", MODE_PRIVATE)
                val savedPosition = prefs.getLong(id, 0)
                if (savedPosition > 0) {
                    resumePosition = savedPosition
                    Log.d(TAG, "📍 Resuming from position: ${formatTime(resumePosition)}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load resume position", e)
            }
        }
    }

    private suspend fun saveCurrentProgress() {
        movieId.takeIf { it.isNotEmpty() }?.let { id ->
            try {
                val prefs = getSharedPreferences("watch_progress", MODE_PRIVATE)
                prefs.edit().putLong(id, playerManager.getCurrentPosition()).apply()
                Log.d(TAG, "💾 Saved progress for: $id at ${formatTime(playerManager.getCurrentPosition())}")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save progress", e)
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isInPipMode) {
            return super.onKeyDown(keyCode, event)
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                // Only seek when controls are hidden
                if (!controlsVisible) {
                    val increment = if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) SEEK_INCREMENT else -SEEK_INCREMENT
                    safeSeekBy(increment)
                } else {
                    // When controls are visible, navigate normally (move focus between buttons)
                    super.onKeyDown(keyCode, event)
                }
                true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                // Handle ribbon expansion/collapse when series is playing
                if (isSeries && allEpisodes.isNotEmpty()) {
                    if (keyCode == KeyEvent.KEYCODE_DPAD_UP && !ribbonExpanded) {
                        expandEpisodesRibbon()
                    } else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN && ribbonPeeking) {
                        collapseEpisodesRibbon()
                    } else {
                        // Default navigation when ribbon is fully visible/collapsed
                        super.onKeyDown(keyCode, event)
                    }
                    true
                } else {
                    // For non-series content, normal navigation
                    super.onKeyDown(keyCode, event)
                }
                true
            }
            KeyEvent.KEYCODE_BACK -> {
                finish()
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                togglePlayPause()
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (!playerManager.isPlaying()) {
                    togglePlayPause()
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                safeSeekBy(SEEK_INCREMENT)
                true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                safeSeekBy(-SEEK_INCREMENT)
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onStart() {
        super.onStart()
        updateHandler.postDelayed(updateProgressRunnable, 1000)
    }

    override fun onStop() {
        super.onStop()
        updateHandler.removeCallbacks(updateProgressRunnable)
        cancelHideControls()
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleScope.launch {
            saveCurrentProgress()
        }

        hideHandler.removeCallbacksAndMessages(null)
        updateHandler.removeCallbacksAndMessages(null)

        playerManager.release()
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipMode = isInPictureInPictureMode

        Log.d(TAG, "PiP mode changed: $isInPictureInPictureMode")

        if (isInPictureInPictureMode) {
            hideControls()
        }
    }
}
