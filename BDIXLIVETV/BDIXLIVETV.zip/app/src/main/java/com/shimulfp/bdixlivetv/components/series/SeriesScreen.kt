package com.shimulfp.bdixlivetv.components.series

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.models.Series
import com.shimulfp.bdixlivetv.models.SeriesCategory

/**
 * Series Screen - Main screen showing all series in a grid
 */
@Composable
fun SeriesScreen(
    series: List<Series>,
    onSeriesClick: (Series) -> Unit,
    onBack: () -> Unit,
    selectedCategory: SeriesCategory = SeriesCategory.ALL,
    onCategoryChange: (SeriesCategory) -> Unit = {},
    searchQuery: String = "",
    onSearchChange: (String) -> Unit = {},
    isLoading: Boolean = false
) {
    val filteredSeries = remember(selectedCategory, searchQuery, series) {
        series.filter { s ->
            val matchesCategory = selectedCategory == SeriesCategory.ALL || s.category == selectedCategory
            val matchesSearch = searchQuery.isEmpty() ||
                    s.title.contains(searchQuery, ignoreCase = true) ||
                    s.originalTitle.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            SeriesHeader(
                selectedCategory = selectedCategory,
                onCategoryChange = onCategoryChange,
                searchQuery = searchQuery,
                onSearchChange = onSearchChange,
                onBack = onBack,
                seriesCount = series.size
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Content
            if (isLoading) {
                LoadingState()
            } else if (filteredSeries.isEmpty()) {
                EmptyState(searchQuery = searchQuery)
            } else {
                SeriesGrid(
                    series = filteredSeries,
                    onSeriesClick = onSeriesClick
                )
            }
        }
    }
}

@Composable
fun SeriesHeader(
    selectedCategory: SeriesCategory,
    onCategoryChange: (SeriesCategory) -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onBack: () -> Unit,
    seriesCount: Int
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Text(
                    "Series",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )

                if (seriesCount > 0) {
                    Text(
                        " ($seriesCount)",
                        color = Color.Gray,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("Search series...", color = Color.Gray) },
            leadingIcon = {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = Color.Gray
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Color.Gray,
                focusedBorderColor = Color(0xFF6200EE),
                cursorColor = Color(0xFF6200EE),
                unfocusedTextColor = Color.White,
                focusedTextColor = Color.White,
                unfocusedPlaceholderColor = Color.Gray,
                focusedPlaceholderColor = Color.Gray
            ),
            shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter (Horizontal Scroll)
        CategoryFilter(
            selectedCategory = selectedCategory,
            onCategoryChange = onCategoryChange
        )
    }
}

@Composable
fun CategoryFilter(
    selectedCategory: SeriesCategory,
    onCategoryChange: (SeriesCategory) -> Unit
) {
    val categories = SeriesCategory.entries

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        categories.forEach { category ->
            FilterChip(
                selected = selectedCategory == category,
                onClick = { onCategoryChange(category) },
                label = {
                    Text(
                        category.displayName,
                        fontSize = 14.sp,
                        fontWeight = if (selectedCategory == category) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = Color(0xFF1A1A1A),
                    labelColor = Color.Gray,
                    selectedContainerColor = Color(0xFF6200EE),
                    selectedLabelColor = Color.White
                ),
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}

@Composable
fun SeriesGrid(
    series: List<Series>,
    onSeriesClick: (Series) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 160.dp),
        contentPadding = PaddingValues(4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(series) { seriesItem ->
            SeriesCard(
                series = seriesItem,
                onClick = { onSeriesClick(seriesItem) }
            )
        }
    }
}

@Composable
fun SeriesCard(
    series: Series,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        label = "scale"
    )

    Card(
        onClick = {
            isPressed = true
            onClick()
            isPressed = false
        },
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(2f / 3f)
            .scale(scale)
            .border(
                width = 2.dp,
                color = Color(0xFF333333),
                shape = RoundedCornerShape(8.dp)
            ),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Poster
            if (series.poster.isNotEmpty()) {
                AsyncImage(
                    model = series.poster,
                    contentDescription = series.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                // Placeholder
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF6200EE),
                                    Color(0xFF3700B3)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Movie,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            // Gradient Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.8f)
                            )
                        )
                    )
            )

            // Info at bottom
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            ) {
                // Year Badge
                if (series.year.isNotEmpty()) {
                    Surface(
                        color = series.getQualityBadgeColor().let { Color(it) },
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .wrapContentWidth()
                            .padding(bottom = 4.dp)
                    ) {
                        Text(
                            series.year,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Title
                Text(
                    series.title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                // Episode Count
                if (series.totalEpisodes > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Icon(
                            Icons.Filled.PlayCircle,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "${series.totalEpisodes} eps",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Season Count Badge
            if (series.getSeasonCount() > 1) {
                Surface(
                    color = Color(0xFF6200EE),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                ) {
                    Text(
                        "S${series.getSeasonCount()}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun LoadingState() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(
                color = Color(0xFF6200EE),
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "Loading series...",
                color = Color.White,
                fontSize = 18.sp
            )
        }
    }
}

@Composable
fun EmptyState(searchQuery: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Filled.Movie,
                contentDescription = null,
                tint = Color.Gray,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                if (searchQuery.isNotEmpty()) {
                    "No series found for \"$searchQuery\""
                } else {
                    "No series available"
                },
                color = Color.Gray,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                if (searchQuery.isNotEmpty()) {
                    "Try a different search term"
                } else {
                    "Check your server configuration"
                },
                color = Color.Gray,
                fontSize = 14.sp
            )
        }
    }
}
