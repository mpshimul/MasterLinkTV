package com.shimulfp.bdixlivetv.services

import android.content.Context
import android.util.Log
import com.shimulfp.bdixlivetv.FirebaseManager
import com.shimulfp.bdixlivetv.GitHubDataManager
import com.shimulfp.bdixlivetv.data.MovieRepository
import com.shimulfp.bdixlivetv.data.MovieScraper
import kotlinx.coroutines.*
import kotlinx.coroutines.Dispatchers.IO

object MovieSyncService {
    private const val TAG = "MovieSyncService"

    /**
     * Start periodic sync (simplified)
     */
    fun startPeriodicSync(context: Context) {
        CoroutineScope(IO).launch {
            try {
                Log.d(TAG, "🔄 Starting movie sync...")
                syncMovies(context)
            } catch (e: Exception) {
                Log.e(TAG, "Sync error: ${e.message}")
            }
        }
    }

    /**
     * Main sync function
     */
    suspend fun syncMovies(context: Context): SyncResult = withContext(IO) {
        Log.d(TAG, "🚀 === MOVIE SYNC START ===")

        return@withContext try {
            val firebaseManager = FirebaseManager(context)
            val githubToken = firebaseManager.getGitHubToken()

            if (githubToken.isEmpty()) {
                Log.w(TAG, "⚠️ No GitHub token available")
                return@withContext SyncResult.NoToken
            }

            // Initialize GitHubDataManager
            GitHubDataManager.initialize(githubToken)

            // Strategy: Try GitHub first, fallback to scraping
            val result = tryGitHubFirst(context, githubToken)

            Log.d(TAG, "✅ Sync completed: ${result.getMessage()}")
            result

        } catch (e: Exception) {
            Log.e(TAG, "❌ Movie sync error: ${e.message}", e)
            SyncResult.Error(e.message ?: "Unknown error")
        }
    }

    /**
     * Try GitHub first, fallback to scraping
     */
    private suspend fun tryGitHubFirst(
        context: Context,
        githubToken: String
    ): SyncResult = withContext(IO) {
        return@withContext try {
            // Check if GitHub data is fresh (<6 hours)
            val isGitHubFresh = GitHubDataManager.isMovieDataFresh()

            if (isGitHubFresh) {
                Log.d(TAG, "📥 GitHub data is fresh, downloading...")
                val movies = GitHubDataManager.downloadMovies(context)

                if (movies.isNotEmpty()) {
                    // Save to repository cache
                    MovieRepository.getInstance(context).clearCache()
                    saveMoviesToCache(context, movies)

                    Log.d(TAG, "✅ Downloaded ${movies.size} movies from GitHub")
                    return@withContext SyncResult.GitHubDownload(movies.size)
                }
            }

            // If GitHub failed or not fresh, scrape fresh
            Log.d(TAG, "🔄 GitHub not available or stale, scraping fresh...")
            scrapeAndUpload(context, githubToken)

        } catch (e: Exception) {
            Log.e(TAG, "GitHub first strategy failed: ${e.message}")
            // Fallback to scraping
            scrapeAndUpload(context, githubToken)
        }
    }

    /**
     * Scrape fresh movies and upload to GitHub
     */
    private suspend fun scrapeAndUpload(
        context: Context,
        githubToken: String
    ): SyncResult = withContext(IO) {
        return@withContext try {
            Log.d(TAG, "🔄 Scraping fresh movie data...")

            val movies = MovieScraper.scrapeAllMovies(context, maxPerServer = 400)

            if (movies.isEmpty()) {
                Log.e(TAG, "❌ Scraping failed, no movies found")
                return@withContext SyncResult.ScrapingFailed
            }

            Log.d(TAG, "✅ Scraped ${movies.size} movies")

            // Save locally
            MovieRepository.getInstance(context).clearCache()
            saveMoviesToCache(context, movies)

            // Try to upload to GitHub
            return@withContext try {
                Log.d(TAG, "🚀 Uploading to GitHub...")
                val uploaded = GitHubDataManager.uploadMovies(context, movies)

                if (uploaded) {
                    Log.d(TAG, "🎉 Uploaded ${movies.size} movies to GitHub")
                    SyncResult.ScrapedAndUploaded(movies.size)
                } else {
                    Log.w(TAG, "⚠️ Scraped ${movies.size} movies but upload failed")
                    SyncResult.ScrapedOnly(movies.size)
                }
            } catch (e: Exception) {
                Log.w(TAG, "⚠️ GitHub upload failed: ${e.message}")
                SyncResult.ScrapedOnly(movies.size)
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ Scrape and upload error: ${e.message}")
            SyncResult.Error(e.message ?: "Unknown error")
        }
    }

    /**
     * Save movies to cache
     */
    private fun saveMoviesToCache(context: Context, movies: List<com.shimulfp.bdixlivetv.models.Movie>) {
        try {
            val file = java.io.File(context.filesDir, "movies_cache.json")
            file.writeText(com.google.gson.Gson().toJson(movies))
            file.setLastModified(System.currentTimeMillis())
            Log.d(TAG, "💾 Saved ${movies.size} movies to cache")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving movies to cache: ${e.message}")
        }
    }

    // ============ DATA CLASSES ============

    sealed class SyncResult {
        object NoToken : SyncResult()
        data class GitHubDownload(val count: Int) : SyncResult()
        data class ScrapedAndUploaded(val count: Int) : SyncResult()
        data class ScrapedOnly(val count: Int) : SyncResult()
        object ScrapingFailed : SyncResult()

        // Alternative fix: Use @JvmField to avoid generating getter
        data class Error(@JvmField val message: String) : SyncResult()

        fun getMessage(): String {
            return when (this) {
                is GitHubDownload -> "Downloaded $count movies from GitHub"
                is ScrapedAndUploaded -> "Scraped and uploaded $count movies"
                is ScrapedOnly -> "Scraped $count movies"
                is ScrapingFailed -> "Scraping failed"
                is Error -> "Error: ${this.message}"
                NoToken -> "No GitHub token"
            }
        }
    }
}