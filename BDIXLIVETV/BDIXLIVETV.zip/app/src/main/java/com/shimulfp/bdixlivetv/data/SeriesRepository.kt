package com.shimulfp.bdixlivetv.data

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.shimulfp.bdixlivetv.FirebaseManager
import com.shimulfp.bdixlivetv.GitHubDataManager
import com.shimulfp.bdixlivetv.models.Series
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

/**
 * Repository for managing series data with GitHub sync support
 * Similar to MovieRepository but for series
 */
class SeriesRepository(private val context: Context) {

    private val gson = Gson()
    private val cacheFile = File(context.filesDir, "series_cache.json")
    private val favoritesFile = File(context.filesDir, "series_favorites.json")
    private val syncStatusFile = File(context.filesDir, "series_sync_status.json")
    private val stopFlagFile = File(context.filesDir, "stop_series_scraping.flag")

    // Synchronization primitives to prevent race conditions
    private val loadMutex = Mutex()
    private val refreshMutex = Mutex()

    // Cache state tracking
    @Volatile
    private var isCurrentlyLoading = false
    @Volatile
    private var lastLoadTime = 0L
    @Volatile
    private var cachedSeries: List<Series>? = null

    @Volatile
    private var isScrapingInProgress = false

    companion object {
        private const val TAG = "SeriesRepository"
        private const val FRESHNESS_THRESHOLD_MINUTES = 120L // 2 hours
        private const val MAX_RETRY_ATTEMPTS = 3
        private const val MIN_LOAD_INTERVAL_MS = 3000L // 3 seconds between loads
        private const val BACKGROUND_REFRESH_DELAY_MS = 30 * 60 * 1000L // 30 minutes delay

        @Volatile
        private var instance: SeriesRepository? = null
        private val instanceMutex = Mutex()

        suspend fun getInstance(context: Context): SeriesRepository {
            return instance ?: instanceMutex.withLock {
                instance ?: SeriesRepository(context.applicationContext).also {
                    Log.d(TAG, "✅ Created new SeriesRepository instance")
                    instance = it
                }
            }
        }
    }

    // ============ TOKEN MANAGEMENT ============

    /**
     * Get GitHub token from multiple possible sources
     */
    private fun getGitHubToken(): String {
        return try {
            // 1. Try GitHubDataManager directly
            val fromGitHubManager = GitHubDataManager.getToken()
            if (fromGitHubManager.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from GitHubDataManager")
                return fromGitHubManager
            }

            // 2. Try Firebase Remote Config
            val firebaseManager = FirebaseManager(context)
            val fromFirebase = firebaseManager.getGitHubToken()
            if (fromFirebase.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from Firebase")
                if (!GitHubDataManager.isInitialized()) {
                    GitHubDataManager.initialize(fromFirebase)
                }
                return fromFirebase
            }

            // 3. Try SharedPreferences
            val fromPrefs = tryGetTokenFromSharedPrefs()
            if (fromPrefs.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from SharedPreferences")
                return fromPrefs
            }

            Log.d(TAG, "⚠️ No GitHub token available from any source")
            ""
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting GitHub token: ${e.message}")
            ""
        }
    }

    /**
     * Try to get token from SharedPreferences
     */
    private fun tryGetTokenFromSharedPrefs(): String {
        return try {
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.getString("github_token", "") ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Save token for future use
     */
    private fun saveTokenLocally(token: String) {
        try {
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("github_token", token).apply()

            val tokenFile = File(context.filesDir, "github_token.txt")
            tokenFile.writeText(token)

            Log.d(TAG, "💾 Saved GitHub token locally")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving token locally: ${e.message}")
        }
    }

    // ============ SCRAPING CONTROL ============

    /**
     * Create stop flag to signal Python scraper to stop
     */
    private fun createStopFlag() {
        try {
            stopFlagFile.writeText("STOP")
            Log.d(TAG, "🛑 Created stop flag for series scraper")
        } catch (e: Exception) {
            Log.e(TAG, "Error creating stop flag: ${e.message}")
        }
    }

    /**
     * Remove stop flag
     */
    private fun removeStopFlag() {
        try {
            if (stopFlagFile.exists()) {
                stopFlagFile.delete()
                Log.d(TAG, "🧹 Removed stop flag")
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    /**
     * Stop all scraping immediately
     */
    private fun stopAllScraping() {
        createStopFlag()
        isScrapingInProgress = false
        Log.d(TAG, "🚨 FORCE STOPPED all series scraping processes")
    }

    // ============ MAIN LOADING FUNCTION ============

    /**
     * Get series with smart GitHub-first loading
     */
    suspend fun getSeriesSmart(): List<Series> = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 SMART SERIES LOADING - GITHUB-FIRST")

        // Clean up any old stop flags
        removeStopFlag()

        // STEP 1: Check if we already have cached series in memory (fastest)
        if (shouldUseCachedSeries()) {
            Log.d(TAG, "⚡ Using cached in-memory series (${cachedSeries?.size ?: 0} items)")
            return@withContext cachedSeries ?: emptyList()
        }

        // STEP 2: Try to load from local GitHub cache file immediately
        val localFile = File(context.filesDir, "series_cache.json")
        if (localFile.exists() && localFile.length() > 50000) { // At least 50KB
            Log.d(TAG, "📥 Found local GitHub cache file (${localFile.length()} bytes)")

            try {
                val content = localFile.readText()
                val series = parseSeriesFromJson(content)

                if (series.isNotEmpty()) {
                    Log.d(TAG, "✅ Loaded ${series.size} series from local GitHub cache")

                    // STOP any ongoing scraping since we have data
                    stopAllScraping()

                    // Update cache state
                    cachedSeries = series
                    lastLoadTime = System.currentTimeMillis()

                    // Save sync status
                    saveSyncStatus("github_cache", series.size)

                    return@withContext series
                } else {
                    Log.w(TAG, "⚠️ Local cache file exists but parsing returned empty")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error loading from local cache: ${e.message}")
            }
        }

        // STEP 3: Get GitHub token from available sources
        val githubToken = getGitHubToken()

        if (githubToken.isNotEmpty()) {
            Log.d(TAG, "🔑 GitHub token available, trying to download...")

            // Save token locally for future use
            saveTokenLocally(githubToken)

            try {
                // Initialize GitHubDataManager if not already
                if (!GitHubDataManager.isInitialized()) {
                    GitHubDataManager.initialize(githubToken)
                }

                val series = GitHubDataManager.downloadSeries(context)

                if (series.isNotEmpty()) {
                    Log.d(TAG, "✅ Downloaded ${series.size} series from GitHub")

                    // STOP any ongoing scraping immediately
                    stopAllScraping()

                    // Update cache state
                    cachedSeries = series
                    lastLoadTime = System.currentTimeMillis()

                    // Save to cache
                    saveToCache(series)
                    saveSyncStatus("github_download", series.size)

                    return@withContext series
                } else {
                    Log.w(TAG, "⚠️ GitHub download returned empty")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub download error: ${e.message}")
            }
        } else {
            Log.d(TAG, "⚠️ No GitHub token available from any source")
        }

        // STEP 4: If GitHub fails, try existing cache file
        val cached = loadFromCache()
        if (cached.isNotEmpty()) {
            Log.d(TAG, "✅ Loaded ${cached.size} series from existing cache")

            // STOP any ongoing scraping
            stopAllScraping()

            cachedSeries = cached
            lastLoadTime = System.currentTimeMillis()
            saveSyncStatus("existing_cache", cached.size)

            return@withContext cached
        }

        // STEP 5: Only scrape as LAST RESORT
        Log.d(TAG, "⚠️ All other sources failed, scraping as last resort...")

        return@withContext loadMutex.withLock {
            // Double-check inside mutex
            if (cachedSeries != null && shouldUseCachedSeries()) {
                stopAllScraping()
                return@withLock cachedSeries ?: emptyList()
            }

            try {
                isCurrentlyLoading = true

                val series = scrapeFreshSeries()
                if (series.isNotEmpty()) {
                    Log.d(TAG, "✅ Scraped ${series.size} series")

                    cachedSeries = series
                    lastLoadTime = System.currentTimeMillis()
                    saveToCache(series)
                    saveSyncStatus("scraped", series.size)

                    // Try to upload to GitHub if we get a token later
                    if (githubToken.isNotEmpty()) {
                        try {
                            GitHubDataManager.initialize(githubToken)
                            GitHubDataManager.uploadSeries(context, series)
                            Log.d(TAG, "📤 Uploaded scraped series to GitHub")
                        } catch (e: Exception) {
                            Log.e(TAG, "⚠️ Failed to upload to GitHub: ${e.message}")
                        }
                    }

                    return@withLock series
                }

                return@withLock emptyList()
            } catch (e: Exception) {
                Log.e(TAG, "❌ Scraping error: ${e.message}")
                return@withLock emptyList()
            } finally {
                isCurrentlyLoading = false
            }
        }
    }

    /**
     * Check if we should use cached series
     */
    private fun shouldUseCachedSeries(): Boolean {
        if (cachedSeries == null) return false

        val timeSinceLastLoad = System.currentTimeMillis() - lastLoadTime
        val isRecent = timeSinceLastLoad < MIN_LOAD_INTERVAL_MS

        return isRecent && cachedSeries!!.isNotEmpty()
    }

    /**
     * Scrape fresh series from BDIX servers
     */
    private suspend fun scrapeFreshSeries(): List<Series> = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "🔄 Scraping fresh series from BDIX servers...")

            // Use the parallel series scraper
            val series = SeriesScraper.scrapeAllSeries(context, maxPerServer = 250)

            Log.d(TAG, "✅ Scraped ${series.size} series")

            series
        } catch (e: Exception) {
            Log.e(TAG, "❌ Series scraping error: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Save series to cache file
     */
    private fun saveToCache(series: List<Series>) {
        try {
            val json = gson.toJson(series)
            cacheFile.writeText(json)
            cacheFile.setLastModified(System.currentTimeMillis())
            Log.d(TAG, "💾 Saved ${series.size} series to cache")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving to cache: ${e.message}")
        }
    }

    /**
     * Load series from cache file
     */
    private fun loadFromCache(): List<Series> {
        return try {
            if (!cacheFile.exists()) {
                return emptyList()
            }

            val content = cacheFile.readText()
            if (content.isEmpty()) {
                return emptyList()
            }

            parseSeriesFromJson(content)
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading from cache: ${e.message}")
            emptyList()
        }
    }

    /**
     * Parse series from JSON string
     */
    private fun parseSeriesFromJson(json: String): List<Series> {
        return try {
            val type = object : TypeToken<List<Series>>() {}.type
            val series = gson.fromJson<List<Series>>(json, type)
            series ?: emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "❌ JSON parsing error: ${e.message}")
            emptyList()
        }
    }

    /**
     * Save sync status
     */
    private fun saveSyncStatus(source: String, count: Int) {
        try {
            val status = mapOf(
                "source" to source,
                "count" to count,
                "timestamp" to System.currentTimeMillis(),
                "datetime" to java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                    .format(java.util.Date())
            )
            val json = gson.toJson(status)
            syncStatusFile.writeText(json)
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving sync status: ${e.message}")
        }
    }

    // ============ FAVORITES ============

    /**
     * Get favorite series
     */
    suspend fun getFavorites(): List<Series> = withContext(Dispatchers.IO) {
        return@withContext try {
            if (!favoritesFile.exists()) {
                return@withContext emptyList()
            }

            val content = favoritesFile.readText()
            val type = object : TypeToken<List<Series>>() {}.type
            val favorites = gson.fromJson<List<Series>>(content, type)
            favorites ?: emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading favorites: ${e.message}")
            emptyList()
        }
    }

    /**
     * Toggle favorite status
     */
    suspend fun toggleFavorite(series: Series): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            var favorites = getFavorites().toMutableList()

            if (favorites.any { it.id == series.id }) {
                favorites.removeAll { it.id == series.id }
                Log.d(TAG, "❌ Removed from favorites: ${series.title}")
                false
            } else {
                favorites.add(series.copy(isFavorite = true))
                Log.d(TAG, "⭐ Added to favorites: ${series.title}")
                true
            }

            // Save updated favorites
            val json = gson.toJson(favorites)
            favoritesFile.writeText(json)

            // Update cached series if exists
            cachedSeries?.let { cached ->
                cachedSeries = cached.map { s ->
                    if (s.id == series.id) s.copy(isFavorite = !s.isFavorite) else s
                }
            }

            // Return new favorite status
            !favorites.any { it.id == series.id && !it.isFavorite }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error toggling favorite: ${e.message}")
            false
        }
    }

    /**
     * Force refresh series from GitHub or scrape fresh
     */
    suspend fun forceRefresh(): List<Series> = withContext(Dispatchers.IO) {
        return@withContext refreshMutex.withLock {
            Log.d(TAG, "🔄 Force refreshing series...")

            // Clear cache
            cachedSeries = null
            lastLoadTime = 0

            // Try GitHub first
            val githubToken = getGitHubToken()
            if (githubToken.isNotEmpty()) {
                try {
                    if (!GitHubDataManager.isInitialized()) {
                        GitHubDataManager.initialize(githubToken)
                    }

                    val series = GitHubDataManager.downloadSeries(context)
                    if (series.isNotEmpty()) {
                        cachedSeries = series
                        lastLoadTime = System.currentTimeMillis()
                        saveToCache(series)
                        saveSyncStatus("force_github", series.size)
                        return@withLock series
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "❌ GitHub refresh failed: ${e.message}")
                }
            }

            // Fallback to scraping
            try {
                val series = scrapeFreshSeries()
                if (series.isNotEmpty()) {
                    cachedSeries = series
                    lastLoadTime = System.currentTimeMillis()
                    saveToCache(series)
                    saveSyncStatus("force_scraped", series.size)

                    // Upload to GitHub
                    if (githubToken.isNotEmpty()) {
                        try {
                            GitHubDataManager.initialize(githubToken)
                            GitHubDataManager.uploadSeries(context, series)
                        } catch (e: Exception) {
                            Log.e(TAG, "⚠️ Failed to upload to GitHub: ${e.message}")
                        }
                    }

                    return@withLock series
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Force refresh failed: ${e.message}")
            }

            // Return cached if available
            cachedSeries ?: emptyList()
        }
    }

    /**
     * Get local cache age in minutes
     */
    fun getLocalCacheAge(): Long {
        return try {
            if (cacheFile.exists()) {
                val ageMinutes = (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000)
                ageMinutes
            } else {
                -1L
            }
        } catch (e: Exception) {
            -1L
        }
    }

    /**
     * Check if currently loading
     */
    fun isLoading(): Boolean = isCurrentlyLoading

    /**
     * Get cached series count
     */
    fun getCachedCount(): Int = cachedSeries?.size ?: 0

    /**
     * Clear cache
     */
    suspend fun clearCache() = withContext(Dispatchers.IO) {
        try {
            cacheFile.delete()
            cachedSeries = null
            lastLoadTime = 0
            Log.d(TAG, "🧹 Cleared series cache")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error clearing cache: ${e.message}")
        }
    }
}
