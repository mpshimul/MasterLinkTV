package com.shimulfp.bdixlivetv

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.view.KeyEvent

class MediaButtonReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Intent.ACTION_MEDIA_BUTTON == intent.action) {
            val event = intent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
            event?.let {
                if (it.action == KeyEvent.ACTION_DOWN) {
                    when (it.keyCode) {
                        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                            // Handle play/pause
                        }
                        KeyEvent.KEYCODE_MEDIA_NEXT -> {
                            // Handle next
                        }
                        KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                            // Handle previous
                        }
                    }
                }
            }
        }
    }
}