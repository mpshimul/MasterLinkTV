package com.shimulfp.bdixlivetv

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Channel(
    val name: String = "",
    val urls: List<String> = emptyList(),
    val logo: String = "",
    val category: String = "General",
    val source: String = "unknown"
) : Parcelable {
    fun isBdixChannel(): Boolean {
        return source.lowercase().let {
            it.contains("basnet") || it.contains("ksb") ||
                    it.contains("redforce") || it.contains("bdix") ||
                    it.contains("fallback")
        }
    }

    fun isAynaChannel(): Boolean {
        return source.lowercase().contains("ayna")
    }
}

// Add a data class for cache metadata
data class ChannelCache(
    val channels: List<Channel>,
    val timestamp: Long,
    val source: String
)
