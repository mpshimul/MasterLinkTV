package com.shimulfp.bdixlivetv.utils

import android.content.Context
import android.util.Log
import com.shimulfp.bdixlivetv.FirebaseManager
import com.shimulfp.bdixlivetv.GitHubDataManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object ChannelSyncHelper {
    private const val TAG = "ChannelSyncHelper"

    /**
     * Sync channels WITHOUT triggering movie scraping
     */
    suspend fun syncChannelsOnly(context: Context): GitHubDataManager.SyncResult = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 SYNC CHANNELS ONLY (no movies)")

        val firebaseManager = FirebaseManager(context)
        val githubToken = firebaseManager.getGitHubToken()

        if (githubToken.isEmpty()) {
            Log.w(TAG, "⚠️ No GitHub token")
            return@withContext GitHubDataManager.SyncResult.NoToken
        }

        // Check if channels already exist locally
        val channelFiles = listOf(
            "all_channels_cache.json",
            "ayna_channels_cache.json",
            "bdix_channels_cache.json"
        )

        val allChannelsExist = channelFiles.all { filename ->
            val file = File(context.filesDir, filename)
            file.exists() && file.length() > 1000
        }

        if (allChannelsExist) {
            Log.d(TAG, "✅ Channels already exist locally, skipping sync")
            return@withContext GitHubDataManager.SyncResult.Downloaded(0)
        }

        // Only sync channels if they don't exist
        return@withContext try {
            GitHubDataManager.initialize(githubToken)
            GitHubDataManager.checkAndSyncData(context)
        } catch (e: Exception) {
            Log.e(TAG, "❌ Channel sync error: ${e.message}")
            GitHubDataManager.SyncResult.Error(e.message ?: "Unknown error")
        }
    }
}