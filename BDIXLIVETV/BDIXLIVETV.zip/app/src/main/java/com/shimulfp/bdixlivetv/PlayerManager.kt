package com.shimulfp.bdixlivetv

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

@UnstableApi
class PlayerManager(
    private val context: Context,
    private val exoPlayerView: PlayerView,
    private val vlcVideoLayout: VLCVideoLayout,
    private val listener: PlayerListener
) {

    enum class PlayerType { EXOPLAYER, VLC }

    interface PlayerListener {
        fun onPlayerReady()
        fun onPlayerError(error: String, isFatal: Boolean)
        fun onBuffering(isBuffering: Boolean, percentage: Int = 0)
        fun onPlaybackStateChanged(isPlaying: Boolean)
        fun onDurationChanged(duration: Long)
        fun onPositionChanged(position: Long)
        fun onSeekableChanged(isSeekable: Boolean)
        fun onTracksChanged()
        fun onProblematicCodecDetected(codecInfo: String)
    }

    data class AudioTrackInfo(
        val trackIndex: Int,
        val language: String,
        val label: String,
        val isSelected: Boolean,
        val channels: Int = 0
    )

    private var currentPlayerType = PlayerType.EXOPLAYER
    private var exoPlayer: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null
    private var libVLC: LibVLC? = null
    private var vlcPlayer: MediaPlayer? = null

    private var currentUrl: String = ""
    private var shouldAutoPlay: Boolean = true
    private var hasInitializedVLC = false
    private var hasCheckedCodecs = false
    private var retryCount = 0
    private var pendingStartPosition: Long = -1
    private var isSeekingInProgress = false

    private val handler = Handler(Looper.getMainLooper())

    companion object {
        private const val TAG = "PlayerManager"
        private const val SEEK_INCREMENT = 10000L
        private const val MAX_RETRY_COUNT = 3

        private val PROBLEMATIC_AUDIO_CODECS = listOf(
            "audio/ac3",
            "audio/eac3",
            "audio/ac-3",
            "audio/eac-3",
            "audio/vnd.dts",
            "audio/vnd.dts.hd",
            "audio/dts",
            "audio/true-hd",
            "audio/truehd"
        )

        private val PROBLEMATIC_VIDEO_CODECS = listOf(
            "video/hevc",
            "video/x-h265",
            "video/h265",
            "video/x-hevc"
        )
    }

    init {
        initExoPlayer()

        try {
            initVLC()
            Log.d(TAG, "✅ VLC pre-initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "❌ VLC failed to initialize at startup", e)
        }
    }

    private fun initExoPlayer() {
        Log.d(TAG, "Initializing ExoPlayer")

        trackSelector = DefaultTrackSelector(context).apply {
            parameters = buildUponParameters()
                .setPreferredAudioLanguage("hin")
                .setMaxVideoSizeSd()
                .build()
        }

        exoPlayer = ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector!!)
            .setSeekBackIncrementMs(SEEK_INCREMENT)
            .setSeekForwardIncrementMs(SEEK_INCREMENT)
            .build()
            .apply {
                exoPlayerView.player = this

                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_BUFFERING -> {
                                listener.onBuffering(true)
                            }
                            Player.STATE_READY -> {
                                listener.onBuffering(false)
                                listener.onPlayerReady()
                                listener.onDurationChanged(duration)

                                val isSeekable = isCurrentMediaItemSeekable
                                val dur = duration
                                val isLive = dur == C.TIME_UNSET

                                Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                                Log.d(TAG, "MEDIA READY:")
                                Log.d(TAG, "  - Duration: ${if (isLive) "LIVE" else "${dur}ms"}")
                                Log.d(TAG, "  - Seekable: $isSeekable")
                                Log.d(TAG, "  - Is Live: $isLive")
                                Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

                                listener.onSeekableChanged(isSeekable)

                                if (!hasCheckedCodecs && currentPlayerType == PlayerType.EXOPLAYER) {
                                    checkForProblematicCodecs()
                                }
                            }
                            Player.STATE_ENDED -> {
                                listener.onPlaybackStateChanged(false)
                            }
                            Player.STATE_IDLE -> {
                                // Idle
                            }
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        Log.e(TAG, "ExoPlayer error: ${error.message}", error)
                        Log.e(TAG, "Error code: ${error.errorCode}")

                        if (shouldSwitchToVLC(error)) {
                            Log.d(TAG, "Codec error detected, auto-switching to VLC")
                            val currentPos = currentPosition
                            switchToVLC(currentUrl, currentPos, autoSwitch = true)
                        } else {
                            val errorMessage = getErrorMessage(error)

                            if (error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) {
                                if (retryCount < MAX_RETRY_COUNT) {
                                    retryWithBackoff(currentUrl, retryCount, isExoPlayer = true)
                                    retryCount++
                                    return
                                }
                            }

                            listener.onPlayerError(errorMessage, true)
                        }
                    }

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        listener.onPlaybackStateChanged(isPlaying)
                    }

                    override fun onTracksChanged(tracks: Tracks) {
                        listener.onTracksChanged()

                        if (!hasCheckedCodecs && currentPlayerType == PlayerType.EXOPLAYER) {
                            checkForProblematicCodecs()
                        }
                    }
                })
            }

        currentPlayerType = PlayerType.EXOPLAYER
        exoPlayerView.visibility = View.VISIBLE
        vlcVideoLayout.visibility = View.GONE
        hasCheckedCodecs = false
        retryCount = 0

        Log.d(TAG, "ExoPlayer initialized successfully")
    }

    private fun checkForProblematicCodecs() {
        exoPlayer?.let { player ->
            val currentTracks = player.currentTracks
            val audioFormat = player.audioFormat
            val videoFormat = player.videoFormat

            videoFormat?.sampleMimeType?.let { mimeType ->
                Log.d(TAG, "Detected video codec: $mimeType")

                if (PROBLEMATIC_VIDEO_CODECS.any { it.equals(mimeType, ignoreCase = true) }) {
                    Log.w(TAG, "⚠️ HEVC/H.265 video codec detected: $mimeType")
                    listener.onProblematicCodecDetected("HEVC/H.265 detected: $mimeType")
                    hasCheckedCodecs = true

                    handler.postDelayed({
                        if (currentPlayerType == PlayerType.EXOPLAYER) {
                            val currentPos = player.currentPosition
                            switchToVLC(currentUrl, currentPos, autoSwitch = true)
                        }
                    }, 1000)
                    return
                }
            }

            audioFormat?.sampleMimeType?.let { mimeType ->
                Log.d(TAG, "Detected audio codec: $mimeType")

                if (PROBLEMATIC_AUDIO_CODECS.any { it.equals(mimeType, ignoreCase = true) }) {
                    Log.w(TAG, "⚠️ Problematic audio codec detected: $mimeType")
                    listener.onProblematicCodecDetected("AC3/DTS detected: $mimeType")
                    hasCheckedCodecs = true
                    return
                }
            }

            currentTracks.groups.forEach { group ->
                if (group.type == C.TRACK_TYPE_AUDIO) {
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        val mimeType = format.sampleMimeType ?: continue

                        Log.d(TAG, "Audio track $i: $mimeType")

                        if (PROBLEMATIC_AUDIO_CODECS.any { it.equals(mimeType, ignoreCase = true) }) {
                            Log.w(TAG, "⚠️ Problematic audio codec in track $i: $mimeType")
                            listener.onProblematicCodecDetected("AC3/DTS detected: $mimeType")
                            hasCheckedCodecs = true
                            return
                        }
                    }
                }
            }

            hasCheckedCodecs = true
            Log.d(TAG, "✅ No problematic codecs detected")
        }
    }

    private fun initVLC() {
        if (hasInitializedVLC && vlcPlayer != null) {
            Log.d(TAG, "VLC already initialized")
            return
        }

        Log.d(TAG, "Initializing VLC...")

        val options = ArrayList<String>().apply {
            add("--verbose=0")
            add("--no-audio-time-stretch")
            add("--file-caching=1500")
            add("--network-caching=2500")
            add("--http-reconnect")
            add("--avcodec-codec=hevc,h264")
            add("--avcodec-skiploopfilter=1")
            add("--rtsp-tcp")
            add("--audio-language=hin,eng")
        }

        try {
            libVLC = LibVLC(context, options)
            Log.d(TAG, "✅ LibVLC instance created successfully")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Failed to create LibVLC instance", e)
            throw RuntimeException("Cannot create LibVLC instance. Check VLC dependencies.", e)
        }

        vlcPlayer = MediaPlayer(libVLC).apply {
            attachViews(vlcVideoLayout, null, false, false)

            setEventListener { event ->
                when (event.type) {
                    MediaPlayer.Event.Playing -> {
                        Log.d(TAG, "VLC: Playing")
                        listener.onBuffering(false)
                        listener.onPlaybackStateChanged(true)
                        listener.onPlayerReady()

                        if (pendingStartPosition > 0) {
                            handler.postDelayed({
                                try {
                                    if (isSeekable) {
                                        time = pendingStartPosition
                                        Log.d(TAG, "VLC: Applied pending seek to: $pendingStartPosition ms")
                                        pendingStartPosition = -1
                                    }
                                } catch (e: Exception) {
                                    Log.e(TAG, "Failed to apply pending seek", e)
                                }
                            }, 1000)
                        }
                    }
                    MediaPlayer.Event.Paused -> {
                        Log.d(TAG, "VLC: Paused")
                        listener.onPlaybackStateChanged(false)
                    }
                    MediaPlayer.Event.Stopped -> {
                        Log.d(TAG, "VLC: Stopped")
                        listener.onPlaybackStateChanged(false)
                    }
                    MediaPlayer.Event.EndReached -> {
                        Log.d(TAG, "VLC: End reached")
                        listener.onPlaybackStateChanged(false)
                    }
                    MediaPlayer.Event.EncounteredError -> {
                        Log.e(TAG, "VLC: Error encountered: ${event.type}")

                        if (currentUrl.isNotEmpty() && retryCount < MAX_RETRY_COUNT) {
                            handler.postDelayed({
                                try {
                                    stop()
                                    play()
                                    Log.d(TAG, "VLC: Attempting recovery after error")
                                } catch (e: Exception) {
                                    Log.e(TAG, "VLC: Recovery failed", e)
                                    listener.onPlayerError("VLC playback error", true)
                                }
                            }, 1000)
                        } else {
                            listener.onPlayerError("VLC playback error", true)
                        }
                    }
                    MediaPlayer.Event.Buffering -> {
                        val buffering = event.buffering
                        Log.d(TAG, "VLC: Buffering $buffering%")
                        listener.onBuffering(buffering < 100f, buffering.toInt())
                    }
                    MediaPlayer.Event.TimeChanged -> {
                        listener.onPositionChanged(time)
                    }
                    MediaPlayer.Event.LengthChanged -> {
                        Log.d(TAG, "VLC: Duration = $length ms")
                        listener.onDurationChanged(length)
                        listener.onSeekableChanged(length > 0)
                    }
                    MediaPlayer.Event.Opening -> {
                        Log.d(TAG, "VLC: Opening media")
                        listener.onBuffering(true)
                    }
                    MediaPlayer.Event.ESAdded -> {
                        Log.d(TAG, "VLC: Elementary stream added")
                        listener.onTracksChanged()
                    }
                    MediaPlayer.Event.SeekableChanged -> {
                        Log.d(TAG, "VLC: Seekable changed: ${event.seekable}")
                        listener.onSeekableChanged(event.seekable)
                    }
                    else -> {
                        // Handle other events if needed
                    }
                }
            }
        }

        hasInitializedVLC = true
        Log.d(TAG, "✅ VLC MediaPlayer initialized successfully")
    }

    private fun shouldSwitchToVLC(error: PlaybackException): Boolean {
        val isCodecError = error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED

        val errorMsg = error.message?.lowercase() ?: ""
        val isAC3Error = errorMsg.contains("ac-3") ||
                errorMsg.contains("ac3") ||
                errorMsg.contains("eac3") ||
                errorMsg.contains("eac-3") ||
                errorMsg.contains("dts") ||
                errorMsg.contains("truehd") ||
                (errorMsg.contains("audio") && errorMsg.contains("codec"))

        val isHEVCError = errorMsg.contains("hevc") ||
                errorMsg.contains("h265") ||
                errorMsg.contains("h.265")

        return isCodecError || isAC3Error || isHEVCError
    }

    private fun getErrorMessage(error: PlaybackException): String {
        return when (error.errorCode) {
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ->
                "Network connection failed. Check your internet."
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                "Connection timeout. Please try again."
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
                "Video format not supported."
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND,
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                "Video not found or unavailable."
            else -> "Playback error: ${error.message}"
        }
    }

    fun load(url: String, autoPlay: Boolean = true, forceVLC: Boolean = false) {
        currentUrl = url
        shouldAutoPlay = autoPlay
        hasCheckedCodecs = false
        retryCount = 0
        pendingStartPosition = -1

        Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        Log.d(TAG, "LOADING MEDIA:")
        Log.d(TAG, "  - URL: $url")
        Log.d(TAG, "  - Player: $currentPlayerType")
        Log.d(TAG, "  - Force VLC: $forceVLC")

        val urlLower = url.lowercase()
        val isMKV = urlLower.contains(".mkv")
        val isAVI = urlLower.contains(".avi")
        val isHEVC = urlLower.contains(".hevc") ||
                urlLower.contains("h265") ||
                urlLower.contains(".265") ||
                urlLower.contains("x265")

        val hasAC3Hint = urlLower.contains("ac3") ||
                urlLower.contains("dts") ||
                urlLower.contains("dd5.1") ||
                urlLower.contains("dd+") ||
                urlLower.contains("eac3")

        val shouldAutoSwitchVLC = forceVLC ||
                (isMKV && hasAC3Hint) ||
                isAVI ||
                isHEVC

        Log.d(TAG, "  - Is HEVC/H.265: $isHEVC")
        Log.d(TAG, "  - Is MKV: $isMKV")
        Log.d(TAG, "  - Is AVI: $isAVI")
        Log.d(TAG, "  - Has AC3 hint: $hasAC3Hint")
        Log.d(TAG, "  - Should auto-switch VLC: $shouldAutoSwitchVLC")
        Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        if (shouldAutoSwitchVLC && currentPlayerType == PlayerType.EXOPLAYER) {
            Log.w(TAG, "⚠️ Auto-switching to VLC for better format support")
            Toast.makeText(context, "Using VLC for better codec support", Toast.LENGTH_SHORT).show()
            switchToVLC(url, 0, autoSwitch = true)
            return
        }

        when (currentPlayerType) {
            PlayerType.EXOPLAYER -> loadWithExo(url, autoPlay)
            PlayerType.VLC -> loadWithVLC(url, 0, autoPlay)
        }
    }

    private fun loadWithExo(url: String, autoPlay: Boolean) {
        try {
            Log.d(TAG, "Loading with ExoPlayer: $url")

            val dataSourceFactory = DefaultDataSource.Factory(
                context,
                DefaultHttpDataSource.Factory()
                    .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                    .setConnectTimeoutMs(30000)
                    .setReadTimeoutMs(30000)
                    .setAllowCrossProtocolRedirects(true)
            )

            val mediaSource: MediaSource = when {
                url.contains(".m3u8", ignoreCase = true) -> {
                    Log.d(TAG, "Creating HLS media source")
                    HlsMediaSource.Factory(dataSourceFactory)
                        .setAllowChunklessPreparation(true)
                        .createMediaSource(MediaItem.fromUri(url))
                }
                else -> {
                    Log.d(TAG, "Creating progressive media source")
                    ProgressiveMediaSource.Factory(dataSourceFactory)
                        .createMediaSource(MediaItem.fromUri(url))
                }
            }

            exoPlayer?.apply {
                setMediaSource(mediaSource)
                prepare()
                playWhenReady = autoPlay
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error loading with ExoPlayer", e)
            listener.onPlayerError("Failed to load with ExoPlayer: ${e.message}", true)
        }
    }

    private fun loadWithVLC(url: String, startPosition: Long, autoPlay: Boolean) {
        try {
            Log.d(TAG, "Loading with VLC: $url")

            if (!hasInitializedVLC) {
                initVLC()
            }

            if (libVLC == null || vlcPlayer == null) {
                throw IllegalStateException("VLC not properly initialized")
            }

            if (startPosition > 0 && vlcPlayer?.isPlaying != true) {
                pendingStartPosition = startPosition
            }

            val media = Media(libVLC, Uri.parse(url)).apply {
                setHWDecoderEnabled(true, true)
                addOption(":network-caching=5000")
                addOption(":file-caching=3000")
                addOption(":clock-jitter=0")
                addOption(":clock-synchro=0")
                addOption(":no-audio-time-stretch")
                addOption(":audio-desync=50")
                addOption(":avcodec-threads=4")
                addOption(":avcodec-skiploopfilter=1")
                addOption(":no-deinterlace")
                addOption(":input-fast-seek")
            }

            vlcPlayer?.media = media
            media.release()

            if (autoPlay) {
                vlcPlayer?.play()
            }

            if (startPosition > 0 && vlcPlayer?.isPlaying == true) {
                handler.postDelayed({
                    try {
                        if (vlcPlayer?.isSeekable == true) {
                            vlcPlayer?.time = startPosition
                            Log.d(TAG, "VLC seeked to: $startPosition ms")
                        } else {
                            Log.w(TAG, "VLC stream is not seekable, skipping initial seek")
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to seek VLC", e)
                    }
                }, 2000)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error loading with VLC", e)
            listener.onPlayerError("VLC failed to load: ${e.message}", true)
        }
    }

    private fun retryWithBackoff(url: String, retryCount: Int, maxRetries: Int = MAX_RETRY_COUNT, isExoPlayer: Boolean = true) {
        if (retryCount >= maxRetries) {
            listener.onPlayerError("Failed to connect after $maxRetries attempts", true)
            return
        }

        val delay = (2000 * (retryCount + 1)).toLong()

        handler.postDelayed({
            Log.w(TAG, "Retry attempt ${retryCount + 1} for URL: $url")

            if (isExoPlayer) {
                exoPlayer?.stop()
                loadWithExo(url, shouldAutoPlay)
            } else {
                vlcPlayer?.stop()
                loadWithVLC(url, 0, shouldAutoPlay)
            }
        }, delay)
    }

    fun switchToVLC(url: String = currentUrl, position: Long = getCurrentPosition(), autoSwitch: Boolean = false) {
        Log.d(TAG, "Switching from ExoPlayer to VLC (position: $position ms, auto: $autoSwitch)")

        exoPlayer?.stop()
        exoPlayerView.visibility = View.GONE
        vlcVideoLayout.visibility = View.VISIBLE
        currentPlayerType = PlayerType.VLC

        if (!hasInitializedVLC) {
            initVLC()
        }

        loadWithVLC(url, position, shouldAutoPlay)

        if (autoSwitch) {
            Toast.makeText(context, "Auto-switched to VLC for better codec support", Toast.LENGTH_SHORT).show()
            listener.onPlayerError("Auto-switched to VLC for better codec support", false)
        } else {
            Toast.makeText(context, "Switched to VLC player", Toast.LENGTH_SHORT).show()
            listener.onPlayerError("Switched to VLC player", false)
        }
    }

    fun switchToExoPlayer(url: String = currentUrl, position: Long = getCurrentPosition()) {
        Log.d(TAG, "Switching from VLC to ExoPlayer (position: $position ms)")

        vlcPlayer?.stop()
        vlcVideoLayout.visibility = View.GONE
        exoPlayerView.visibility = View.VISIBLE
        currentPlayerType = PlayerType.EXOPLAYER

        loadWithExo(url, shouldAutoPlay)

        if (position > 0) {
            handler.postDelayed({
                exoPlayer?.seekTo(position)
            }, 1000)
        }

        Toast.makeText(context, "Switched to ExoPlayer", Toast.LENGTH_SHORT).show()
        listener.onPlayerError("Switched to ExoPlayer", false)
    }

    fun forceVLCMode() {
        if (currentPlayerType == PlayerType.EXOPLAYER) {
            switchToVLC(autoSwitch = false)
        }
    }

    fun forceExoPlayerMode() {
        if (currentPlayerType == PlayerType.VLC) {
            switchToExoPlayer()
        }
    }

    fun play() {
        when (currentPlayerType) {
            PlayerType.EXOPLAYER -> {
                exoPlayer?.play()
                Log.d(TAG, "ExoPlayer: play()")
            }
            PlayerType.VLC -> {
                vlcPlayer?.play()
                Log.d(TAG, "VLC: play()")
            }
        }
    }

    fun pause() {
        when (currentPlayerType) {
            PlayerType.EXOPLAYER -> {
                exoPlayer?.pause()
                Log.d(TAG, "ExoPlayer: pause()")
            }
            PlayerType.VLC -> {
                vlcPlayer?.pause()
                Log.d(TAG, "VLC: pause()")
            }
        }
    }

    fun stop() {
        when (currentPlayerType) {
            PlayerType.EXOPLAYER -> exoPlayer?.stop()
            PlayerType.VLC -> vlcPlayer?.stop()
        }
    }

    fun seekTo(positionMs: Long) {
        if (isSeekingInProgress) return

        isSeekingInProgress = true

        when (currentPlayerType) {
            PlayerType.EXOPLAYER -> {
                exoPlayer?.seekTo(positionMs)
                Log.d(TAG, "ExoPlayer: seekTo($positionMs)")
            }
            PlayerType.VLC -> {
                try {
                    vlcPlayer?.time = positionMs
                    Log.d(TAG, "VLC: seekTo($positionMs)")
                } catch (e: Exception) {
                    Log.e(TAG, "VLC seek failed", e)
                }
            }
        }

        handler.postDelayed({
            isSeekingInProgress = false
        }, 500)
    }

    fun seekBy(incrementMs: Long) {
        val currentPos = getCurrentPosition()
        val duration = getDuration()
        val newPos = (currentPos + incrementMs).coerceIn(0, duration)
        seekTo(newPos)
    }

    fun isPlaying(): Boolean {
        return when (currentPlayerType) {
            PlayerType.EXOPLAYER -> exoPlayer?.isPlaying == true
            PlayerType.VLC -> vlcPlayer?.isPlaying == true
        }
    }

    fun getCurrentPosition(): Long {
        return when (currentPlayerType) {
            PlayerType.EXOPLAYER -> exoPlayer?.currentPosition ?: 0
            PlayerType.VLC -> vlcPlayer?.time ?: 0
        }
    }

    fun getDuration(): Long {
        return when (currentPlayerType) {
            PlayerType.EXOPLAYER -> exoPlayer?.duration?.takeIf { it != C.TIME_UNSET } ?: 0
            PlayerType.VLC -> vlcPlayer?.length ?: 0
        }
    }

    fun isSeekable(): Boolean {
        return when (currentPlayerType) {
            PlayerType.EXOPLAYER -> exoPlayer?.isCurrentMediaItemSeekable == true
            PlayerType.VLC -> (vlcPlayer?.length ?: 0) > 0
        }
    }

    fun getBufferedPosition(): Long {
        return when (currentPlayerType) {
            PlayerType.EXOPLAYER -> exoPlayer?.bufferedPosition ?: 0
            PlayerType.VLC -> getCurrentPosition()
        }
    }

    fun getBufferedPercentage(): Int {
        return when (currentPlayerType) {
            PlayerType.EXOPLAYER -> exoPlayer?.bufferedPercentage ?: 0
            PlayerType.VLC -> {
                val duration = getDuration()
                if (duration > 0) {
                    ((getBufferedPosition() * 100) / duration).toInt()
                } else 0
            }
        }
    }

    fun getAudioTrackCount(): Int {
        return when (currentPlayerType) {
            PlayerType.EXOPLAYER -> {
                exoPlayer?.currentTracks?.groups?.count { it.type == C.TRACK_TYPE_AUDIO } ?: 0
            }
            PlayerType.VLC -> {
                try {
                    // VLC doesn't provide a direct audio track count API
                    // We'll return 0 for now since VLC audio track management is limited
                    0
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to get VLC audio track count", e)
                    0
                }
            }
        }
    }

    fun getCurrentAudioTrack(): Int {
        return when (currentPlayerType) {
            PlayerType.EXOPLAYER -> {
                // For ExoPlayer, find the selected audio track
                exoPlayer?.let { player ->
                    player.currentTracks.groups.forEach { group ->
                        if (group.type == C.TRACK_TYPE_AUDIO) {
                            for (i in 0 until group.length) {
                                if (group.isTrackSelected(i)) {
                                    return@let i
                                }
                            }
                        }
                    }
                    0
                } ?: 0
            }
            PlayerType.VLC -> {
                // VLC doesn't expose current audio track index easily
                0
            }
        }
    }

    fun setAudioTrack(trackIndex: Int): Boolean {
        return try {
            when (currentPlayerType) {
                PlayerType.EXOPLAYER -> {
                    exoPlayer?.let { player ->
                        val audioTrackGroup = player.currentTracks.groups
                            .firstOrNull { it.type == C.TRACK_TYPE_AUDIO }

                        audioTrackGroup?.let { group ->
                            val override = TrackSelectionOverride(
                                group.mediaTrackGroup,
                                listOf(trackIndex)
                            )

                            val newParams = trackSelector?.parameters?.buildUpon()
                                ?.clearOverrides()
                                ?.addOverride(override)
                                ?.build()

                            if (newParams != null) {
                                trackSelector?.parameters = newParams
                                true
                            } else false
                        } ?: false
                    } ?: false
                }
                PlayerType.VLC -> {
                    // VLC doesn't support setting audio track by index easily
                    // You might need to use different approach for VLC
                    Log.w(TAG, "VLC audio track switching not implemented")
                    false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set audio track", e)
            false
        }
    }

    fun getAvailableAudioTracks(): List<AudioTrackInfo> {
        val tracks = mutableListOf<AudioTrackInfo>()

        when (currentPlayerType) {
            PlayerType.EXOPLAYER -> {
                exoPlayer?.let { player ->
                    player.currentTracks.groups.forEach { group ->
                        if (group.type == C.TRACK_TYPE_AUDIO) {
                            for (i in 0 until group.length) {
                                val format = group.getTrackFormat(i)
                                tracks.add(
                                    AudioTrackInfo(
                                        trackIndex = i,
                                        language = format.language ?: "Unknown",
                                        label = format.label ?: "Track ${tracks.size + 1}",
                                        isSelected = group.isTrackSelected(i),
                                        channels = format.channelCount
                                    )
                                )
                            }
                        }
                    }
                }
            }
            PlayerType.VLC -> {
                // VLC doesn't expose audio track information easily
                // For VLC, we can't get detailed track info, so return empty or basic info
                Log.d(TAG, "VLC audio track info not available")
                // You could add basic placeholder if needed:
                // tracks.add(AudioTrackInfo(0, "Unknown", "Default", true, 2))
            }
        }

        return tracks
    }

    fun getPlayerType(): PlayerType = currentPlayerType

    fun getTrackSelector(): DefaultTrackSelector? = trackSelector

    fun getExoPlayer(): ExoPlayer? = exoPlayer

    fun getVLCPlayer(): MediaPlayer? = vlcPlayer

    fun getCurrentUrl(): String = currentUrl

    fun release() {
        Log.d(TAG, "Releasing players")

        handler.removeCallbacksAndMessages(null)

        exoPlayer?.let { player ->
            player.pause()
            player.stop()
            player.clearMediaItems()
            exoPlayerView.player = null
            player.release()
        }
        exoPlayer = null
        trackSelector = null

        vlcPlayer?.let {
            it.stop()
            it.detachViews()
            it.media?.release()
            it.setEventListener(null)
            it.release()
        }
        vlcPlayer = null

        libVLC?.let {
            it.release()
        }
        libVLC = null

        hasInitializedVLC = false
        hasCheckedCodecs = false
        pendingStartPosition = -1
        retryCount = 0
        isSeekingInProgress = false

        Log.d(TAG, "All players released successfully")
    }
}