package com.shimulfp.bdixlivetv.components.tv

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.FocusInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.utils.TVFocusManager

/**
 * Enhanced TV Channel Card with improved focus management and D-pad support
 *
 * @param channelName Name of the channel
 * @param channelLogo URL of the channel logo
 * @param isSelected Whether this channel is currently selected
 * @param isPlaying Whether this channel is currently playing
 * @param onClick Callback when card is clicked
 * @param modifier Modifier for the card
 * @param focusRequester Optional focus requester for programmatic focus
 */
@Composable
fun TvChannelCardEnhanced(
    channelName: String,
    channelLogo: String,
    isSelected: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Collect focus state from interaction source
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is FocusInteraction.Focus) {
                isFocused = true
            } else if (interaction is FocusInteraction.Unfocus) {
                isFocused = false
            }
        }
    }

    // ========== TV FOCUS ANIMATIONS - HIGHLY VISIBLE ==========
    val scale by animateDpAsState(
        targetValue = if (isFocused) 150.dp else 130.dp,
        animationSpec = spring(
            dampingRatio = 0.7f,
            stiffness = 400f
        ),
        label = "scale"
    )

    val borderWidth by animateDpAsState(
        targetValue = if (isFocused) 8.dp else 2.dp,
        animationSpec = tween(150),
        label = "borderWidth"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFFFFD700)          // Gold when focused
            isPlaying -> Color(0xFF00E676)         // Green when playing
            isSelected -> Color(0xFFFFC107)         // Yellow when selected
            else -> Color(0xFF333333)              // Dark gray when normal
        },
        animationSpec = tween(150),
        label = "borderColor"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFF3D3D1A)         // Dark gold when focused
            isPlaying -> Color(0xFF1A3D1A)         // Dark green when playing
            isSelected -> Color(0xFF3D3D1A)         // Dark yellow when selected
            else -> Color(0xFF1E1E1E)             // Dark gray when normal
        },
        animationSpec = tween(150),
        label = "bgColor"
    )

    val titleColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color.White               // White when focused
            isPlaying -> Color(0xFF90EE90)        // Light green when playing
            isSelected -> Color(0xFFFFD700)       // Gold when selected
            else -> Color(0xFFAAAAAA)             // Gray when normal
        },
        animationSpec = tween(150),
        label = "titleColor"
    )

    val shadowElevation by animateDpAsState(
        targetValue = if (isFocused) 16.dp else 4.dp,
        animationSpec = tween(150),
        label = "shadowElevation"
    )

    Box(
        modifier = modifier
            .width(scale)
            .height(scale * 0.6f) // Maintain aspect ratio
            .clip(RoundedCornerShape(16.dp))
            .background(bgColor)
            .border(
                width = borderWidth,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .focusable(interactionSource = interactionSource)
            .focusRequester(focusRequester)
    ) {
        // Channel logo or text
        if (channelLogo.isNotEmpty()) {
            AsyncImage(
                model = channelLogo,
                contentDescription = channelName,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp),
                contentScale = androidx.compose.ui.layout.ContentScale.Fit
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    channelName.take(3).uppercase(),
                    color = titleColor,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        // ========== FOCUS INDICATOR - TOP RIGHT CORNER ==========
        if (isFocused) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(24.dp)
                    .background(Color(0xFFFFD700), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = "Focused",
                    tint = Color.Black,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // ========== PLAYING INDICATOR - TOP LEFT CORNER ==========
        if (isPlaying) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .size(28.dp)
                    .background(Color(0xFF00E676), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = "Playing",
                    tint = Color.Black,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // ========== FOCUS OVERLAY - GRADIENT ==========
        if (isFocused) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFFFFD700).copy(alpha = 0.3f)
                            )
                        )
                    )
            )
        }

        // Channel name at bottom
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Color.Black.copy(alpha = if (isFocused) 0.7f else 0.5f),
                    RoundedCornerShape(bottomStart = 14.dp, bottomEnd = 14.dp)
                )
                .padding(horizontal = 6.dp, vertical = 6.dp)
        ) {
            Text(
                text = channelName,
                color = titleColor,
                fontSize = if (isFocused) 14.sp else 12.sp,
                fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * Enhanced TV Movie Card with improved focus management
 *
 * @param movieTitle Title of the movie
 * @param moviePoster URL of the movie poster
 * @param movieQuality Quality badge (e.g., "1080p", "4K")
 * @param movieYear Release year
 * @param isFavorite Whether the movie is marked as favorite
 * @param isSelected Whether this movie is currently selected
 * @param onClick Callback when card is clicked
 * @param modifier Modifier for the card
 * @param focusRequester Optional focus requester for programmatic focus
 */
@Composable
fun TvMovieCardEnhanced(
    movieTitle: String,
    moviePoster: String,
    movieQuality: String = "",
    movieYear: String = "",
    isFavorite: Boolean = false,
    isSelected: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Collect focus state
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is FocusInteraction.Focus) {
                isFocused = true
            } else if (interaction is FocusInteraction.Unfocus) {
                isFocused = false
            }
        }
    }

    // ========== TV FOCUS ANIMATIONS - HIGHLY VISIBLE ==========
    val scale by animateDpAsState(
        targetValue = if (isFocused) 160.dp else 140.dp,
        animationSpec = spring(
            dampingRatio = 0.7f,
            stiffness = 400f
        ),
        label = "scale"
    )

    val borderWidth by animateDpAsState(
        targetValue = if (isFocused) 8.dp else 2.dp,
        animationSpec = tween(150),
        label = "borderWidth"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFFFFD700)          // Gold when focused
            isSelected -> Color(0xFFFFC107)         // Yellow when selected
            else -> Color(0xFF333333)              // Dark gray when normal
        },
        animationSpec = tween(150),
        label = "borderColor"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFF3D3D1A)         // Dark gold when focused
            isSelected -> Color(0xFF3D3D1A)         // Dark yellow when selected
            else -> Color(0xFF1E1E1E)             // Dark gray when normal
        },
        animationSpec = tween(150),
        label = "bgColor"
    )

    Column(
        modifier = modifier
            .width(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .focusable(interactionSource = interactionSource)
            .focusRequester(focusRequester)
    ) {
        // Poster
        Box(
            modifier = Modifier
                .width(scale)
                .height(scale * 1.5f) // 2:3 aspect ratio
                .clip(RoundedCornerShape(16.dp))
                .background(bgColor)
                .border(
                    width = borderWidth,
                    color = borderColor,
                    shape = RoundedCornerShape(16.dp)
                )
        ) {
            // Movie poster
            if (moviePoster.isNotEmpty()) {
                AsyncImage(
                    model = moviePoster,
                    contentDescription = movieTitle,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
            } else {
                // Placeholder
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            movieTitle.take(20),
                            color = Color.Gray,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // ========== FOCUS OVERLAY - VERY VISIBLE ==========
            if (isFocused) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xFFFFD700).copy(alpha = 0.8f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Large play button
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color(0xFFFFD700),
                                modifier = Modifier.size(42.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "SELECT",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }

            // ========== QUALITY BADGE - TOP RIGHT ==========
            if (movieQuality.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .background(
                            when {
                                movieQuality.contains("4K") -> Color(0xFFFFD700)
                                movieQuality.contains("1080") -> Color(0xFF00E676)
                                movieQuality.contains("720") -> Color(0xFF00BFFF)
                                else -> Color(0xFF808080)
                            },
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        movieQuality,
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // ========== YEAR BADGE - TOP LEFT ==========
            if (movieYear.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                        .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        movieYear,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // ========== FAVORITE HEART - BOTTOM LEFT ==========
            if (isFavorite) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(10.dp)
                        .size(28.dp)
                        .background(Color(0xFFFF1744), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Favorite",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Movie title below poster
        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = movieTitle,
            color = if (isFocused) Color.White else Color(0xFFCCCCCC),
            fontSize = if (isFocused) 14.sp else 12.sp,
            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Start,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * Enhanced TV Navigation Item with improved focus management
 *
 * @param title Navigation item title
 * @param icon Icon to display
 * @param isSelected Whether this item is currently selected
 * @param onClick Callback when item is clicked
 * @param modifier Modifier for the nav item
 * @param focusRequester Optional focus requester
 */
@Composable
fun TvNavItemEnhanced(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Collect focus state
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is FocusInteraction.Focus) {
                isFocused = true
            } else if (interaction is FocusInteraction.Unfocus) {
                isFocused = false
            }
        }
    }

    // ========== FOCUS ANIMATIONS ==========
    val backgroundColor by animateColorAsState(
        targetValue = when {
            isSelected -> Color(0xFFFFD700).copy(alpha = 0.3f) // Gold tint
            isFocused -> Color(0xFF3D3D1A)                      // Dark gold
            else -> Color.Transparent
        },
        animationSpec = tween(150),
        label = "backgroundColor"
    )

    val iconColor by animateColorAsState(
        targetValue = when {
            isSelected -> Color(0xFFFFD700)  // Gold
            isFocused -> Color.White          // White
            else -> Color(0xFFAAAAAA)        // Gray
        },
        animationSpec = tween(150),
        label = "iconColor"
    )

    val textColor by animateColorAsState(
        targetValue = when {
            isSelected -> Color(0xFFFFD700)  // Gold
            isFocused -> Color.White          // White
            else -> Color(0xFFCCCCCC)        // Light gray
        },
        animationSpec = tween(150),
        label = "textColor"
    )

    val scale by animateDpAsState(
        targetValue = if (isFocused) 8.dp else 0.dp,
        animationSpec = tween(150),
        label = "scale"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .background(
                backgroundColor,
                RoundedCornerShape(12.dp)
            )
            .border(
                width = scale,
                color = if (isSelected) Color(0xFFFFD700) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .focusable(interactionSource = interactionSource)
            .focusRequester(focusRequester)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = iconColor,
            modifier = Modifier.size(28.dp)
        )

        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text = title,
            color = textColor,
            fontSize = 16.sp,
            fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Normal
        )
    }
}
