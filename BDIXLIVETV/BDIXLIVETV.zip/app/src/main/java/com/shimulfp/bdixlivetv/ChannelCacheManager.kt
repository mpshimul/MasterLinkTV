package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.*
import java.io.File

object ChannelCacheManager {
    private const val TAG = "ChannelCacheManager"
    private const val CACHE_EXPIRY_MINUTES = 50L
    private const val CACHE_EXPIRY_MS = CACHE_EXPIRY_MINUTES * 60 * 1000L

    private const val AYNA_CACHE_FILE = "ayna_channels_cache.json"
    private const val BDIX_CACHE_FILE = "bdix_channels_cache.json"
    private const val COMBINED_CACHE_FILE = "all_channels_cache.json"

    // ⚠️ PREVENT INFINITE LOOP
    private var isRefreshing = false
    private var lastRefreshTime = 0L
    private const val MIN_REFRESH_INTERVAL_MS = 60_000L  // 1 minute minimum between refreshes

    fun isCacheOlderThan(context: Context, minutes: Long): Boolean {
        return try {
            val file = File(context.filesDir, COMBINED_CACHE_FILE)
            if (file.exists()) {
                val minutesOld = (System.currentTimeMillis() - file.lastModified()) / (60 * 1000)
                Log.d(TAG, "Cache age: ${minutesOld}m (threshold: ${minutes}m)")
                minutesOld > minutes
            } else {
                true
            }
        } catch (e: Exception) {
            true
        }
    }

    fun clearAllCache(context: Context) {
        listOf(AYNA_CACHE_FILE, BDIX_CACHE_FILE, COMBINED_CACHE_FILE).forEach { filename ->
            try {
                val file = File(context.filesDir, filename)
                if (file.exists()) {
                    file.delete()
                    Log.d(TAG, "✅ Cleared cache: $filename")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error clearing cache $filename: ${e.message}")
            }
        }
    }

    fun getCacheStatus(context: Context): CacheStatus {
        val aynaCache = loadChannelCacheFromFile(context, AYNA_CACHE_FILE)
        val bdixCache = loadChannelCacheFromFile(context, BDIX_CACHE_FILE)
        val combinedCache = loadChannelCacheFromFile(context, COMBINED_CACHE_FILE)

        val now = System.currentTimeMillis()

        return CacheStatus(
            aynaCache = aynaCache?.let {
                CacheInfo(
                    channelCount = it.channels.size,
                    lastUpdated = it.timestamp,
                    isExpired = now - it.timestamp > CACHE_EXPIRY_MS,
                    source = it.source
                )
            },
            bdixCache = bdixCache?.let {
                CacheInfo(
                    channelCount = it.channels.size,
                    lastUpdated = it.timestamp,
                    isExpired = now - it.timestamp > CACHE_EXPIRY_MS,
                    source = it.source
                )
            },
            combinedCache = combinedCache?.let {
                CacheInfo(
                    channelCount = it.channels.size,
                    lastUpdated = it.timestamp,
                    isExpired = now - it.timestamp > CACHE_EXPIRY_MS,
                    source = it.source
                )
            },
            cacheExpiryMinutes = CACHE_EXPIRY_MINUTES
        )
    }

    suspend fun loadChannelsWithSmartCache(
        context: Context,
        username: String? = null,
        password: String? = null
    ): LoadResult = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 SMART CACHE LOAD STARTED")

        val firebaseManager = FirebaseManager(context)
        val githubToken = firebaseManager.getGitHubToken()

        if (githubToken.isNotEmpty()) {
            try {
                GitHubDataManager.initialize(githubToken)

                Log.d(TAG, "📊 Checking GitHub data freshness...")

                val githubDataAge = GitHubDataManager.getGitHubDataAge()

                if (githubDataAge > 0L && githubDataAge <= CACHE_EXPIRY_MINUTES) {
                    Log.d(TAG, "📥 GitHub data is fresh (${githubDataAge}m), downloading...")

                    val downloaded = GitHubDataManager.downloadAllFiles(context)

                    if (downloaded) {
                        val combinedCache = loadChannelCacheFromFile(context, COMBINED_CACHE_FILE)
                        if (combinedCache != null && combinedCache.channels.isNotEmpty()) {
                            val cachedChannels = combinedCache.channels
                            val (bdixChannels, aynaChannels) = separateChannelsBySource(cachedChannels)

                            Log.d(TAG, "📊 Loaded ${cachedChannels.size} channels from GitHub")
                            Log.d(TAG, "   Ayna: ${aynaChannels.size}, BDIX: ${bdixChannels.size}")

                            return@withContext LoadResult(
                                allChannels = cachedChannels,
                                bdixChannels = bdixChannels,
                                aynaChannels = aynaChannels,
                                isFromCache = true,
                                needsBackgroundRefresh = false
                            )
                        }
                    }
                } else if (githubDataAge > CACHE_EXPIRY_MINUTES) {
                    Log.d(TAG, "⚠️ GitHub data is old (${githubDataAge}m), will scrape fresh")
                } else if (githubDataAge == -1L) {
                    Log.d(TAG, "⚠️ No data on GitHub, will scrape fresh")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub check failed: ${e.message}")
            }
        }

        val combinedCache = loadChannelCacheFromFile(context, COMBINED_CACHE_FILE)

        if (combinedCache != null && combinedCache.channels.isNotEmpty()) {
            Log.d(TAG, "✅ Loaded ${combinedCache.channels.size} channels from cache")

            val isExpired = System.currentTimeMillis() - combinedCache.timestamp > CACHE_EXPIRY_MS

            val cachedChannels = combinedCache.channels
            val (bdixChannels, aynaChannels) = separateChannelsBySource(cachedChannels)

            Log.d(TAG, "📊 Separated: Ayna=${aynaChannels.size}, BDIX=${bdixChannels.size}")

            if (isExpired && canStartRefresh()) {
                Log.d(TAG, "⚠️ Cache expired, starting background refresh...")
                startBackgroundRefresh(context, username, password)
            }

            return@withContext LoadResult(
                allChannels = cachedChannels,
                bdixChannels = bdixChannels,
                aynaChannels = aynaChannels,
                isFromCache = true,
                needsBackgroundRefresh = isExpired
            )
        }

        Log.d(TAG, "❌ No cache found, performing immediate refresh")
        return@withContext performImmediateRefresh(context, username, password)
    }

    /**
     * Prevent infinite refresh loops
     */
    private fun canStartRefresh(): Boolean {
        val now = System.currentTimeMillis()

        if (isRefreshing) {
            Log.w(TAG, "⚠️ Already refreshing, skipping...")
            return false
        }

        if (now - lastRefreshTime < MIN_REFRESH_INTERVAL_MS) {
            Log.w(TAG, "⚠️ Refresh too soon (${(now - lastRefreshTime) / 1000}s ago), skipping...")
            return false
        }

        return true
    }

    fun startBackgroundRefresh(context: Context, username: String?, password: String?) {
        if (!canStartRefresh()) {
            Log.w(TAG, "⚠️ Skipping background refresh (loop prevention)")
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                isRefreshing = true
                lastRefreshTime = System.currentTimeMillis()

                Log.d(TAG, "🔄 Background refresh started...")
                val result = refreshAllChannels(context, username, password)

                if (result.success && result.allChannels.isNotEmpty()) {
                    Log.d(TAG, "✅ Background refresh completed: ${result.allChannels.size} channels")

                    val firebaseManager = FirebaseManager(context)
                    val githubToken = firebaseManager.getGitHubToken()

                    if (githubToken.isNotEmpty()) {
                        Log.d(TAG, "🚀 Attempting GitHub upload...")
                        GitHubDataManager.initialize(githubToken)

                        val uploaded = GitHubDataManager.uploadAllFiles(context)

                        if (uploaded) {
                            Log.d(TAG, "🎉 Uploaded to GitHub")
                        } else {
                            Log.w(TAG, "⚠️ GitHub upload failed")
                        }
                    }
                } else {
                    Log.w(TAG, "⚠️ Background refresh failed or empty")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Background refresh error: ${e.message}")
            } finally {
                isRefreshing = false
            }
        }
    }

    private suspend fun performImmediateRefresh(
        context: Context,
        username: String?,
        password: String?
    ): LoadResult = withContext(Dispatchers.IO) {

        // ⚠️ PREVENT INFINITE LOOP
        if (!canStartRefresh()) {
            Log.w(TAG, "⚠️ Refresh blocked (loop prevention), returning empty")
            return@withContext LoadResult(
                allChannels = emptyList(),
                bdixChannels = emptyList(),
                aynaChannels = emptyList(),
                isFromCache = false,
                needsBackgroundRefresh = false
            )
        }

        Log.d(TAG, "🔄 Performing immediate refresh...")

        isRefreshing = true
        lastRefreshTime = System.currentTimeMillis()

        try {
            val refreshResult = refreshAllChannels(context, username, password)

            val (bdixChannels, aynaChannels) = separateChannelsBySource(refreshResult.allChannels)

            Log.d(TAG, "📊 Refresh result: Total=${refreshResult.allChannels.size}, Ayna=${aynaChannels.size}, BDIX=${bdixChannels.size}")

            return@withContext LoadResult(
                allChannels = refreshResult.allChannels,
                bdixChannels = bdixChannels,
                aynaChannels = aynaChannels,
                isFromCache = false,
                needsBackgroundRefresh = false
            )
        } finally {
            isRefreshing = false
        }
    }

    private suspend fun refreshAllChannels(
        context: Context,
        username: String?,
        password: String?
    ): RefreshResult = withContext(Dispatchers.IO) {
        Log.d(TAG, "🔄 === REFRESH ALL CHANNELS ===")

        val allChannels = mutableListOf<Channel>()

        // ========== AYNA OTT ==========
        val aynaChannels = try {
            if (username != null && password != null && password.isNotEmpty()) {
                Log.d(TAG, "🔄 Starting AynaOTT refresh...")
                val channels = PythonHelper.getAynaChannels(context, username, password, true)
                Log.d(TAG, "✅ AynaOTT: ${channels.size} channels")

                // DEBUG: Log first channel to check source
                if (channels.isNotEmpty()) {
                    val first = channels.first()
                    Log.d(TAG, "   First channel: name=${first.name}, source=${first.source}")
                }

                saveToCache(
                    context,
                    AYNA_CACHE_FILE,
                    ChannelCache(channels, System.currentTimeMillis(), "aynaott")
                )

                channels
            } else {
                Log.d(TAG, "⚠️ AynaOTT skipped - no credentials")
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ AynaOTT refresh failed: ${e.message}")
            emptyList()
        }

        // ========== BDIX ==========
        val bdixChannels = try {
            Log.d(TAG, "🔄 Starting BDIX refresh...")
            val channels = PythonHelper.getOtherSourcesChannels(context)
            Log.d(TAG, "✅ BDIX: ${channels.size} channels")

            // DEBUG: Log first channel to check source
            if (channels.isNotEmpty()) {
                val first = channels.first()
                Log.d(TAG, "   First channel: name=${first.name}, source=${first.source}")
            }

            saveToCache(
                context,
                BDIX_CACHE_FILE,
                ChannelCache(channels, System.currentTimeMillis(), "bdix")
            )

            channels
        } catch (e: Exception) {
            Log.e(TAG, "❌ BDIX refresh failed: ${e.message}")
            emptyList()
        }

        // ========== COMBINE ALL ==========
        allChannels.addAll(aynaChannels)
        allChannels.addAll(bdixChannels)

        val finalChannels = allChannels.sortedBy { it.name.uppercase().trim() }

        Log.d(TAG, "📊 Channel counts:")
        Log.d(TAG, "   - Ayna: ${aynaChannels.size}")
        Log.d(TAG, "   - BDIX: ${bdixChannels.size}")
        Log.d(TAG, "   - Total: ${finalChannels.size}")

        // Save combined cache
        if (finalChannels.isNotEmpty()) {
            saveToCache(
                context,
                COMBINED_CACHE_FILE,
                ChannelCache(finalChannels, System.currentTimeMillis(), "combined")
            )
            Log.d(TAG, "💾 Saved ${finalChannels.size} channels to combined cache")
        }

        Log.d(TAG, "🎉 Total: ${finalChannels.size} channels")

        // ========== GITHUB UPLOAD ==========
        if (finalChannels.isNotEmpty()) {
            try {
                val firebaseManager = FirebaseManager(context)
                val githubToken = firebaseManager.getGitHubToken()

                if (githubToken.isNotEmpty()) {
                    GitHubDataManager.initialize(githubToken)
                    val uploaded = GitHubDataManager.uploadAllFiles(context)
                    Log.d(TAG, if (uploaded) "🎉 GitHub upload success" else "⚠️ GitHub upload failed")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Upload error: ${e.message}")
            }
        }

        return@withContext RefreshResult(
            allChannels = finalChannels,
            success = finalChannels.isNotEmpty()
        )
    }

    suspend fun manualRefresh(
        context: Context,
        username: String?,
        password: String?
    ): RefreshResult = withContext(Dispatchers.IO) {
        Log.d(TAG, "🔄 Manual refresh triggered")
        // Reset loop prevention for manual refresh
        isRefreshing = false
        lastRefreshTime = 0L
        return@withContext refreshAllChannels(context, username, password)
    }

    private fun <T> saveToCache(context: Context, filename: String, data: T) {
        try {
            val file = File(context.filesDir, filename)
            val json = Gson().toJson(data)

            if (data is ChannelCache) {
                Log.d(TAG, "💾 Saving $filename (${data.channels.size} channels)")
            }

            file.writeText(json)
            file.setLastModified(System.currentTimeMillis())

            // Verify save
            if (file.exists() && file.length() > 0) {
                Log.d(TAG, "✅ Saved $filename (${file.length()} bytes)")
            } else {
                Log.e(TAG, "❌ Failed to save $filename")
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving cache $filename: ${e.message}")
        }
    }

    private fun loadChannelCacheFromFile(context: Context, filename: String): ChannelCache? {
        return try {
            val file = File(context.filesDir, filename)
            if (file.exists() && file.length() > 10) {
                val json = file.readText()
                val type = object : TypeToken<ChannelCache>() {}.type
                val cache: ChannelCache = Gson().fromJson(json, type)
                Log.d(TAG, "📂 Loaded $filename: ${cache.channels.size} channels")
                cache
            } else {
                Log.d(TAG, "📂 $filename not found or empty")
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error loading $filename: ${e.message}")
            null
        }
    }

    /**
     * FIXED: Properly separate channels by source
     * Now handles cases where source field might be different
     */
    private fun separateChannelsBySource(channels: List<Channel>): Pair<List<Channel>, List<Channel>> {
        val bdixList = mutableListOf<Channel>()
        val aynaList = mutableListOf<Channel>()
        var unknownCount = 0

        Log.d(TAG, "🔀 Separating ${channels.size} channels by source...")

        channels.forEach { channel ->
            val source = channel.source.lowercase().trim()

            when {
                // Check for Ayna source
                source.contains("ayna") ||
                        channel.isAynaChannel() -> {
                    aynaList.add(channel)
                }
                // Check for BDIX source
                source.contains("bdix") ||
                        source.contains("other") ||
                        channel.isBdixChannel() -> {
                    bdixList.add(channel)
                }
                // Unknown source - add to BDIX by default (or you can add to both)
                else -> {
                    unknownCount++
                    // Add to BDIX as default
                    bdixList.add(channel)

                    // Log unknown sources for debugging
                    if (unknownCount <= 5) {
                        Log.w(TAG, "   Unknown source: '${channel.source}' for channel: ${channel.name}")
                    }
                }
            }
        }

        Log.d(TAG, "📊 Separation result:")
        Log.d(TAG, "   - Ayna: ${aynaList.size}")
        Log.d(TAG, "   - BDIX: ${bdixList.size}")
        Log.d(TAG, "   - Unknown (added to BDIX): $unknownCount")

        return Pair(bdixList, aynaList)
    }

    // Data classes
    data class LoadResult(
        val allChannels: List<Channel>,
        val bdixChannels: List<Channel>,
        val aynaChannels: List<Channel>,
        val isFromCache: Boolean,
        val needsBackgroundRefresh: Boolean
    )

    data class RefreshResult(
        val allChannels: List<Channel>,
        val success: Boolean
    )

    data class CacheInfo(
        val channelCount: Int,
        val lastUpdated: Long,
        val isExpired: Boolean,
        val source: String
    )

    data class CacheStatus(
        val aynaCache: CacheInfo?,
        val bdixCache: CacheInfo?,
        val combinedCache: CacheInfo?,
        val cacheExpiryMinutes: Long
    )
}