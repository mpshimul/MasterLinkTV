package com.shimulfp.bdixlivetv

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object ServerPingHelper {
    private const val TAG = "ServerPingHelper"

    // BDIX server URLs to check
    private const val REDFORCE_SERVER = "http://redforce.live/"
    private const val SERVER_99 = "http://10.99.99.99/"
    private const val SERVER_30 = "http://10.30.30.30/"

    private fun getBdixServers(): List<String> = listOf(
        REDFORCE_SERVER,
        SERVER_99,
        SERVER_30
    )

    // Cache the result
    private var lastCheckTime: Long = 0
    private var lastCheckResult: Boolean = false
    private const val CACHE_DURATION_MS = 30 * 1000L // 30 seconds cache

    // Track app foreground/background state
    private var isAppInForeground: Boolean = true

    // FIX: Use explicit type parameter and initialize with null
    private val _bdixStatus = MutableStateFlow<BdixStatus?>(null)
    val bdixStatus: StateFlow<BdixStatus?> = _bdixStatus.asStateFlow()

    sealed class BdixStatus {
        object Unknown : BdixStatus()
        object Checking : BdixStatus()
        data class Available(val reachableServers: Int, val totalServers: Int) : BdixStatus()
        object Unavailable : BdixStatus()
        object BackgroundLimited : BdixStatus()
    }

    init {
        // Initialize with Unknown status
        _bdixStatus.value = BdixStatus.Unknown
    }

    fun setAppForegroundState(isForeground: Boolean) {
        isAppInForeground = isForeground
        if (isForeground) {
            // Force check when app comes to foreground
            lastCheckTime = 0
            Log.d(TAG, "App in foreground, clearing cache for fresh check")
        }
    }

    suspend fun checkBdixServers(context: Context): Boolean = withContext(Dispatchers.IO) {
        // If app is in background, limit checks
        if (!isAppInForeground) {
            Log.d(TAG, "App in background, using cached result")
            _bdixStatus.value = BdixStatus.BackgroundLimited
            return@withContext lastCheckResult
        }

        _bdixStatus.value = BdixStatus.Checking

        // Quick network check (fast, doesn't require internet permission)
        if (!isNetworkPossiblyAvailable(context)) {
            Log.d(TAG, "Network appears unavailable")
            _bdixStatus.value = BdixStatus.Unavailable
            lastCheckResult = false
            lastCheckTime = System.currentTimeMillis()
            return@withContext false
        }

        // Check cache
        if (System.currentTimeMillis() - lastCheckTime < CACHE_DURATION_MS) {
            Log.d(TAG, "Using cached result: $lastCheckResult")
            _bdixStatus.value = if (lastCheckResult) {
                BdixStatus.Available(1, getBdixServers().size)
            } else {
                BdixStatus.Unavailable
            }
            return@withContext lastCheckResult
        }

        return@withContext try {
            val servers = getBdixServers()
            var reachableCount = 0

            // Try to ping servers with timeout
            servers.forEach { serverUrl ->
                try {
                    if (pingServerQuick(serverUrl)) {
                        reachableCount++
                        Log.d(TAG, "✅ Server reachable: $serverUrl")
                        // If at least one server is reachable, we can return early
                        if (reachableCount >= 1) {
                            // Don't break, but we have our answer
                        }
                    }
                } catch (e: Exception) {
                    // Ignore individual errors
                }
            }

            val isAnyServerReachable = reachableCount > 0

            Log.d(TAG, "BDIX check: $reachableCount/${servers.size} servers reachable")

            // Update status
            _bdixStatus.value = if (isAnyServerReachable) {
                BdixStatus.Available(reachableCount, servers.size)
            } else {
                BdixStatus.Unavailable
            }

            lastCheckResult = isAnyServerReachable
            lastCheckTime = System.currentTimeMillis()

            isAnyServerReachable
        } catch (e: Exception) {
            Log.e(TAG, "Error checking servers: ${e.message}")
            _bdixStatus.value = BdixStatus.Unavailable
            lastCheckResult = false
            lastCheckTime = System.currentTimeMillis()
            false
        }
    }

    /**
     * Less restrictive network check - doesn't require VALIDATED capability
     * which might not be available in background
     */
    private fun isNetworkPossiblyAvailable(context: Context): Boolean {
        return try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = connectivityManager.activeNetwork
            val capabilities = connectivityManager.getNetworkCapabilities(network)

            capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        } catch (e: Exception) {
            Log.w(TAG, "Could not check network: ${e.message}")
            false
        }
    }

    private suspend fun pingServerQuick(url: String): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            withTimeout(2000L) { // 2 second timeout
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 1500 // 1.5 seconds
                connection.readTimeout = 1500
                connection.requestMethod = "HEAD"
                connection.instanceFollowRedirects = false

                val responseCode = connection.responseCode
                connection.disconnect()

                // Consider 200-399 as success, also accept 301/302 redirects
                responseCode in 200..399 || responseCode in 300..302
            }
        } catch (e: Exception) {
            false
        }
    }

    fun forceImmediateCheck(context: Context) {
        if (!isAppInForeground) {
            Log.d(TAG, "Cannot force check in background")
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            lastCheckTime = 0
            Log.d(TAG, "Forced immediate check")
            checkBdixServers(context)
        }
    }

    suspend fun quickCheck(context: Context): Boolean = withContext(Dispatchers.IO) {
        if (!isNetworkPossiblyAvailable(context)) {
            return@withContext false
        }

        return@withContext try {
            val servers = getBdixServers()
            if (servers.isNotEmpty()) {
                pingServerQuick(servers.first())
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Get last known status without performing a check
     */
    fun getLastKnownStatus(): BdixStatus? = _bdixStatus.value
}