package com.shimulfp.bdixlivetv.ui.movies

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory
import com.shimulfp.bdixlivetv.viewmodel.MovieUiState
import com.shimulfp.bdixlivetv.viewmodel.MovieViewModel

@Composable
fun MoviesScreen(
    viewModel: MovieViewModel = viewModel(),
    onMovieClick: (Movie) -> Unit,
    onMovieDetailClick: ((Movie) -> Unit)? = null
) {
    val uiState by viewModel.uiState.collectAsState()
    val allMovies by viewModel.allMovies.collectAsState()
    val displayedMovies by viewModel.displayedMovies.collectAsState()
    val recentlyAdded by viewModel.recentlyAdded.collectAsState()
    val continueWatching by viewModel.continueWatching.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()
    val syncStatus by viewModel.syncStatus.collectAsState()
    val cacheInfo by viewModel.cacheInfo.collectAsState()

    // Get favorite IDs for display
    val favoriteIds = remember(favorites) {
        favorites.map { it.id }.toSet()
    }

    // Calculate movie counts by category
    val movieCounts = remember(allMovies) {
        val counts = mutableMapOf<MovieCategory, Int>()
        counts[MovieCategory.ALL] = allMovies.size
        MovieCategory.values().filter { it != MovieCategory.ALL }.forEach { category ->
            counts[category] = allMovies.count { it.category == category }
        }
        counts
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        when (uiState) {
            is MovieUiState.Loading -> {
                LoadingScreen("Loading movies...")
            }

            is MovieUiState.Error -> {
                ErrorScreen(
                    message = (uiState as MovieUiState.Error).message,
                    onRetry = { viewModel.loadMoviesSmart() }
                )
            }

            is MovieUiState.Empty -> {
                EmptyScreen("No movies found. Try refreshing.")
            }

            is MovieUiState.Success -> {
                MoviesContent(
                    allMovies = allMovies,
                    displayedMovies = displayedMovies,
                    recentlyAdded = recentlyAdded,
                    continueWatching = continueWatching,
                    favorites = favorites,
                    selectedCategory = selectedCategory,
                    movieCounts = movieCounts,
                    favoriteIds = favoriteIds,
                    isRefreshing = isRefreshing,
                    syncStatus = syncStatus,
                    cacheInfo = cacheInfo,
                    onMovieClick = onMovieClick,
                    onMovieDetailClick = onMovieDetailClick,
                    onCategorySelect = { viewModel.selectCategory(it) },
                    onRefresh = { viewModel.loadMoviesSmart() },
                    onForceRefresh = { viewModel.forceRefresh() },
                    onClearCache = { viewModel.clearCacheAndReload() }
                )
            }
        }

        // Sync status bar (always visible)
        if (syncStatus.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                SyncStatusBar(
                    status = syncStatus,
                    isRefreshing = isRefreshing,
                    onRefresh = { viewModel.loadMoviesSmart() }
                )
            }
        }
    }
}

@Composable
private fun MoviesContent(
    allMovies: List<Movie>,
    displayedMovies: List<Movie>,
    recentlyAdded: List<Movie>,
    continueWatching: List<Movie>,
    favorites: List<Movie>,
    selectedCategory: MovieCategory,
    movieCounts: Map<MovieCategory, Int>,
    favoriteIds: Set<String>,
    isRefreshing: Boolean,
    syncStatus: String,
    cacheInfo: com.shimulfp.bdixlivetv.data.MovieRepository.CacheInfo?,
    onMovieClick: (Movie) -> Unit,
    onMovieDetailClick: ((Movie) -> Unit)?,
    onCategorySelect: (MovieCategory) -> Unit,
    onRefresh: () -> Unit,
    onForceRefresh: () -> Unit,
    onClearCache: () -> Unit
) {
    var showSyncMenu by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Sync Menu FAB
        item {
            if (!isRefreshing) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 16.dp, top = 40.dp),
                    contentAlignment = Alignment.TopEnd
                ) {
                    FloatingActionButton(
                        onClick = { showSyncMenu = !showSyncMenu },
                        modifier = Modifier.size(48.dp),
                        containerColor = Color(0xFF2A2A2A)
                    ) {
                        Icon(
                            Icons.Filled.Sync,
                            contentDescription = "Sync",
                            tint = Color.White
                        )
                    }

                    // Sync options dropdown
                    if (showSyncMenu) {
                        SyncOptionsMenu(
                            onRefresh = {
                                onRefresh()
                                showSyncMenu = false
                            },
                            onForceRefresh = {
                                onForceRefresh()
                                showSyncMenu = false
                            },
                            onClearCache = {
                                onClearCache()
                                showSyncMenu = false
                            },
                            onDismiss = { showSyncMenu = false }
                        )
                    }
                }
            }
        }

        // Hero Banner
        item {
            MovieHeroBanner(
                movie = recentlyAdded.firstOrNull(),
                onPlayClick = { recentlyAdded.firstOrNull()?.let(onMovieClick) },
                onInfoClick = onMovieDetailClick?.let { { recentlyAdded.firstOrNull()?.let(it) } }
            )
        }

        // Category Chips
        item {
            CategoryChips(
                selectedCategory = selectedCategory,
                onCategorySelect = onCategorySelect,
                movieCounts = movieCounts
            )
        }

        // Status info
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${displayedMovies.size} movies",
                    color = Color.Gray,
                    fontSize = 12.sp
                )

                cacheInfo?.let {
                    val statusColor = if (it.isExpired) Color.Yellow else Color.Green
                    Text(
                        text = "${it.ageMinutes}m old",
                        color = statusColor,
                        fontSize = 10.sp
                    )
                }

                IconButton(
                    onClick = onRefresh,
                    enabled = !isRefreshing
                ) {
                    Icon(
                        Icons.Filled.Refresh,
                        contentDescription = "Refresh",
                        tint = if (isRefreshing) Color.Gray else Color.White
                    )
                }
            }
        }

        // Continue Watching
        if (continueWatching.isNotEmpty()) {
            item {
                MovieRow(
                    title = "▶️ Continue Watching",
                    movies = continueWatching,
                    onMovieClick = onMovieClick,
                    showProgress = true,
                    favoriteIds = favoriteIds,
                    accentColor = Color.Yellow
                )
            }
        }

        // Favorites
        if (favorites.isNotEmpty()) {
            item {
                MovieRow(
                    title = "❤️ My Favorites",
                    movies = favorites,
                    onMovieClick = onMovieClick,
                    favoriteIds = favoriteIds,
                    accentColor = Color.Red
                )
            }
        }

        // Recently Added
        if (selectedCategory == MovieCategory.ALL && recentlyAdded.isNotEmpty()) {
            item {
                MovieRow(
                    title = "🆕 Recently Added",
                    movies = recentlyAdded,
                    onMovieClick = onMovieClick,
                    favoriteIds = favoriteIds,
                    accentColor = Color.Green
                )
            }
        }

        // Category-specific rows
        if (selectedCategory == MovieCategory.ALL) {
            MovieCategory.values()
                .filter { it != MovieCategory.ALL }
                .forEach { category ->
                    val categoryMovies = allMovies.filter { it.category == category }
                    if (categoryMovies.isNotEmpty()) {
                        item {
                            MovieRow(
                                title = category.displayName,
                                movies = categoryMovies.take(20),
                                onMovieClick = onMovieClick,
                                onSeeAllClick = { onCategorySelect(category) },
                                favoriteIds = favoriteIds
                            )
                        }
                    }
                }
        } else {
            // Filtered movies by selected category
            item {
                MovieRow(
                    title = selectedCategory.displayName,
                    movies = displayedMovies,
                    onMovieClick = onMovieClick,
                    favoriteIds = favoriteIds
                )
            }
        }
    }
}

@Composable
private fun SyncStatusBar(
    status: String,
    isRefreshing: Boolean,
    onRefresh: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xAA1A1A1A))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isRefreshing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(14.dp),
                    strokeWidth = 2.dp,
                    color = Color.Green
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "Syncing...",
                    color = Color.White,
                    fontSize = 12.sp
                )
            } else {
                Icon(
                    Icons.Filled.Info,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    status,
                    color = Color(0xFFAAAAAA),
                    fontSize = 11.sp,
                    maxLines = 2
                )
            }
        }
    }
}

@Composable
private fun SyncOptionsMenu(
    onRefresh: () -> Unit,
    onForceRefresh: () -> Unit,
    onClearCache: () -> Unit,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(200.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
    ) {
        Column {
            SyncMenuItem(
                icon = Icons.Filled.Refresh,
                text = "Refresh",
                description = "Check for updates",
                onClick = onRefresh
            )

            SyncMenuItem(
                icon = Icons.Filled.Sync,
                text = "Force Refresh",
                description = "Scrape fresh & upload",
                onClick = onForceRefresh
            )

            SyncMenuItem(
                icon = Icons.Filled.Delete,
                text = "Clear Cache",
                description = "Delete local data",
                onClick = onClearCache
            )
        }
    }
}

@Composable
private fun SyncMenuItem(
    icon: ImageVector,
    text: String,
    description: String,
    onClick: () -> Unit
) {
    TextButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text, fontSize = 14.sp, color = Color.White)
                Text(description, fontSize = 10.sp, color = Color.Gray)
            }
        }
    }
}