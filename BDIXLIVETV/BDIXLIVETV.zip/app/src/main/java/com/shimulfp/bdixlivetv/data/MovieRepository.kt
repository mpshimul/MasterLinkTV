package com.shimulfp.bdixlivetv.data

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.shimulfp.bdixlivetv.FirebaseManager
import com.shimulfp.bdixlivetv.GitHubDataManager
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.concurrent.TimeUnit

class MovieRepository(private val context: Context) {

    private val gson = Gson()
    private val cacheFile = File(context.filesDir, "movies_cache.json")
    private val favoritesFile = File(context.filesDir, "movie_favorites.json")
    private val watchHistoryFile = File(context.filesDir, "movie_watch_history.json")
    private val syncStatusFile = File(context.filesDir, "movie_sync_status.json")
    private val stopFlagFile = File(context.filesDir, "stop_scraping.flag")

    // Synchronization primitives to prevent race conditions
    private val loadMutex = Mutex()
    private val refreshMutex = Mutex()

    // Cache state tracking
    @Volatile
    private var isCurrentlyLoading = false
    @Volatile
    private var lastLoadTime = 0L
    @Volatile
    private var cachedMovies: List<Movie>? = null

    @Volatile
    private var isScrapingInProgress = false

    companion object {
        private const val TAG = "MovieRepository"
        private const val FRESHNESS_THRESHOLD_MINUTES = 120L // 2 hours
        private const val MAX_RETRY_ATTEMPTS = 3
        private const val MIN_LOAD_INTERVAL_MS = 3000L // 3 seconds between loads
        private const val BACKGROUND_REFRESH_DELAY_MS = 30 * 60 * 1000L // 30 minutes delay

        @Volatile
        private var instance: MovieRepository? = null
        private val instanceMutex = Mutex()

        suspend fun getInstance(context: Context): MovieRepository {
            return instance ?: instanceMutex.withLock {
                instance ?: MovieRepository(context.applicationContext).also {
                    Log.d(TAG, "✅ Created new MovieRepository instance")
                    instance = it
                }
            }
        }
    }

    // ============ TOKEN MANAGEMENT ============

    /**
     * Get GitHub token from multiple possible sources
     */
    // ============ TOKEN MANAGEMENT ============

    /**
     * Get GitHub token from multiple possible sources
     */
    private fun getGitHubToken(): String {
        return try {
            // 1. Try GitHubDataManager directly (FIXED: No reflection needed)
            val fromGitHubManager = GitHubDataManager.getToken()
            if (fromGitHubManager.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from GitHubDataManager")
                return fromGitHubManager
            }

            // 2. Try Firebase Remote Config
            val firebaseManager = FirebaseManager(context)
            val fromFirebase = firebaseManager.getGitHubToken()
            if (fromFirebase.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from Firebase")
                // Initialize Manager if we found a token so it remembers it next time
                if (!GitHubDataManager.isInitialized()) {
                    GitHubDataManager.initialize(fromFirebase)
                }
                return fromFirebase
            }

            // 3. Try SharedPreferences (if you store it there)
            val fromPrefs = tryGetTokenFromSharedPrefs()
            if (fromPrefs.isNotEmpty()) {
                Log.d(TAG, "🔑 Got token from SharedPreferences")
                return fromPrefs
            }

            Log.d(TAG, "⚠️ No GitHub token available from any source")
            ""
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error getting GitHub token: ${e.message}")
            ""
        }
    }

    // DELETE the function: tryGetTokenFromGitHubDataManager() - It is no longer needed
    // DELETE the function: tryAlternativeTokenAccess() - Optional, but keeping it clean is better

    /**
     * Try to get token from GitHubDataManager using reflection
     */
    private fun tryGetTokenFromGitHubDataManager(): String {
        return try {
            // Check if GitHubDataManager is initialized
            val isInitializedMethod = GitHubDataManager::class.java.getDeclaredMethod("isInitialized")
            val isInitialized = isInitializedMethod.invoke(null) as? Boolean ?: false

            if (isInitialized) {
                // Try to access the token field via reflection
                val tokenField = GitHubDataManager::class.java.getDeclaredField("githubToken")
                tokenField.isAccessible = true
                val token = tokenField.get(null) as? String ?: ""
                token
            } else {
                ""
            }
        } catch (e: Exception) {
            // Reflection failed, try alternative approach
            Log.d(TAG, "⚠️ Could not get token via reflection: ${e.message}")
            tryAlternativeTokenAccess()
        }
    }

    /**
     * Alternative method to get token
     */
    private fun tryAlternativeTokenAccess(): String {
        return try {
            // Check if we have a local token file
            val tokenFile = File(context.filesDir, "github_token.txt")
            if (tokenFile.exists()) {
                val token = tokenFile.readText().trim()
                if (token.isNotEmpty()) {
                    return token
                }
            }

            // Check in SharedPreferences
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.getString("github_token", "") ?: ""
        } catch (e: Exception) {
            Log.e(TAG, "❌ Alternative token access failed: ${e.message}")
            ""
        }
    }

    /**
     * Try to get token from SharedPreferences
     */
    private fun tryGetTokenFromSharedPrefs(): String {
        return try {
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.getString("github_token", "") ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Save token for future use
     */
    private fun saveTokenLocally(token: String) {
        try {
            // Save to SharedPreferences
            val prefs = context.getSharedPreferences("github_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("github_token", token).apply()

            // Also save to file for backup
            val tokenFile = File(context.filesDir, "github_token.txt")
            tokenFile.writeText(token)

            Log.d(TAG, "💾 Saved GitHub token locally")
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error saving token locally: ${e.message}")
        }
    }

    // ============ SCRAPING CONTROL ============

    /**
     * Create stop flag to signal Python scraper to stop
     */
    private fun createStopFlag() {
        try {
            stopFlagFile.writeText("STOP")
            Log.d(TAG, "🛑 Created stop flag for Python scraper")
        } catch (e: Exception) {
            Log.e(TAG, "Error creating stop flag: ${e.message}")
        }
    }

    /**
     * Remove stop flag
     */
    private fun removeStopFlag() {
        try {
            if (stopFlagFile.exists()) {
                stopFlagFile.delete()
                Log.d(TAG, "🧹 Removed stop flag")
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    /**
     * Check if stop flag exists
     */
    private fun shouldStopScraping(): Boolean {
        return try {
            stopFlagFile.exists()
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Stop all scraping immediately
     */
    private fun stopAllScraping() {
        createStopFlag()
        isScrapingInProgress = false
        Log.d(TAG, "🚨 FORCE STOPPED all scraping processes")
    }

    // ============ ULTRA-SIMPLE GITHUB-FIRST LOADING ============

    suspend fun getMoviesSmart(): List<Movie> = withContext(Dispatchers.IO) {
        Log.d(TAG, "🚀 ULTRA-SIMPLE GITHUB-FIRST LOADING")

        // Clean up any old stop flags
        removeStopFlag()

        // STEP 1: Check if we already have cached movies in memory (fastest)
        if (shouldUseCachedMovies()) {
            Log.d(TAG, "⚡ Using cached in-memory movies (${cachedMovies?.size ?: 0} items)")
            return@withContext cachedMovies ?: emptyList()
        }

        // STEP 2: Try to load from local GitHub cache file immediately
        val localFile = File(context.filesDir, "movies_cache.json")
        if (localFile.exists() && localFile.length() > 100000) { // At least 100KB
            Log.d(TAG, "📥 Found local GitHub cache file (${localFile.length()} bytes)")

            try {
                val content = localFile.readText()
                val movies = parseMoviesFromJson(content)

                if (movies.isNotEmpty()) {
                    Log.d(TAG, "✅ Loaded ${movies.size} movies from local GitHub cache")

                    // STOP any ongoing scraping since we have data
                    stopAllScraping()

                    // Update cache state
                    cachedMovies = movies
                    lastLoadTime = System.currentTimeMillis()

                    // Save sync status
                    saveSyncStatus("github_cache", movies.size)

                    return@withContext movies
                } else {
                    Log.w(TAG, "⚠️ Local cache file exists but parsing returned empty")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Error loading from local cache: ${e.message}")
            }
        }

        // STEP 3: Get GitHub token from available sources
        val githubToken = getGitHubToken()

        if (githubToken.isNotEmpty()) {
            Log.d(TAG, "🔑 GitHub token available, trying to download...")

            // Save token locally for future use
            saveTokenLocally(githubToken)

            try {
                // Initialize GitHubDataManager if not already
                if (!GitHubDataManager.isInitialized()) {
                    GitHubDataManager.initialize(githubToken)
                }

                val movies = GitHubDataManager.downloadMovies(context)

                if (movies.isNotEmpty()) {
                    Log.d(TAG, "✅ Downloaded ${movies.size} movies from GitHub")

                    // STOP any ongoing scraping immediately
                    stopAllScraping()

                    // Update cache state
                    cachedMovies = movies
                    lastLoadTime = System.currentTimeMillis()

                    // Save to cache
                    saveToCache(movies)
                    saveSyncStatus("github_download", movies.size)

                    return@withContext movies
                } else {
                    Log.w(TAG, "⚠️ GitHub download returned empty")
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub download error: ${e.message}")
            }
        } else {
            Log.d(TAG, "⚠️ No GitHub token available from any source")
        }

        // STEP 4: If GitHub fails, try existing cache file (old method)
        val cached = loadFromCache()
        if (cached.isNotEmpty()) {
            Log.d(TAG, "✅ Loaded ${cached.size} movies from existing cache")

            // STOP any ongoing scraping
            stopAllScraping()

            cachedMovies = cached
            lastLoadTime = System.currentTimeMillis()
            saveSyncStatus("existing_cache", cached.size)

            return@withContext cached
        }

        // STEP 5: Only scrape as LAST RESORT
        Log.d(TAG, "⚠️ All other sources failed, scraping as last resort...")

        return@withContext loadMutex.withLock {
            // Double-check inside mutex
            if (cachedMovies != null && shouldUseCachedMovies()) {
                stopAllScraping()
                return@withLock cachedMovies ?: emptyList()
            }

            try {
                isCurrentlyLoading = true

                val movies = scrapeFreshMovies()
                if (movies.isNotEmpty()) {
                    Log.d(TAG, "✅ Scraped ${movies.size} movies")

                    cachedMovies = movies
                    lastLoadTime = System.currentTimeMillis()
                    saveToCache(movies)
                    saveSyncStatus("scraped", movies.size)

                    // Try to upload to GitHub if we get a token later
                    if (githubToken.isNotEmpty()) {
                        try {
                            GitHubDataManager.initialize(githubToken)
                            GitHubDataManager.uploadMovies(context, movies)
                            Log.d(TAG, "📤 Uploaded scraped movies to GitHub")
                        } catch (e: Exception) {
                            Log.e(TAG, "⚠️ Failed to upload to GitHub: ${e.message}")
                        }
                    }

                    return@withLock movies
                }

                return@withLock emptyList()
            } catch (e: Exception) {
                Log.e(TAG, "❌ Scraping error: ${e.message}")
                return@withLock emptyList()
            } finally {
                isCurrentlyLoading = false
            }
        }
    }

    /**
     * Check if we should use cached movies
     */
    private fun shouldUseCachedMovies(): Boolean {
        if (cachedMovies == null) return false

        val timeSinceLastLoad = System.currentTimeMillis() - lastLoadTime
        val isRecent = timeSinceLastLoad < MIN_LOAD_INTERVAL_MS

        return isRecent && cachedMovies!!.isNotEmpty()
    }

    /**
     * Try GitHub with retry logic
     */
    private suspend fun tryGitHubWithRetry(githubToken: String): List<Movie> = withContext(Dispatchers.IO) {
        var attempt = 0
        while (attempt < MAX_RETRY_ATTEMPTS) {
            try {
                attempt++
                Log.d(TAG, "📥 Attempt $attempt: Trying GitHub...")

                if (!GitHubDataManager.isInitialized()) {
                    GitHubDataManager.initialize(githubToken)
                }

                // Download movies from GitHub
                val movies = GitHubDataManager.downloadMovies(context)

                if (movies.isNotEmpty()) {
                    Log.d(TAG, "✅ Successfully downloaded ${movies.size} movies from GitHub")
                    return@withContext movies
                } else {
                    Log.d(TAG, "⚠️ No movies downloaded from GitHub")
                    // Don't return empty list yet, try again
                }

            } catch (e: Exception) {
                Log.e(TAG, "❌ GitHub attempt $attempt failed: ${e.message}")
                if (attempt == MAX_RETRY_ATTEMPTS) {
                    return@withContext emptyList()
                }
                delay(1000L * attempt) // Exponential backoff
            }
        }
        return@withContext emptyList()
    }

    /**
     * Download movies from GitHub with proper synchronization
     */
    private suspend fun downloadMoviesFromGitHub(githubToken: String): List<Movie> = withContext(Dispatchers.IO) {
        return@withContext try {
            Log.d(TAG, "📥 Downloading movies from GitHub...")

            // Initialize if not already done
            if (!GitHubDataManager.isInitialized()) {
                GitHubDataManager.initialize(githubToken)
            }

            // Use GitHubDataManager's download method
            val movies = GitHubDataManager.downloadMovies(context)

            if (movies.isNotEmpty()) {
                // Save locally for future use
                saveToCache(movies)
                Log.d(TAG, "✅ Downloaded ${movies.size} movies from GitHub")
                movies
            } else {
                Log.w(TAG, "⚠️ No movies downloaded from GitHub")
                emptyList()
            }

        } catch (e: Exception) {
            Log.e(TAG, "❌ GitHub movie download error: ${e.message}")
            emptyList()
        }
    }

    /**
     * Parse movies from JSON
     */
    private fun parseMoviesFromJson(jsonString: String): List<Movie> {
        return try {
            val type = object : TypeToken<List<Movie>>() {}.type
            gson.fromJson<List<Movie>>(jsonString, type) ?: emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error parsing movies JSON: ${e.message}")
            emptyList()
        }
    }

    /**
     * Check if we should refresh in background
     */
    private fun shouldRefreshInBackground(source: String): Boolean {
        return when (source) {
            "github" -> {
                // If we got from GitHub but it was stale, refresh
                val cacheAge = getCacheAgeMinutes()
                cacheAge > FRESHNESS_THRESHOLD_MINUTES
            }
            "cache" -> {
                // If cache is old, refresh
                val cacheAge = getCacheAgeMinutes()
                cacheAge > FRESHNESS_THRESHOLD_MINUTES
            }
            else -> true // Always refresh if scraped
        }
    }

    /**
     * Start background refresh
     */
    private fun startBackgroundRefresh(githubToken: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Wait to not block immediate loading
                delay(BACKGROUND_REFRESH_DELAY_MS)

                Log.d(TAG, "🔄 Starting background refresh...")

                val movies = scrapeFreshMovies()
                if (movies.isNotEmpty()) {
                    Log.d(TAG, "✅ Background scraped ${movies.size} movies")

                    // Update cache
                    saveToCache(movies)
                    cachedMovies = movies
                    lastLoadTime = System.currentTimeMillis()

                    // Try to upload to GitHub if we have token
                    if (githubToken.isNotEmpty()) {
                        try {
                            if (!GitHubDataManager.isInitialized()) {
                                GitHubDataManager.initialize(githubToken)
                            }
                            val uploaded = GitHubDataManager.uploadMovies(context, movies)
                            if (uploaded) {
                                Log.d(TAG, "✅ Background upload to GitHub successful")
                                saveSyncStatus("background_uploaded", movies.size)
                            } else {
                                Log.w(TAG, "⚠️ Background upload failed")
                                saveSyncStatus("background_failed", movies.size)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "❌ Background upload error: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Background refresh error: ${e.message}")
            }
        }
    }

    /**
     * Scrape fresh movies - WITH STOP CHECKING
     */
    private suspend fun scrapeFreshMovies(): List<Movie> = withContext(Dispatchers.IO) {
        return@withContext try {
            // Check if scraping should stop before starting
            if (shouldStopScraping()) {
                Log.d(TAG, "🛑 Scraping cancelled before start (GitHub data available)")
                return@withContext emptyList()
            }

            // Check if scraping is already in progress
            if (isScrapingInProgress) {
                Log.d(TAG, "⚠️ Scraping already in progress, skipping")
                return@withContext emptyList()
            }

            isScrapingInProgress = true
            Log.d(TAG, "🔄 Scraping fresh movies...")

            val movies = MovieScraper.scrapeAllMovies(context, maxPerServer = 400)

            // Check if we should stop after scraping
            if (shouldStopScraping()) {
                Log.d(TAG, "🛑 Scraping results discarded (GitHub data available)")
                return@withContext emptyList()
            }

            if (movies.isNotEmpty()) {
                saveToCache(movies)
                movies
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Scraping error: ${e.message}")
            emptyList()
        } finally {
            isScrapingInProgress = false
        }
    }

    // ============ PUBLIC API ============

    /**
     * Get all movies with smart loading
     */
    suspend fun getAllMovies(): List<Movie> {
        return getMoviesSmart()
    }

    /**
     * Force refresh (scrape fresh and upload to GitHub)
     */
    suspend fun forceRefresh(): List<Movie> = withContext(Dispatchers.IO) {
        return@withContext refreshMutex.withLock {
            Log.d(TAG, "🔄 FORCE REFRESH REQUESTED")

            // Clean stop flag before force refresh
            removeStopFlag()

            try {
                // Get GitHub token first
                val githubToken = getGitHubToken()

                // 1. Scrape fresh
                val movies = scrapeFreshMovies()

                if (movies.isEmpty()) {
                    Log.w(TAG, "⚠️ Force refresh: No movies scraped")
                    return@withLock emptyList()
                }

                Log.d(TAG, "✅ Force refresh: Scraped ${movies.size} movies")

                // Update cache
                cachedMovies = movies
                lastLoadTime = System.currentTimeMillis()

                // 2. Try to upload to GitHub if we have token
                if (githubToken.isNotEmpty()) {
                    try {
                        if (!GitHubDataManager.isInitialized()) {
                            GitHubDataManager.initialize(githubToken)
                        }
                        val uploaded = GitHubDataManager.uploadMovies(context, movies)

                        if (uploaded) {
                            Log.d(TAG, "✅ Force refresh: Uploaded to GitHub")
                            saveSyncStatus("force_refresh_uploaded", movies.size)
                        } else {
                            Log.w(TAG, "⚠️ Force refresh: Upload failed")
                            saveSyncStatus("force_refresh_failed", movies.size)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "❌ Force refresh upload error: ${e.message}")
                        saveSyncStatus("force_refresh_error", movies.size)
                    }
                } else {
                    Log.w(TAG, "⚠️ Force refresh: No GitHub token")
                    saveSyncStatus("force_refresh_no_token", movies.size)
                }

                movies

            } catch (e: Exception) {
                Log.e(TAG, "❌ Force refresh error: ${e.message}")
                emptyList()
            }
        }
    }

    /**
     * Get movies by category
     */
    suspend fun getMoviesByCategory(category: MovieCategory): List<Movie> {
        val allMovies = getAllMovies()
        return if (category == MovieCategory.ALL) {
            allMovies
        } else {
            allMovies.filter { it.category == category }
        }
    }

    /**
     * Search movies
     */
    suspend fun searchMovies(query: String): List<Movie> {
        if (query.isBlank()) return emptyList()

        val allMovies = getAllMovies()
        val queryLower = query.lowercase()

        return allMovies.filter { movie ->
            movie.title.lowercase().contains(queryLower) ||
                    movie.originalTitle.lowercase().contains(queryLower) ||
                    movie.genres.any { it.lowercase().contains(queryLower) }
        }
    }

    /**
     * Get recently added movies
     */
    suspend fun getRecentlyAdded(limit: Int = 20): List<Movie> {
        return getAllMovies()
            .sortedByDescending { it.folderModifiedTimestamp }
            .take(limit)
    }

    /**
     * Get movies by year
     */
    suspend fun getMoviesByYear(year: String): List<Movie> {
        return getAllMovies().filter { it.year == year }
    }

    /**
     * Clear cache and force reload
     */
    suspend fun clearCacheAndReload(): List<Movie> {
        clearCache()
        cachedMovies = null
        lastLoadTime = 0L
        removeStopFlag() // Clean stop flag
        return getMoviesSmart()
    }

    /**
     * Stop any ongoing operations (call when leaving screen)
     */
    fun stopAllOperations() {
        stopAllScraping()
        Log.d(TAG, "🛑 All movie operations stopped")
    }

    // ============ CACHE MANAGEMENT ============

    private fun getCacheAgeMinutes(): Long {
        return if (cacheFile.exists()) {
            (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000)
        } else {
            -1L
        }
    }

    private fun loadFromCache(): List<Movie> {
        return try {
            if (cacheFile.exists()) {
                val json = cacheFile.readText()
                if (json.isBlank() || json == "[]" || json == "{}") {
                    Log.w(TAG, "Cache file is empty or invalid")
                    return emptyList()
                }

                val type = object : TypeToken<List<Movie>>() {}.type
                val movies = gson.fromJson<List<Movie>>(json, type)

                if (movies.isNullOrEmpty()) {
                    Log.w(TAG, "Cache parsed but empty")
                    emptyList()
                } else {
                    Log.d(TAG, "Loaded ${movies.size} movies from cache")
                    movies
                }
            } else {
                Log.d(TAG, "Cache file not found")
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cache load error: ${e.message}")
            emptyList()
        }
    }

    private fun saveToCache(movies: List<Movie>) {
        try {
            val json = gson.toJson(movies)
            cacheFile.writeText(json)
            cacheFile.setLastModified(System.currentTimeMillis())

            Log.d(TAG, "💾 Saved ${movies.size} movies to cache (${cacheFile.length()} bytes)")
        } catch (e: Exception) {
            Log.e(TAG, "Cache save error: ${e.message}")
        }
    }

    private fun saveSyncStatus(syncType: String, movieCount: Int) {
        try {
            val syncData = mapOf(
                "last_sync_time" to System.currentTimeMillis(),
                "last_sync_type" to syncType,
                "movie_count" to movieCount,
                "cache_file_size" to cacheFile.length(),
                "cache_last_modified" to cacheFile.lastModified(),
                "timestamp" to System.currentTimeMillis()
            )
            syncStatusFile.writeText(gson.toJson(syncData))
            Log.d(TAG, "💾 Saved sync status: $syncType ($movieCount movies)")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving sync status: ${e.message}")
        }
    }

    fun clearCache() {
        try {
            if (cacheFile.exists()) {
                cacheFile.delete()
                cachedMovies = null
                lastLoadTime = 0L
                Log.d(TAG, "Cache cleared")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cache clear error: ${e.message}")
        }
    }

    fun getCacheInfo(): CacheInfo {
        return if (cacheFile.exists()) {
            val ageMinutes = getCacheAgeMinutes()
            val sizeKb = cacheFile.length() / 1024
            CacheInfo(
                exists = true,
                ageMinutes = ageMinutes,
                sizeKb = sizeKb,
                isExpired = ageMinutes > FRESHNESS_THRESHOLD_MINUTES
            )
        } else {
            CacheInfo(exists = false, ageMinutes = 0, sizeKb = 0, isExpired = true)
        }
    }

    fun getSyncInfo(): SyncInfo {
        return try {
            if (syncStatusFile.exists()) {
                val json = syncStatusFile.readText()
                val type = object : TypeToken<Map<String, Any>>() {}.type
                val data = gson.fromJson<Map<String, Any>>(json, type)

                val lastSyncTime = (data["last_sync_time"] as? Double)?.toLong() ?: 0L
                val syncType = data["last_sync_type"] as? String ?: "unknown"
                val movieCount = (data["movie_count"] as? Double)?.toInt() ?: 0

                SyncInfo(
                    lastSyncTime = lastSyncTime,
                    syncType = syncType,
                    movieCount = movieCount
                )
            } else {
                SyncInfo()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading sync info: ${e.message}")
            SyncInfo()
        }
    }

    // ============ FAVORITES ============

    fun getFavoriteIds(): Set<String> {
        return try {
            if (favoritesFile.exists()) {
                val type = object : TypeToken<Set<String>>() {}.type
                gson.fromJson<Set<String>>(favoritesFile.readText(), type) ?: emptySet()
            } else {
                emptySet()
            }
        } catch (e: Exception) {
            emptySet()
        }
    }

    fun toggleFavorite(movieId: String): Boolean {
        synchronized(favoritesFile) {
            val favorites = getFavoriteIds().toMutableSet()
            val isNowFavorite = if (favorites.contains(movieId)) {
                favorites.remove(movieId)
                false
            } else {
                favorites.add(movieId)
                true
            }
            favoritesFile.writeText(gson.toJson(favorites))
            return isNowFavorite
        }
    }

    fun isFavorite(movieId: String): Boolean {
        return getFavoriteIds().contains(movieId)
    }

    suspend fun getFavoriteMovies(): List<Movie> {
        val favoriteIds = getFavoriteIds()
        return getAllMovies().filter { it.id in favoriteIds }
    }

    // ============ WATCH HISTORY ============

    fun saveWatchProgress(movieId: String, progress: Float, position: Long) {
        synchronized(watchHistoryFile) {
            val history = getWatchHistory().toMutableMap()
            history[movieId] = WatchRecord(progress, position, System.currentTimeMillis())
            watchHistoryFile.writeText(gson.toJson(history))
        }
    }

    fun getWatchProgress(movieId: String): WatchRecord? {
        return getWatchHistory()[movieId]
    }

    private fun getWatchHistory(): Map<String, WatchRecord> {
        return try {
            if (watchHistoryFile.exists()) {
                val type = object : TypeToken<Map<String, WatchRecord>>() {}.type
                gson.fromJson<Map<String, WatchRecord>>(watchHistoryFile.readText(), type) ?: emptyMap()
            } else {
                emptyMap()
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    suspend fun getContinueWatching(): List<Movie> {
        val history = getWatchHistory()
        val allMovies = getAllMovies()

        return allMovies
            .filter { movie ->
                val record = history[movie.id]
                record != null && record.progress > 0.05f && record.progress < 0.95f
            }
            .sortedByDescending { history[it.id]?.timestamp ?: 0 }
            .take(10)
    }

    suspend fun getRecentlyWatched(limit: Int = 10): List<Movie> {
        val history = getWatchHistory()
        val allMovies = getAllMovies()

        return allMovies
            .filter { movie -> history.containsKey(movie.id) }
            .sortedByDescending { history[it.id]?.timestamp ?: 0 }
            .take(limit)
    }

    // ============ DATA CLASSES ============

    data class WatchRecord(
        val progress: Float,
        val position: Long,
        val timestamp: Long
    )

    data class CacheInfo(
        val exists: Boolean,
        val ageMinutes: Long,
        val sizeKb: Long,
        val isExpired: Boolean
    ) {
        fun getStatus(): String {
            return if (!exists) {
                "No cache"
            } else if (isExpired) {
                "${ageMinutes}m old (stale)"
            } else {
                "${ageMinutes}m old (fresh)"
            }
        }
    }

    data class SyncInfo(
        val lastSyncTime: Long = 0L,
        val syncType: String = "never",
        val movieCount: Int = 0
    ) {
        fun getStatus(): String {
            if (lastSyncTime == 0L) return "Never synced"

            val hoursAgo = (System.currentTimeMillis() - lastSyncTime) / (1000 * 60 * 60)
            val minutesAgo = (System.currentTimeMillis() - lastSyncTime) / (1000 * 60)

            return when {
                hoursAgo < 1 -> "${minutesAgo}m ago"
                hoursAgo < 24 -> "${hoursAgo}h ago"
                else -> "${hoursAgo / 24}d ago"
            }
        }

        fun getSource(): String {
            return when (syncType) {
                "github" -> "GitHub"
                "github_cache" -> "GitHub Cache"
                "github_download" -> "GitHub Download"
                "cache" -> "Local Cache"
                "scraped" -> "Fresh Scrape"
                "force_refresh_uploaded" -> "Force Refresh & Uploaded"
                "background_uploaded" -> "Background Upload"
                else -> syncType.replace("_", " ").replaceFirstChar { it.uppercase() }
            }
        }
    }
}