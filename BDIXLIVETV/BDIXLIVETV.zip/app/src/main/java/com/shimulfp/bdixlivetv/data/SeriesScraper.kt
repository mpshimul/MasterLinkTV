package com.shimulfp.bdixlivetv.data

import android.content.Context
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.shimulfp.bdixlivetv.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SeriesScraper {

    private const val TAG = "SeriesScraper"
    private val gson = Gson()

    /**
     * Ensure Python is started
     */
    private fun ensurePythonStarted(context: Context) {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(context))
        }
    }

    /**
     * Scrape all configured BDIX series servers
     */
    suspend fun scrapeAllSeries(
        context: Context,
        maxPerServer: Int = 250
    ): List<Series> {
        return withContext(Dispatchers.IO) {
            try {
                ensurePythonStarted(context)

                val py = Python.getInstance()
                val module = py.getModule("series_scraper")

                Log.d(TAG, "🚀 Starting series scrape (max per server: $maxPerServer)")

                val result = module.callAttr("scrape_all_series", maxPerServer).toString()

                val seriesList = parseSeriesFromJson(result)

                Log.d(TAG, "✅ Scraped ${seriesList.size} series successfully")

                seriesList

            } catch (e: Exception) {
                Log.e(TAG, "❌ Scrape error: ${e.message}", e)
                emptyList()
            }
        }
    }

    /**
     * Scrape a single series server
     */
    suspend fun scrapeSingleServer(
        context: Context,
        baseUrl: String,
        category: String = "KOREAN",
        language: String = "Korean",
        serverName: String = "BDIX",
        maxSeries: Int = 250
    ): List<Series> {
        return withContext(Dispatchers.IO) {
            try {
                ensurePythonStarted(context)

                val py = Python.getInstance()
                val module = py.getModule("series_scraper")

                val result = module.callAttr(
                    "scrape_single_server",
                    baseUrl, category, language, serverName, maxSeries
                ).toString()

                parseSeriesFromJson(result)

            } catch (e: Exception) {
                Log.e(TAG, "❌ Single server scrape error: ${e.message}", e)
                emptyList()
            }
        }
    }

    /**
     * Search series by title
     */
    suspend fun searchSeries(
        context: Context,
        query: String,
        maxResults: Int = 50
    ): List<Series> {
        return withContext(Dispatchers.IO) {
            try {
                ensurePythonStarted(context)

                val py = Python.getInstance()
                val module = py.getModule("series_scraper")

                val result = module.callAttr("search_series", query, maxResults).toString()

                parseSeriesFromJson(result)

            } catch (e: Exception) {
                Log.e(TAG, "❌ Search error: ${e.message}", e)
                emptyList()
            }
        }
    }

    /**
     * Parse JSON response to Series list
     */
    private fun parseSeriesFromJson(json: String): List<Series> {
        return try {
            // Check for error response
            if (json.contains("\"error\"") && !json.startsWith("[") && !json.startsWith("{")) {
                val errorMap = gson.fromJson(json, Map::class.java)
                Log.e(TAG, "API error: ${errorMap["error"]}")
                return emptyList()
            }

            // Handle parallel scraper format: { count: X, series: [...] }
            if (json.trim().startsWith("{")) {
                try {
                    val parallelResult = gson.fromJson(json, Map::class.java)
                    val seriesArray = parallelResult["series"]
                    if (seriesArray is List<*>) {
                        val seriesJson = gson.toJson(seriesArray)
                        val type = object : TypeToken<List<SeriesJsonModel>>() {}.type
                        val seriesJsonList: List<SeriesJsonModel> = gson.fromJson(seriesJson, type) ?: emptyList()
                        return seriesJsonList.map { it.toSeries() }
                    }
                } catch (e: Exception) {
                    // Fall through to array format
                    Log.d(TAG, "Not parallel format, trying array format")
                }
            }

            // Direct array format: [...]
            val type = object : TypeToken<List<SeriesJsonModel>>() {}.type
            val seriesJsonList: List<SeriesJsonModel> = gson.fromJson(json, type) ?: emptyList()

            seriesJsonList.map { it.toSeries() }

        } catch (e: Exception) {
            Log.e(TAG, "JSON parse error: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Internal JSON model matching Python output
     */
    private data class SeriesJsonModel(
        val id: String = "",
        val title: String = "",
        val originalTitle: String = "",
        val year: String = "",
        val quality: String = "HD",
        val poster: String = "",
        val backdrop: String = "",
        val description: String = "",
        val genres: List<String> = emptyList(),
        val cast: List<String> = emptyList(),
        val director: String = "",
        val language: String = "",
        val seasons: List<SeasonJson> = emptyList(),
        val subtitles: List<SubtitleJson> = emptyList(),
        val source: String = "BDIX",
        val serverName: String = "",
        val category: String = "KOREAN",
        val folderUrl: String = "",
        val lastModified: String = "",
        val lastModifiedTimestamp: Long = 0,
        val folderModified: String = "",
        val folderModifiedTimestamp: Long = 0,
        val addedDate: Long = 0,
        val isFavorite: Boolean = false,
        val totalEpisodes: Int = 0,
        val status: String = "Completed"
    ) {
        fun toSeries(): Series {
            return Series(
                id = id,
                title = title,
                originalTitle = originalTitle,
                year = year,
                quality = quality,
                poster = poster,
                backdrop = backdrop,
                description = description,
                genres = genres,
                cast = cast,
                director = director,
                language = language,
                seasons = seasons.map { it.toSeason() },
                subtitles = subtitles.map { it.toSubtitle() },
                source = source,
                serverName = serverName,
                category = SeriesCategory.fromApiName(category),
                folderUrl = folderUrl,
                lastModified = lastModified,
                lastModifiedTimestamp = lastModifiedTimestamp,
                folderModified = folderModified,
                folderModifiedTimestamp = folderModifiedTimestamp,
                addedDate = if (addedDate > 0) addedDate else System.currentTimeMillis(),
                isFavorite = isFavorite,
                totalEpisodes = totalEpisodes,
                status = status
            )
        }
    }

    private data class SeasonJson(
        val seasonNumber: Int = 1,
        val title: String = "",
        val description: String = "",
        val poster: String = "",
        val year: String = "",
        val episodeCount: Int = 0,
        val episodes: List<EpisodeJson> = emptyList(),
        val folderUrl: String = ""
    ) {
        fun toSeason(): Season {
            return Season(
                seasonNumber = seasonNumber,
                title = title,
                description = description,
                poster = poster,
                year = year,
                episodeCount = episodeCount,
                episodes = episodes.map { it.toEpisode() },
                folderUrl = folderUrl
            )
        }
    }

    private data class EpisodeJson(
        val id: String = "",
        val episodeNumber: Int = 0,
        val title: String = "",
        val description: String = "",
        val duration: String = "",
        val quality: String = "HD",
        val poster: String = "",
        val streamUrls: List<StreamUrlJson> = emptyList(),
        val subtitles: List<SubtitleJson> = emptyList(),
        val airDate: String = "",
        val folderUrl: String = "",
        val lastModified: String = "",
        val watchProgress: Double = 0.0,
        val lastWatched: Long = 0
    ) {
        fun toEpisode(): Episode {
            return Episode(
                id = id,
                episodeNumber = episodeNumber,
                title = title,
                description = description,
                duration = duration,
                quality = quality,
                poster = poster,
                streamUrls = streamUrls.map { it.toStreamUrl() },
                subtitles = subtitles.map { it.toSubtitle() },
                airDate = airDate,
                folderUrl = folderUrl,
                lastModified = lastModified,
                watchProgress = watchProgress.toFloat(),
                lastWatched = lastWatched
            )
        }
    }

    private data class StreamUrlJson(
        val url: String = "",
        val quality: String = "HD",
        val server: String = "BDIX",
        val fileName: String = "",
        val isWorking: Boolean = true
    ) {
        fun toStreamUrl() = StreamUrl(url, quality, server, fileName, isWorking)
    }

    private data class SubtitleJson(
        val url: String = "",
        val language: String = "",
        val label: String = ""
    ) {
        fun toSubtitle() = Subtitle(url, language, label)
    }

    data class ServerStatus(
        val url: String,
        val isReachable: Boolean,
        val statusCode: Int
    )
}
