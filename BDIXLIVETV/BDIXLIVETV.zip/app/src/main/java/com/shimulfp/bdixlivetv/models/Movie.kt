package com.shimulfp.bdixlivetv.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Movie(
    val id: String,
    val title: String,
    val originalTitle: String = "",
    val year: String = "",
    val rating: String = "",
    val duration: String = "",
    val quality: String = "HD",
    val poster: String = "",
    val backdrop: String = "",
    val description: String = "",
    val genres: List<String> = emptyList(),
    val cast: List<String> = emptyList(),
    val director: String = "",
    val language: String = "Hindi",
    val streamUrls: List<StreamUrl> = emptyList(),
    val subtitles: List<Subtitle> = emptyList(),
    val source: String = "BDIX",
    val serverName: String = "",
    val category: MovieCategory = MovieCategory.HINDI,
    val folderUrl: String = "",
    val lastModified: String = "",
    val lastModifiedTimestamp: Long = 0,
    val folderModified: String = "",
    val folderModifiedTimestamp: Long = 0,
    val addedDate: Long = System.currentTimeMillis(),
    val audioInfo: String = "",
    val codec: String = "",
    val isFavorite: Boolean = false,
    val watchProgress: Float = 0f,
    val lastWatched: Long = 0
) : Parcelable {

    fun getBestStreamUrl(): String? {
        return streamUrls.firstOrNull { it.isWorking }?.url
            ?: streamUrls.firstOrNull()?.url
    }

    fun getQualityBadgeColor(): Long {
        return when (quality.uppercase()) {
            "4K", "2160P" -> 0xFF9C27B0  // Purple
            "1080P" -> 0xFF4CAF50        // Green
            "720P" -> 0xFF2196F3         // Blue
            "BLURAY" -> 0xFF00BCD4       // Cyan
            else -> 0xFF757575           // Gray
        }
    }

    fun getFormattedAddedDate(): String {
        if (folderModified.isEmpty()) return ""
        return "Added: $folderModified"
    }

    fun getCategoryDisplayName(): String {
        return category.displayName
    }
}

@Parcelize
data class StreamUrl(
    val url: String,
    val quality: String = "HD",
    val server: String = "Server 1",
    val fileName: String = "",
    val isWorking: Boolean = true
) : Parcelable

@Parcelize
data class Subtitle(
    val url: String,
    val language: String,
    val label: String
) : Parcelable

enum class MovieCategory(val displayName: String, val apiName: String) {
    ALL("All Movies", "ALL"),
    HINDI("Hindi Movies", "HINDI"),
    HOLLYWOOD("Hollywood", "HOLLYWOOD"),
    SOUTH_DUBBED("South Hindi Dubbed", "SOUTH_DUBBED"),
    BENGALI("Bengali", "BENGALI"),
    KOREAN("Korean", "KOREAN"),
    ANIME("Anime", "ANIME"),
    WEB_SERIES("Web Series", "WEB_SERIES");

    companion object {
        fun fromApiName(name: String): MovieCategory {
            return values().find { it.apiName == name } ?: HINDI
        }
    }
}
