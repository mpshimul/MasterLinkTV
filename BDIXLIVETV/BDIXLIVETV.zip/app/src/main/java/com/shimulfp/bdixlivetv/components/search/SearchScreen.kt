package com.shimulfp.bdixlivetv.components.search

//import androidx.compose.animation.core.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.Channel
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.components.TvMovieCard
import com.shimulfp.bdixlivetv.components.TvChannelCard
import com.shimulfp.bdixlivetv.viewmodel.MovieViewModel

@Composable
fun SearchScreen(
    movieViewModel: MovieViewModel,
    onMovieClick: (Movie) -> Unit,
    onChannelClick: (Int, List<Channel>) -> Unit,
    allChannels: List<Channel>,
    onClose: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val searchResults by movieViewModel.searchResults.collectAsState()
    val searchInputFocusRequester = remember { FocusRequester() }
    val resultsFocusRequester = remember { FocusRequester() }
    
    // Request focus on search input when screen loads
    LaunchedEffect(Unit) {
        searchInputFocusRequester.requestFocus()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }

            Spacer(modifier = Modifier.width(16.dp))

            Text(
                "Search",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search Input
        SearchInput(
            query = searchQuery,
            onQueryChange = { query ->
                searchQuery = query
                movieViewModel.search(query)
            },
            onClear = {
                searchQuery = ""
                movieViewModel.clearSearch()
            },
            focusRequester = searchInputFocusRequester
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Results
        if (searchQuery.isNotEmpty()) {
            SearchResultsContent(
                searchResults = searchResults,
                allChannels = allChannels,
                searchQuery = searchQuery,
                onMovieClick = onMovieClick,
                onChannelClick = onChannelClick,
                focusRequester = resultsFocusRequester
            )
        } else {
            EmptySearchState()
        }
    }
}

@Composable
private fun SearchInput(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit,
    focusRequester: FocusRequester
) {
    var isFocused by remember { mutableStateOf(false) }
    
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        label = { Text("Search movies and channels...") },
        leadingIcon = {
            Icon(Icons.Default.Search, null, tint = Color.Gray)
        },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = onClear) {
                    Icon(Icons.Default.Clear, null, tint = Color.Gray)
                }
            }
        },
        keyboardOptions = KeyboardOptions(
            imeAction = ImeAction.Search
        ),
        keyboardActions = KeyboardActions(
            onSearch = {
                // Handle search action
                defaultKeyboardAction(ImeAction.Default)
            }
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color.Red,
            unfocusedBorderColor = Color.Gray,
            focusedLabelColor = Color.Red,
            unfocusedLabelColor = Color.Gray,
            unfocusedContainerColor = Color(0xFF1A1A1A),
            focusedContainerColor = Color(0xFF1A1A1A)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .focusRequester(focusRequester)
            .onFocusChanged { isFocused = it.isFocused }
            .border(
                width = if (isFocused) 3.dp else 1.dp,
                color = if (isFocused) Color.Red else Color.Gray,
                shape = RoundedCornerShape(8.dp)
            ),
        singleLine = true
    )
}

@Composable
private fun SearchResultsContent(
    searchResults: List<Movie>,
    allChannels: List<Channel>,
    searchQuery: String,
    onMovieClick: (Movie) -> Unit,
    onChannelClick: (Int, List<Channel>) -> Unit,
    focusRequester: FocusRequester
) {
    val channelResults = remember(searchQuery, allChannels) {
        allChannels.filter {
            it.name.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn {
        // Movie Results Section
        if (searchResults.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Movies",
                    count = searchResults.size,
                    icon = Icons.Default.Movie
                )
            }

            items(searchResults.take(10), key = { it.id }) { movie ->
                MovieSearchResultItem(
                    movie = movie,
                    onClick = { onMovieClick(movie) },
                    focusRequester = focusRequester
                )
            }
        }

        // Channel Results Section
        if (channelResults.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(24.dp))

                SectionHeader(
                    title = "Channels",
                    count = channelResults.size,
                    icon = Icons.Default.LiveTv
                )
            }

            itemsIndexed(channelResults.take(10)) { index, channel ->
                ChannelSearchResultItem(
                    channel = channel,
                    index = index,
                    onClick = { onChannelClick(index, channelResults) }
                )
            }
        }

        // No Results State
        if (searchResults.isEmpty() && channelResults.isEmpty()) {
            item {
                NoResultsFound(searchQuery = searchQuery)
            }
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    count: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            title,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            "($count)",
            color = Color.Gray,
            fontSize = 14.sp
        )
    }
}

@Composable
private fun MovieSearchResultItem(
    movie: Movie,
    onClick: () -> Unit,
    focusRequester: FocusRequester
) {
    var isFocused by remember { mutableStateOf(false) }
    
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Poster thumbnail
            Box(
                modifier = Modifier
                    .size(60.dp, 90.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2A2A2A))
            ) {
                if (movie.poster.isNotEmpty()) {
                    AsyncImage(
                        model = movie.poster,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        Icons.Default.Movie,
                        null,
                        tint = Color.Gray,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Movie info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    movie.title,
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    InfoChip(text = movie.year)
                    InfoChip(text = movie.quality, color = Color.Green)
                    InfoChip(text = movie.language, color = Color.Cyan)
                }
            }

            // Play icon
            Icon(Icons.Default.PlayCircle, null, tint = Color.Red)
        }
    }
}

@Composable
private fun ChannelSearchResultItem(
    channel: Channel,
    index: Int,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Channel logo/thumbnail
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2A2A2A)),
                contentAlignment = Alignment.Center
            ) {
                if (channel.logo.isNotEmpty()) {
                    AsyncImage(
                        model = channel.logo,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize().padding(4.dp),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Text(
                        channel.name.take(2),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Channel info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    channel.name,
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${channel.urls.size} servers • ${channel.source}",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // Live TV icon
            Icon(Icons.Default.LiveTv, null, tint = Color.Magenta)
        }
    }
}

@Composable
private fun NoResultsFound(searchQuery: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Default.Search,
                null,
                tint = Color.Gray,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "No results for \"$searchQuery\"",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Try different keywords",
                color = Color.Gray,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun EmptySearchState() {
    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Default.Search,
                null,
                tint = Color.Gray,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "Search for movies and channels",
                color = Color.Gray,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(24.dp))

            // Search suggestions
            SearchSuggestionItem(icon = Icons.Default.Movie, text = "Popular Movies")
            SearchSuggestionItem(icon = Icons.Default.LiveTv, text = "Popular Channels")
            SearchSuggestionItem(icon = Icons.Default.Favorite, text = "Your Favorites")
            SearchSuggestionItem(icon = Icons.Default.History, text = "Watch History")
        }
    }
}

@Composable
private fun SearchSuggestionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 8.dp)
            .clickable { /* Handle suggestion click */ }
            .background(Color(0xFF1A1A1A), RoundedCornerShape(8.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(text, color = Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun InfoChip(text: String, color: Color = Color.Gray) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}