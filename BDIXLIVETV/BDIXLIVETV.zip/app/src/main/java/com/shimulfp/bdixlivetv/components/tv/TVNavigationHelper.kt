package com.shimulfp.bdixlivetv.components.tv

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.FocusInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer

/**
 * TV Navigation Helper - Provides enhanced navigation components for Android TV
 *
 * This file contains improved navigation components with better focus management,
 * D-pad support, and visual feedback for TV remote control interaction.
 */

/**
 * Enhanced TV Navigation Item with improved focus management
 *
 * Features:
 * - Highly visible focus indicator with gold border
 * - Smooth animations for focus changes
 * - Chevron icon when focused
 * - Better support for D-pad navigation
 *
 * @param title Navigation item title
 * @param icon Icon to display
 * @param selected Whether this item is currently selected
 * @param onClick Callback when item is clicked
 * @param modifier Modifier for nav item
 * @param focusRequester Optional focus requester for programmatic focus
 */
@Composable
fun TVNavItem(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Collect focus state
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is FocusInteraction.Focus) {
                isFocused = true
            } else if (interaction is FocusInteraction.Unfocus) {
                isFocused = false
            }
        }
    }

    // Focus animations
    val backgroundColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700).copy(alpha = 0.2f) // Gold tint when selected
            isFocused -> Color(0xFF3D3D1A)                      // Dark gold when focused
            else -> Color.Transparent                            // Transparent when normal
        },
        animationSpec = tween(durationMillis = 150),
        label = "backgroundColor"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700)  // Gold border when selected
            isFocused -> Color(0xFFFFD700) // Gold border when focused
            else -> Color.Transparent      // No border when normal
        },
        animationSpec = tween(durationMillis = 150),
        label = "borderColor"
    )

    val iconColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700)  // Gold when selected
            isFocused -> Color.White       // White when focused
            else -> Color(0xFFAAAAAA)      // Gray when normal
        },
        animationSpec = tween(durationMillis = 150),
        label = "iconColor"
    )

    val textColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700)  // Gold when selected
            isFocused -> Color.White       // White when focused
            else -> Color(0xFFCCCCCC)      // Light gray when normal
        },
        animationSpec = tween(durationMillis = 150),
        label = "textColor"
    )

    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.02f else 1f,
        animationSpec = tween(durationMillis = 150),
        label = "scale"
    )

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .border(
                width = if (isFocused || selected) 3.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(12.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(interactionSource = interactionSource)
            .focusRequester(focusRequester),
        colors = CardDefaults.cardColors(
            containerColor = backgroundColor
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier.size(28.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Text(
                text = title,
                color = textColor,
                fontSize = 16.sp,
                fontWeight = if (isFocused || selected) FontWeight.Bold else FontWeight.Normal
            )

            if (isFocused || selected) {
                Spacer(modifier = Modifier.weight(1f))
                Icon(
                    Icons.Filled.ChevronRight,
                    contentDescription = null,
                    tint = Color(0xFFFFD700),
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

/**
 * TV Sub Navigation Item for nested menu items
 *
 * @param title Sub navigation item title
 * @param selected Whether this item is currently selected
 * @param onClick Callback when item is clicked
 * @param modifier Modifier for sub nav item
 * @param focusRequester Optional focus requester
 */
@Composable
fun TVSubNavItem(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Collect focus state
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is FocusInteraction.Focus) {
                isFocused = true
            } else if (interaction is FocusInteraction.Unfocus) {
                isFocused = false
            }
        }
    }

    // Focus animations
    val backgroundColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFF2A2A2A)
            isFocused -> Color(0xFF2A2A2A)
            else -> Color.Transparent
        },
        animationSpec = tween(durationMillis = 150),
        label = "backgroundColor"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700)
            isFocused -> Color(0xFFFFD700)
            else -> Color.Transparent
        },
        animationSpec = tween(durationMillis = 150),
        label = "borderColor"
    )

    val textColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700)
            isFocused -> Color.White
            else -> Color(0xFFCCCCCC)
        },
        animationSpec = tween(durationMillis = 150),
        label = "textColor"
    )

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 32.dp, top = 3.dp, bottom = 3.dp)
            .border(
                width = if (isFocused || selected) 2.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(interactionSource = interactionSource)
            .focusRequester(focusRequester),
        colors = CardDefaults.cardColors(
            containerColor = backgroundColor
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = textColor,
                fontSize = 14.sp,
                fontWeight = if (isFocused || selected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

/**
 * TV Expandable Navigation Item for dropdown menus
 *
 * @param title Navigation item title
 * @param icon Icon to display
 * @param selected Whether this item is currently selected
 * @param expanded Whether dropdown is currently expanded
 * @param onClick Callback when item is clicked
 * @param modifier Modifier for nav item
 * @param focusRequester Optional focus requester
 */
@Composable
fun TVExpandableNavItem(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    expanded: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Collect focus state
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is FocusInteraction.Focus) {
                isFocused = true
            } else if (interaction is FocusInteraction.Unfocus) {
                isFocused = false
            }
        }
    }

    // Focus animations
    val backgroundColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700).copy(alpha = 0.2f)
            isFocused -> Color(0xFF3D3D1A)
            else -> Color.Transparent
        },
        animationSpec = tween(durationMillis = 150),
        label = "backgroundColor"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700)
            isFocused -> Color(0xFFFFD700)
            else -> Color.Transparent
        },
        animationSpec = tween(durationMillis = 150),
        label = "borderColor"
    )

    val iconColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700)
            isFocused -> Color.White
            else -> Color(0xFFAAAAAA)
        },
        animationSpec = tween(durationMillis = 150),
        label = "iconColor"
    )

    val textColor by animateColorAsState(
        targetValue = when {
            selected -> Color(0xFFFFD700)
            isFocused -> Color.White
            else -> Color(0xFFCCCCCC)
        },
        animationSpec = tween(durationMillis = 150),
        label = "textColor"
    )

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .border(
                width = if (isFocused || selected) 3.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(12.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(interactionSource = interactionSource)
            .focusRequester(focusRequester),
        colors = CardDefaults.cardColors(
            containerColor = backgroundColor
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier.size(28.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Text(
                text = title,
                color = textColor,
                fontSize = 16.sp,
                fontWeight = if (isFocused || selected) FontWeight.Bold else FontWeight.Normal
            )

            Spacer(modifier = Modifier.weight(1f))

            Icon(
                imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                contentDescription = if (expanded) "Collapse" else "Expand",
                tint = if (isFocused || selected) Color(0xFFFFD700) else Color.Gray,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

/**
 * TV Focusable Button - A button with enhanced TV focus support
 *
 * @param text Button text
 * @param onClick Callback when button is clicked
 * @param enabled Whether button is enabled
 * @param modifier Modifier for button
 * @param focusRequester Optional focus requester
 */
@Composable
fun TVFocusableButton(
    text: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() }
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Collect focus state
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is FocusInteraction.Focus) {
                isFocused = true
            } else if (interaction is FocusInteraction.Unfocus) {
                isFocused = false
            }
        }
    }

    // Focus animations
    val backgroundColor by animateColorAsState(
        targetValue = when {
            !enabled -> Color(0xFF333333)
            isFocused -> Color(0xFFFFD700)
            else -> Color(0xFF2A2A2A)
        },
        animationSpec = tween(durationMillis = 150),
        label = "backgroundColor"
    )

    val textColor by animateColorAsState(
        targetValue = when {
            !enabled -> Color(0xFF666666)
            isFocused -> Color.Black
            else -> Color.White
        },
        animationSpec = tween(durationMillis = 150),
        label = "textColor"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            !enabled -> Color.Transparent
            isFocused -> Color.White
            else -> Color.Transparent
        },
        animationSpec = tween(durationMillis = 150),
        label = "borderColor"
    )

    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .border(
                width = if (isFocused) 3.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(interactionSource = interactionSource)
            .focusRequester(focusRequester),
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = text,
            color = textColor,
            fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal
        )
    }
}

/**
 * TV Focusable Card - A general-purpose card with enhanced TV focus support
 *
 * Features:
 * - Highly visible focus border
 * - Scale animation on focus
 * - Customizable content
 *
 * @param onClick Callback when card is clicked
 * @param modifier Modifier for card
 * @param focusRequester Optional focus requester
 * @param content Card content
 */
@Composable
fun TVFocusableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester = remember { FocusRequester() },
    content: @Composable BoxScope.() -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Collect focus state
    LaunchedEffect(interactionSource) {
        interactionSource.interactions.collect { interaction ->
            if (interaction is FocusInteraction.Focus) {
                isFocused = true
            } else if (interaction is FocusInteraction.Unfocus) {
                isFocused = false
            }
        }
    }

    // Focus animations
    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.05f else 1f,
        animationSpec = tween(durationMillis = 150),
        label = "scale"
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            isFocused -> Color(0xFFFFD700)
            else -> Color.Transparent
        },
        animationSpec = tween(durationMillis = 150),
        label = "borderColor"
    )

    val elevation by animateFloatAsState(
        targetValue = if (isFocused) 8.dp.value else 4.dp.value,
        animationSpec = tween(durationMillis = 150),
        label = "elevation"
    )

    Card(
        onClick = onClick,
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .border(
                width = if (isFocused) 3.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(12.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(interactionSource = interactionSource)
            .focusRequester(focusRequester),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E1E1E)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = elevation.dp
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(content = content)
    }
}
