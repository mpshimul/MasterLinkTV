package com.shimulfp.bdixlivetv

import android.app.PictureInPictureParams
import android.app.UiModeManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Point
import android.graphics.Rect
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.util.Rational
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeDown
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
//import androidx.compose.material3.ripple
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.localbroadcastmanager.content.LocalBroadcastManager.*
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class PlayerActivity : ComponentActivity() {
    private lateinit var exoPlayer: ExoPlayer
    private var isReleased = false
    private lateinit var broadcastReceiver: BroadcastReceiver
    private var isRegistered = false
    private lateinit var httpClient: OkHttpClient
    private var screenWidth = 0
    private var screenHeight = 0
    private var isTvDevice = false

    // ===== PIP STATE FLOW - This is the key fix =====
    private val _isInPipMode = MutableStateFlow(false)
    val isInPipMode: StateFlow<Boolean> = _isInPipMode.asStateFlow()

    // Check if PiP is supported
    private val isPipSupported: Boolean by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        } else false
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        isTvDevice = isTV()

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        val display = windowManager.defaultDisplay
        val size = Point()
        display.getSize(size)
        screenWidth = size.x
        screenHeight = size.y

        hideSystemUI()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Set initial PiP params for auto-enter (Android 12+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && isPipSupported) {
            setPictureInPictureParams(buildPipParams())
        }

        httpClient = OkHttpClient.Builder()
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(3, TimeUnit.SECONDS)
            .writeTimeout(3, TimeUnit.SECONDS)
            .build()

        val channels = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra("CHANNEL_LIST", Channel::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableArrayListExtra("CHANNEL_LIST")
        } ?: emptyList()

        val initialChannelIndex = intent.getIntExtra("CHANNEL_INDEX", 0)

        initializeExoPlayer()
        setupBroadcastReceiver()

        setContent {
            // Collect PiP state
            val pipMode by isInPipMode.collectAsState()

            MaterialTheme {
                PlayerScreen(
                    channels = channels,
                    initialChannelIndex = initialChannelIndex,
                    exoPlayer = exoPlayer,
                    httpClient = httpClient,
                    screenWidth = screenWidth,
                    screenHeight = screenHeight,
                    isTvDevice = isTvDevice,
                    isInPipMode = pipMode, // Pass PiP state directly
                    isPipSupported = isPipSupported,
                    onEnterPipMode = { enterPictureInPicture() },
                    onActivityFinish = { finish() },
                    onSetBrightness = { brightness -> setBrightness(brightness) },
                    onGetBrightness = { getBrightness() }
                )
            }
        }
    }

    private fun isTV(): Boolean {
        val uiModeManager = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        return uiModeManager.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
    }

    private fun setBrightness(brightness: Float) {
        val layoutParams = window.attributes
        layoutParams.screenBrightness = brightness.coerceIn(0.01f, 1f)
        window.attributes = layoutParams
    }

    private fun getBrightness(): Float {
        val brightness = window.attributes.screenBrightness
        return if (brightness < 0) {
            try {
                Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
            } catch (e: Exception) {
                0.5f
            }
        } else {
            brightness
        }
    }

    @UnstableApi
    private fun initializeExoPlayer() {
        val trackSelector = DefaultTrackSelector(this).apply {
            parameters = parameters.buildUpon()
                .setMaxVideoSize(1920, 1080)
                .setAllowVideoNonSeamlessAdaptiveness(true)
                .build()
        }

        exoPlayer = ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setLoadControl(
                androidx.media3.exoplayer.DefaultLoadControl.Builder()
                    .setBufferDurationsMs(5000, 15000, 1500, 2000)
                    .build()
            )
            .build()
            .apply {
                playWhenReady = true
                repeatMode = Player.REPEAT_MODE_OFF
            }
    }

    private fun setupBroadcastReceiver() {
        broadcastReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    "CHANNEL_DATA_UPDATED" -> {
                        val updatedChannels = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableArrayListExtra("channels", Channel::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableArrayListExtra("channels")
                        }
                        if (updatedChannels != null) {
                            val updateIntent = Intent("CHANNEL_UPDATE_IN_PLAYER")
                            updateIntent.putParcelableArrayListExtra("channels", ArrayList(updatedChannels))
                            getInstance(context).sendBroadcast(updateIntent)
                        }
                    }
                }
            }
        }

        val filter = IntentFilter().apply {
            addAction("CHANNEL_DATA_UPDATED")
        }

        try {
            getInstance(this).registerReceiver(broadcastReceiver, filter)
            isRegistered = true
        } catch (e: Exception) {
            Log.e("PlayerActivity", "Error registering receiver", e)
        }
    }

    // ===== BUILD PIP PARAMS WITH RESIZING SUPPORT =====
    private fun buildPipParams(): PictureInPictureParams {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            throw IllegalStateException("PiP not supported below API 26")
        }

        val builder = PictureInPictureParams.Builder()

        // Set aspect ratio range for flexibility (allows resizing)
        // 16:9 is standard, but we allow some flexibility
        builder.setAspectRatio(Rational(16, 9))

        // Android 12+ (API 31): Enable seamless resize and auto-enter
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setSeamlessResizeEnabled(true)
            builder.setAutoEnterEnabled(true)

            // Set source rect hint for smooth transition
            val sourceRect = Rect(0, 0, screenWidth, screenHeight)
            builder.setSourceRectHint(sourceRect)
        }

        // Android 14+ (API 34): Set expanded aspect ratio for more resize flexibility
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                // Use reflection for API 34+ as it might not be in SDK yet
                val method = PictureInPictureParams.Builder::class.java.getMethod(
                    "setExpandedAspectRatio",
                    Rational::class.java
                )
                method.invoke(builder, Rational(239, 100)) // 2.39:1 for ultrawide
            } catch (e: Exception) {
                Log.d("PlayerActivity", "setExpandedAspectRatio not available")
            }
        }

        return builder.build()
    }

    // ===== ENTER PIP MODE =====
    private fun enterPictureInPicture() {
        if (!isPipSupported) {
            Log.w("PlayerActivity", "PiP not supported on this device")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = buildPipParams()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                Log.e("PlayerActivity", "Failed to enter PiP mode", e)
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Auto-enter PiP when user presses home (for Android 8-11)
        // Android 12+ uses setAutoEnterEnabled(true) instead
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S &&
            isPipSupported) {
            enterPictureInPicture()
        }
    }

    // ===== THIS IS THE KEY - Update StateFlow when PiP mode changes =====
    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)

        // Update the StateFlow - this triggers recomposition
        _isInPipMode.value = isInPictureInPictureMode

        Log.d("PlayerActivity", "PiP mode changed: $isInPictureInPictureMode")

        if (isInPictureInPictureMode) {
            hideSystemUI()
            // Ensure video keeps playing
            if (!exoPlayer.isPlaying) {
                exoPlayer.play()
            }
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Ignore key events in PiP mode
        if (_isInPipMode.value) {
            return super.onKeyDown(keyCode, event)
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                sendKeyEventToComposable("KEY_DPAD_LEFT")
                true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                sendKeyEventToComposable("KEY_DPAD_RIGHT")
                true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                sendKeyEventToComposable("KEY_DPAD_UP")
                true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                sendKeyEventToComposable("KEY_DPAD_DOWN")
                true
            }
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                sendKeyEventToComposable("KEY_CHANNEL_UP")
                true
            }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                sendKeyEventToComposable("KEY_CHANNEL_DOWN")
                true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                sendKeyEventToComposable("KEY_DPAD_CENTER")
                true
            }
            KeyEvent.KEYCODE_BACK -> {
                sendKeyEventToComposable("KEY_BACK")
                true
            }
            KeyEvent.KEYCODE_MENU -> {
                sendKeyEventToComposable("KEY_MENU")
                true
            }
            KeyEvent.KEYCODE_VOLUME_UP -> {
                sendKeyEventToComposable("KEY_VOLUME_UP")
                true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                sendKeyEventToComposable("KEY_VOLUME_DOWN")
                true
            }
            KeyEvent.KEYCODE_P -> {
                sendKeyEventToComposable("KEY_PIP")
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (_isInPipMode.value) {
            return super.onKeyUp(keyCode, event)
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_UP,
            KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_CHANNEL_UP,
            KeyEvent.KEYCODE_CHANNEL_DOWN,
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_VOLUME_UP,
            KeyEvent.KEYCODE_VOLUME_DOWN,
            KeyEvent.KEYCODE_P -> true
            else -> super.onKeyUp(keyCode, event)
        }
    }

    private fun sendKeyEventToComposable(action: String) {
        val intent = Intent("PLAYER_KEY_EVENT")
        intent.putExtra("action", action)
        getInstance(this).sendBroadcast(intent)
    }

    override fun onResume() {
        super.onResume()
        if (!_isInPipMode.value) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
        if (!isReleased) {
            exoPlayer.play()
        }
    }

    override fun onPause() {
        super.onPause()
        // Don't pause in PiP mode
        if (!_isInPipMode.value && !isReleased) {
            exoPlayer.pause()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!_isInPipMode.value && !isReleased) {
            exoPlayer.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        if (isRegistered) {
            try {
                getInstance(this).unregisterReceiver(broadcastReceiver)
            } catch (e: Exception) {
                Log.e("PlayerActivity", "Error unregistering receiver", e)
            }
        }

        releasePlayer()

        try {
            httpClient.dispatcher.executorService.shutdown()
        } catch (e: Exception) {
            Log.e("PlayerActivity", "Error shutting down HTTP client", e)
        }
    }

    private fun releasePlayer() {
        if (isReleased) return
        isReleased = true
        exoPlayer.release()
    }

    private fun hideSystemUI() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
}

// ===== UPDATED PLAYER SCREEN =====
@androidx.annotation.OptIn(UnstableApi::class)
@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    channels: List<Channel>,
    initialChannelIndex: Int,
    exoPlayer: ExoPlayer,
    httpClient: OkHttpClient,
    screenWidth: Int,
    screenHeight: Int,
    isTvDevice: Boolean,
    isInPipMode: Boolean, // Now passed directly from Activity
    isPipSupported: Boolean,
    onEnterPipMode: () -> Unit,
    onActivityFinish: () -> Unit,
    onSetBrightness: (Float) -> Unit,
    onGetBrightness: () -> Float
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }

    val initialVolume = remember {
        audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume
    }

    // State variables
    var channelIndex by remember { mutableIntStateOf(initialChannelIndex) }
    var serverIndex by remember { mutableIntStateOf(0) }
    var showInfo by remember { mutableStateOf(true) }
    var showRibbon by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var currentChannels by remember { mutableStateOf(channels) }
    var ribbonFocusIndex by remember { mutableIntStateOf(initialChannelIndex) }
    var showServerList by remember { mutableStateOf(false) }
    var serverListFocusIndex by remember { mutableIntStateOf(0) }

    // Volume/Brightness control
    var displayVolume by remember { mutableFloatStateOf(initialVolume) }
    var displayBrightness by remember { mutableFloatStateOf(onGetBrightness()) }
    var actualVolume by remember { mutableIntStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)) }
    var actualBrightness by remember { mutableFloatStateOf(onGetBrightness()) }
    var showVolumeControl by remember { mutableStateOf(false) }
    var showBrightnessControl by remember { mutableStateOf(false) }
    var volumeAccumulator by remember { mutableFloatStateOf(0f) }
    var hideControlJob by remember { mutableStateOf<Job?>(null) }

    // Server retry tracking
    var serverRetryCount by remember { mutableIntStateOf(0) }
    var currentServerAttempts by remember { mutableIntStateOf(0) }
    var isErrorState by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    // Channel update notification
    var showUpdateToast by remember { mutableStateOf(false) }
    var updateToastMessage by remember { mutableStateOf("") }

    // Channel change debounce
    var lastChannelChangeTime by remember { mutableLongStateOf(0L) }
    val channelChangeCooldown = 500L
    var isChannelChanging by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val ribbonListState = rememberLazyListState()

    // Calculate responsive dimensions
    val screenWidthDp = configuration.screenWidthDp.dp
    val screenHeightDp = configuration.screenHeightDp.dp
    val ribbonHeight = (screenHeightDp * 0.18f)
    val serverListHorizontalPadding = 100.dp

    // ===== HIDE ALL OVERLAYS WHEN ENTERING PIP =====
    LaunchedEffect(isInPipMode) {
        if (isInPipMode) {
            showRibbon = false
            showServerList = false
            showInfo = false
            showVolumeControl = false
            showBrightnessControl = false
            showUpdateToast = false
        }
    }

    // Helper functions
    fun adjustVolume(delta: Float) {
        volumeAccumulator += delta
        displayVolume = (displayVolume + delta).coerceIn(0f, 1f)

        val stepSize = 1f / maxVolume
        val stepsToChange = (volumeAccumulator / stepSize).toInt()

        if (stepsToChange != 0) {
            val newVolume = (actualVolume + stepsToChange).coerceIn(0, maxVolume)
            if (newVolume != actualVolume) {
                actualVolume = newVolume
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
                displayVolume = newVolume.toFloat() / maxVolume
            }
            volumeAccumulator = volumeAccumulator % stepSize
        }

        showVolumeControl = true
        showBrightnessControl = false

        hideControlJob?.cancel()
        hideControlJob = coroutineScope.launch {
            delay(1500)
            showVolumeControl = false
        }
    }

    fun adjustBrightness(delta: Float) {
        val newBrightness = (displayBrightness + delta).coerceIn(0.01f, 1f)
        displayBrightness = newBrightness
        actualBrightness = newBrightness
        onSetBrightness(newBrightness)

        showBrightnessControl = true
        showVolumeControl = false

        hideControlJob?.cancel()
        hideControlJob = coroutineScope.launch {
            delay(1500)
            showBrightnessControl = false
        }
    }

    fun setVolumeStep(increase: Boolean) {
        val newVolume = if (increase) {
            (actualVolume + 1).coerceAtMost(maxVolume)
        } else {
            (actualVolume - 1).coerceAtLeast(0)
        }

        if (newVolume != actualVolume) {
            actualVolume = newVolume
            displayVolume = newVolume.toFloat() / maxVolume
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
        }

        showVolumeControl = true
        showBrightnessControl = false

        hideControlJob?.cancel()
        hideControlJob = coroutineScope.launch {
            delay(1500)
            showVolumeControl = false
        }
    }

    fun safeChangeChannel(newIndex: Int, newServerIndex: Int = 0): Boolean {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastChannelChangeTime < channelChangeCooldown) return false
        if (isChannelChanging) return false

        lastChannelChangeTime = currentTime
        isChannelChanging = true

        channelIndex = newIndex
        ribbonFocusIndex = newIndex
        serverIndex = newServerIndex

        return true
    }

    fun createMediaSource(url: String): androidx.media3.exoplayer.source.MediaSource {
        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(10000)
            .setAllowCrossProtocolRedirects(true)

        val defaultDataSourceFactory = DefaultDataSource.Factory(context, dataSourceFactory)

        return if (url.contains(".m3u8") || url.contains("m3u")) {
            HlsMediaSource.Factory(defaultDataSourceFactory)
                .setAllowChunklessPreparation(true)
                .createMediaSource(MediaItem.fromUri(Uri.parse(url)))
        } else {
            ProgressiveMediaSource.Factory(defaultDataSourceFactory)
                .createMediaSource(MediaItem.fromUri(Uri.parse(url)))
        }
    }

    fun playChannel(chIndex: Int, srvIndex: Int) {
        val channel = currentChannels.getOrNull(chIndex)
        val urls = channel?.urls ?: emptyList()

        if (channel != null && urls.isNotEmpty()) {
            coroutineScope.launch {
                try {
                    isBuffering = true
                    isErrorState = false
                    errorMessage = ""
                    currentServerAttempts = 0

                    var attemptIndex = srvIndex
                    var attempts = 0
                    val maxAttempts = urls.size

                    while (attempts < maxAttempts) {
                        val urlIndex = attemptIndex % urls.size
                        val currentUrl = urls[urlIndex]

                        currentServerAttempts = attempts + 1
                        serverIndex = urlIndex

                        try {
                            exoPlayer.stop()
                            exoPlayer.clearMediaItems()

                            val mediaSource = createMediaSource(currentUrl)
                            exoPlayer.setMediaSource(mediaSource)
                            exoPlayer.prepare()
                            exoPlayer.play()

                            delay(5000)

                            if (exoPlayer.isPlaying ||
                                exoPlayer.playbackState == Player.STATE_READY ||
                                exoPlayer.playbackState == Player.STATE_BUFFERING) {
                                isBuffering = false
                                serverRetryCount = 0
                                isChannelChanging = false
                                return@launch
                            }
                        } catch (e: Exception) {
                            Log.w("Player", "Failed attempt ${attempts + 1}", e)
                        }

                        attempts++
                        attemptIndex++
                        delay(1000)
                    }

                    isChannelChanging = false

                    if (attempts >= maxAttempts) {
                        if (currentChannels.isNotEmpty()) {
                            val nextChannelIndex = (channelIndex + 1) % currentChannels.size
                            if (nextChannelIndex == initialChannelIndex && serverRetryCount >= 2) {
                                isErrorState = true
                                errorMessage = "No working channels available"
                            } else {
                                channelIndex = nextChannelIndex
                                ribbonFocusIndex = nextChannelIndex
                                serverIndex = 0
                                serverRetryCount++
                                playChannel(nextChannelIndex, 0)
                            }
                        } else {
                            isErrorState = true
                            errorMessage = "No channels available"
                        }
                    }
                } catch (e: Exception) {
                    isChannelChanging = false
                    isErrorState = true
                    errorMessage = "Playback error"
                }
            }
        } else {
            isChannelChanging = false
            if (currentChannels.isNotEmpty()) {
                val nextChannelIndex = (channelIndex + 1) % currentChannels.size
                channelIndex = nextChannelIndex
                ribbonFocusIndex = nextChannelIndex
                serverIndex = 0
                playChannel(nextChannelIndex, 0)
            }
        }
    }

    // Initialize playback
    LaunchedEffect(Unit) {
        playChannel(channelIndex, serverIndex)
        delay(100)
        if (currentChannels.isNotEmpty()) {
            ribbonListState.animateScrollToItem(channelIndex)
        }
    }

    // Player lifecycle observer
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    if (!exoPlayer.isPlaying) exoPlayer.play()
                    actualVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    displayVolume = actualVolume.toFloat() / maxVolume
                }
                Lifecycle.Event.ON_PAUSE -> {
                    // Don't pause in PiP mode
                    if (!isInPipMode && exoPlayer.isPlaying) exoPlayer.pause()
                }
                else -> {}
            }
        }

        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(channelIndex) {
        ribbonFocusIndex = channelIndex
        if (currentChannels.isNotEmpty()) {
            ribbonListState.animateScrollToItem(channelIndex)
        }
    }

    // Auto-hide info (not in PiP)
    LaunchedEffect(channelIndex, showRibbon, isInPipMode) {
        if (!isInPipMode) {
            showInfo = true
            delay(3000)
            if (!showRibbon) showInfo = false
        }
    }

    // Auto-hide ribbon - ONLY FOR TV DEVICES
    LaunchedEffect(showRibbon, isTvDevice) {
        if (showRibbon && isTvDevice) {
            delay(5000)
            if (showRibbon && !showServerList) {
                showRibbon = false
            }
        }
    }

    // TV Remote Key Event Handler
    DisposableEffect(Unit) {
        val keyReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                // Ignore in PiP mode
                if (isInPipMode) return

                val action = intent?.getStringExtra("action") ?: return

                when (action) {
                    "KEY_DPAD_LEFT" -> {
                        if (showRibbon && currentChannels.isNotEmpty() && !showServerList) {
                            val newFocusIndex = if (ribbonFocusIndex - 1 < 0)
                                currentChannels.size - 1 else ribbonFocusIndex - 1
                            ribbonFocusIndex = newFocusIndex
                            coroutineScope.launch { ribbonListState.animateScrollToItem(newFocusIndex) }
                        } else if (!showRibbon && currentChannels.isNotEmpty()) {
                            val newIndex = if (channelIndex - 1 < 0)
                                currentChannels.size - 1 else channelIndex - 1
                            if (safeChangeChannel(newIndex, 0)) playChannel(newIndex, 0)
                        }
                    }
                    "KEY_DPAD_RIGHT" -> {
                        if (showRibbon && currentChannels.isNotEmpty() && !showServerList) {
                            val newFocusIndex = (ribbonFocusIndex + 1) % currentChannels.size
                            ribbonFocusIndex = newFocusIndex
                            coroutineScope.launch { ribbonListState.animateScrollToItem(newFocusIndex) }
                        } else if (!showRibbon && currentChannels.isNotEmpty()) {
                            val newIndex = (channelIndex + 1) % currentChannels.size
                            if (safeChangeChannel(newIndex, 0)) playChannel(newIndex, 0)
                        }
                    }
                    "KEY_CHANNEL_UP" -> {
                        if (currentChannels.isNotEmpty()) {
                            val newIndex = (channelIndex + 1) % currentChannels.size
                            if (safeChangeChannel(newIndex, 0)) {
                                playChannel(newIndex, 0)
                                showRibbon = true
                                showInfo = true
                            }
                        }
                    }
                    "KEY_CHANNEL_DOWN" -> {
                        if (currentChannels.isNotEmpty()) {
                            val newIndex = if (channelIndex - 1 < 0)
                                currentChannels.size - 1 else channelIndex - 1
                            if (safeChangeChannel(newIndex, 0)) {
                                playChannel(newIndex, 0)
                                showRibbon = true
                                showInfo = true
                            }
                        }
                    }
                    "KEY_DPAD_UP" -> {
                        if (showRibbon && !showServerList) {
                            showServerList = true
                            serverListFocusIndex = serverIndex
                        } else if (showServerList) {
                            val channel = currentChannels.getOrNull(channelIndex)
                            val servers = channel?.urls ?: emptyList()
                            if (servers.isNotEmpty()) {
                                serverListFocusIndex = if (serverListFocusIndex - 1 < 0)
                                    servers.size - 1 else serverListFocusIndex - 1
                            }
                        } else {
                            showRibbon = true
                            showInfo = true
                            showServerList = false
                            ribbonFocusIndex = channelIndex
                            coroutineScope.launch { ribbonListState.animateScrollToItem(channelIndex) }
                        }
                    }
                    "KEY_DPAD_DOWN" -> {
                        if (showServerList) {
                            val channel = currentChannels.getOrNull(channelIndex)
                            val servers = channel?.urls ?: emptyList()
                            if (servers.isNotEmpty()) {
                                serverListFocusIndex = (serverListFocusIndex + 1) % servers.size
                            }
                        } else if (showRibbon) {
                            showRibbon = false
                            showServerList = false
                        }
                    }
                    "KEY_DPAD_CENTER", "KEY_ENTER" -> {
                        if (showServerList) {
                            serverIndex = serverListFocusIndex
                            playChannel(channelIndex, serverListFocusIndex)
                            showServerList = false
                        } else if (showRibbon) {
                            if (ribbonFocusIndex != channelIndex) {
                                if (safeChangeChannel(ribbonFocusIndex, 0)) {
                                    playChannel(ribbonFocusIndex, 0)
                                }
                            }
                            showRibbon = false
                            showServerList = false
                        }
                    }
                    "KEY_MENU" -> {
                        showRibbon = !showRibbon
                        if (showRibbon) {
                            showInfo = true
                            showServerList = false
                            ribbonFocusIndex = channelIndex
                            coroutineScope.launch { ribbonListState.animateScrollToItem(channelIndex) }
                        }
                    }
                    "KEY_BACK" -> {
                        when {
                            showServerList -> showServerList = false
                            showRibbon -> {
                                showRibbon = false
                                showServerList = false
                            }
                            else -> onActivityFinish()
                        }
                    }
                    "KEY_VOLUME_UP" -> setVolumeStep(increase = true)
                    "KEY_VOLUME_DOWN" -> setVolumeStep(increase = false)
                    "KEY_PIP" -> if (isPipSupported) onEnterPipMode()
                }
            }
        }

        val filter = IntentFilter("PLAYER_KEY_EVENT")
        getInstance(context).registerReceiver(keyReceiver, filter)
        onDispose { getInstance(context).unregisterReceiver(keyReceiver) }
    }

    // Channel update receiver
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == "CHANNEL_UPDATE_IN_PLAYER" && !isInPipMode) {
                    val updatedChannels = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableArrayListExtra("channels", Channel::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableArrayListExtra("channels")
                    }
                    if (updatedChannels != null) {
                        val oldSize = currentChannels.size
                        currentChannels = updatedChannels
                        updateToastMessage = "Updated: +${currentChannels.size - oldSize} servers"
                        showUpdateToast = true
                        coroutineScope.launch {
                            delay(3000)
                            showUpdateToast = false
                        }
                        if (channelIndex >= currentChannels.size) {
                            channelIndex = 0
                            ribbonFocusIndex = 0
                            serverIndex = 0
                            playChannel(0, 0)
                        }
                    }
                }
            }
        }

        val filter = IntentFilter("CHANNEL_UPDATE_IN_PLAYER")
        getInstance(context).registerReceiver(receiver, filter)
        onDispose { getInstance(context).unregisterReceiver(receiver) }
    }

    // Player event listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> isBuffering = true
                    Player.STATE_READY -> {
                        isBuffering = false
                        isErrorState = false
                        errorMessage = ""
                        isChannelChanging = false
                    }
                    Player.STATE_ENDED -> {
                        coroutineScope.launch {
                            delay(1000)
                            val channel = currentChannels.getOrNull(channelIndex)
                            val urls = channel?.urls ?: emptyList()
                            if (urls.isNotEmpty()) {
                                val nextIndex = (serverIndex + 1) % urls.size
                                serverIndex = nextIndex
                                playChannel(channelIndex, nextIndex)
                            }
                        }
                    }
                    Player.STATE_IDLE -> isChannelChanging = false
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                isErrorState = true
                errorMessage = "Playback error"
                isChannelChanging = false
                coroutineScope.launch {
                    delay(1000)
                    val channel = currentChannels.getOrNull(channelIndex)
                    val urls = channel?.urls ?: emptyList()
                    if (urls.isNotEmpty()) {
                        val nextIndex = (serverIndex + 1) % urls.size
                        serverIndex = nextIndex
                        playChannel(channelIndex, nextIndex)
                    }
                }
            }
        }

        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Back handler (disabled in PiP)
    BackHandler(enabled = !isInPipMode) {
        when {
            showServerList -> showServerList = false
            showRibbon -> {
                showRibbon = false
                showServerList = false
            }
            else -> onActivityFinish()
        }
    }

    // Gesture tracking
    var swipeHandled by remember { mutableStateOf(false) }
    var totalDragX by remember { mutableFloatStateOf(0f) }
    var totalDragY by remember { mutableFloatStateOf(0f) }
    var dragDirection by remember { mutableStateOf("none") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            // ===== DISABLE GESTURES IN PIP MODE =====
            .then(
                if (!isInPipMode) {
                    Modifier
                        .pointerInput(showRibbon) {
                            detectTapGestures(
                                onTap = { offset ->
                                    val isInRibbonArea = offset.y > size.height * 0.7f
                                    if (!(showRibbon && isInRibbonArea)) {
                                        showRibbon = !showRibbon
                                        if (showRibbon) showServerList = false
                                    }
                                },
                                onDoubleTap = {
                                    if (isPipSupported) onEnterPipMode()
                                }
                            )
                        }
                        .pointerInput(showRibbon, showServerList, channelIndex) {
                            detectDragGestures(
                                onDragStart = {
                                    swipeHandled = false
                                    totalDragX = 0f
                                    totalDragY = 0f
                                    dragDirection = "none"
                                    volumeAccumulator = 0f
                                },
                                onDragEnd = {
                                    swipeHandled = false
                                    totalDragX = 0f
                                    totalDragY = 0f
                                    dragDirection = "none"
                                },
                                onDragCancel = {
                                    swipeHandled = false
                                    totalDragX = 0f
                                    totalDragY = 0f
                                    dragDirection = "none"
                                },
                                onDrag = { change, dragAmount ->
                                    change.consume()

                                    totalDragX += dragAmount.x
                                    totalDragY += dragAmount.y

                                    if (dragDirection == "none" && (abs(totalDragX) > 30 || abs(totalDragY) > 30)) {
                                        dragDirection = if (abs(totalDragX) > abs(totalDragY) * 1.2f) {
                                            "horizontal"
                                        } else if (abs(totalDragY) > abs(totalDragX) * 1.2f) {
                                            "vertical"
                                        } else "none"
                                    }

                                    if (dragDirection == "horizontal" && !swipeHandled && !showRibbon) {
                                        val swipeThreshold = size.width * 0.15f
                                        if (abs(totalDragX) > swipeThreshold) {
                                            swipeHandled = true
                                            if (currentChannels.isNotEmpty()) {
                                                val newIndex = if (totalDragX > 0) {
                                                    if (channelIndex - 1 < 0) currentChannels.size - 1 else channelIndex - 1
                                                } else {
                                                    (channelIndex + 1) % currentChannels.size
                                                }
                                                if (safeChangeChannel(newIndex, 0)) {
                                                    playChannel(newIndex, 0)
                                                }
                                            }
                                        }
                                    }

                                    if (dragDirection == "vertical" && !showRibbon) {
                                        val screenWidthLocal = size.width
                                        val touchX = change.position.x
                                        val sensitivity = 0.003f

                                        if (touchX < screenWidthLocal * 0.35f) {
                                            val delta = -dragAmount.y * sensitivity
                                            adjustVolume(delta)
                                        } else if (touchX > screenWidthLocal * 0.65f) {
                                            val delta = -dragAmount.y * sensitivity
                                            adjustBrightness(delta)
                                        }
                                    }

                                    if (showRibbon && !showServerList && dragDirection == "vertical" && totalDragY < -100) {
                                        showServerList = true
                                        serverListFocusIndex = serverIndex
                                    }
                                }
                            )
                        }
                } else Modifier
            )
    ) {
        // ===== VIDEO PLAYER - ALWAYS VISIBLE =====
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // ===== ALL UI BELOW IS HIDDEN IN PIP MODE =====

        // Error overlay
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = isErrorState && errorMessage.isNotEmpty(),
                enter = fadeIn(tween(300)),
                exit = fadeOut(tween(300)),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(0.8f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Error, "Error", tint = Color.Red, modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(16.dp))
                        Text("Playback Error", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(errorMessage, color = Color.Gray, fontSize = 16.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(16.dp))
                        Text("Trying alternative sources...", color = Color.Yellow, fontSize = 14.sp)
                    }
                }
            }
        }

        // PiP Button - HIDDEN IN PIP MODE
        if (!isInPipMode && isPipSupported) {
            AnimatedVisibility(
                visible = !showRibbon,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(200)),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(0.7f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = true, color = Color.White)
                        ) { onEnterPipMode() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PictureInPicture, "PiP", tint = Color.White, modifier = Modifier.size(24.dp))
                }
            }
        }

        // Volume Control - HIDDEN IN PIP MODE
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = showVolumeControl,
                enter = fadeIn(tween(100)) + scaleIn(initialScale = 0.9f, animationSpec = tween(100)),
                exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.9f, animationSpec = tween(150)),
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 32.dp)
            ) {
                val animatedVolume by animateFloatAsState(
                    targetValue = displayVolume,
                    animationSpec = tween(50, easing = LinearEasing),
                    label = "volume_anim"
                )
                VolumeIndicator(value = animatedVolume, maxSteps = maxVolume, currentStep = actualVolume)
            }
        }

        // Brightness Control - HIDDEN IN PIP MODE
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = showBrightnessControl,
                enter = fadeIn(tween(100)) + scaleIn(initialScale = 0.9f, animationSpec = tween(100)),
                exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.9f, animationSpec = tween(150)),
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 32.dp)
            ) {
                val animatedBrightness by animateFloatAsState(
                    targetValue = displayBrightness,
                    animationSpec = tween(50, easing = LinearEasing),
                    label = "brightness_anim"
                )
                BrightnessIndicator(value = animatedBrightness)
            }
        }

        // Update toast - HIDDEN IN PIP MODE
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = showUpdateToast,
                enter = slideInVertically { -it } + fadeIn(),
                exit = slideOutVertically { -it } + fadeOut(),
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 60.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Green.copy(0.9f))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(updateToastMessage, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        // Server List - HIDDEN IN PIP MODE
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = showRibbon && showServerList,
                enter = fadeIn(tween(200)) + slideInVertically(tween(200)) { it / 2 },
                exit = fadeOut(tween(200)) + slideOutVertically(tween(200)) { it / 2 },
                modifier = Modifier.align(Alignment.Center)
            ) {
                val channel = currentChannels.getOrNull(channelIndex)
                val servers = channel?.urls ?: emptyList()

                if (servers.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(0.7f))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { showServerList = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            modifier = Modifier
                                .widthIn(max = 400.dp)
                                .background(Color.Black.copy(0.95f), RoundedCornerShape(16.dp))
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Select Server", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(channel?.name ?: "", color = Color.Gray, fontSize = 14.sp)
                            Spacer(Modifier.height(16.dp))

                            servers.forEachIndexed { index, _ ->
                                val isSelected = index == serverListFocusIndex
                                val isActive = index == serverIndex

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            when {
                                                isSelected -> Color.Red.copy(0.3f)
                                                isActive -> Color.Green.copy(0.15f)
                                                else -> Color.Transparent
                                            }
                                        )
                                        .border(
                                            width = if (isActive) 1.dp else 0.dp,
                                            color = if (isActive) Color.Green else Color.Transparent,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable(
                                            interactionSource = remember { MutableInteractionSource() },
                                            indication = ripple(bounded = true)
                                        ) {
                                            serverIndex = index
                                            playChannel(channelIndex, index)
                                            showServerList = false
                                        }
                                        .padding(horizontal = 16.dp, vertical = 12.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            "Server ${index + 1}",
                                            color = if (isActive) Color.Green else Color.White,
                                            fontSize = 16.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                        if (isActive) {
                                            Icon(Icons.Default.CheckCircle, "Active", tint = Color.Green, modifier = Modifier.size(20.dp))
                                        }
                                    }
                                }
                                if (index < servers.size - 1) Spacer(Modifier.height(4.dp))
                            }

                            Spacer(Modifier.height(12.dp))
                            Text("Tap to select • Tap outside to close", color = Color.Gray, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Buffering - Show minimal in PiP, full otherwise
        AnimatedVisibility(
            visible = isBuffering && !isErrorState,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(if (isInPipMode) Color.Black.copy(0.3f) else Color.Black.copy(0.6f)),
                contentAlignment = Alignment.Center
            ) {
                if (isInPipMode) {
                    // Minimal loading in PiP - just a small spinner
                    CircularProgressIndicator(
                        color = Color.Red,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                } else {
                    // Full loading indicator
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color.Red, strokeWidth = 3.dp, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Loading...", color = Color.White, fontSize = 14.sp)
                        if (currentServerAttempts > 1) {
                            Text("Attempt $currentServerAttempts", color = Color.Gray, fontSize = 12.sp)
                        }
                        currentChannels.getOrNull(channelIndex)?.let { channel ->
                            Text("${channel.name} • Server ${serverIndex + 1}", color = Color.Gray, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Channel info - HIDDEN IN PIP MODE
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = showInfo && !showRibbon && !isErrorState,
                enter = fadeIn(tween(200)) + slideInHorizontally(tween(200)) { -it },
                exit = fadeOut(tween(200)) + slideOutHorizontally(tween(200)) { -it },
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
            ) {
                val channel = currentChannels.getOrNull(channelIndex)
                val totalServers = channel?.urls?.size ?: 1

                Box(
                    modifier = Modifier
                        .background(Color.Black.copy(0.85f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Red),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${channelIndex + 1}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(channel?.name ?: "Unknown", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text(channel?.category ?: "General", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                        if (totalServers > 1) {
                            Spacer(Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Storage, "Server", tint = Color.Gray, modifier = Modifier.size(12.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Server ${serverIndex + 1} of $totalServers", color = Color.Gray, fontSize = 10.sp)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Swipe ←→ to change channel", color = Color.Gray.copy(0.7f), fontSize = 9.sp)
                    }
                }
            }
        }

        // Channel ribbon - HIDDEN IN PIP MODE
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = showRibbon && currentChannels.isNotEmpty(),
                enter = slideInVertically(tween(250, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(200)),
                exit = slideOutVertically(tween(200, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(150)),
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .height(ribbonHeight + 16.dp)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.95f))))
                        .padding(top = 8.dp, bottom = 16.dp)
                ) {
                    if (!isTvDevice) {
                        IconButton(
                            onClick = { showRibbon = false; showServerList = false },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(end = 8.dp)
                                .size(32.dp)
                                .zIndex(1f)
                        ) {
                            Icon(Icons.Default.Close, "Close", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }

                    LazyRow(
                        state = ribbonListState,
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxHeight().padding(bottom = 4.dp)
                    ) {
                        itemsIndexed(currentChannels) { index, channel ->
                            val isPlaying = index == channelIndex
                            val isFocused = index == ribbonFocusIndex
                            val scale by animateFloatAsState(
                                targetValue = when {
                                    isFocused -> 1.08f
                                    isPlaying -> 1.04f
                                    else -> 1f
                                },
                                animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                                label = "scale"
                            )
                            val borderColor by animateColorAsState(
                                targetValue = when {
                                    isPlaying && isFocused -> Color.Red
                                    isPlaying -> Color.Red.copy(0.7f)
                                    isFocused -> Color.White
                                    else -> Color.Transparent
                                },
                                animationSpec = tween(200),
                                label = "border"
                            )

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .width(72.dp)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = ripple(bounded = true, color = Color.White)
                                    ) {
                                        if (safeChangeChannel(index, 0)) playChannel(index, 0)
                                        if (isTvDevice) showRibbon = false
                                        showServerList = false
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(52.dp)
                                        .scale(scale)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(2.dp, borderColor, RoundedCornerShape(8.dp))
                                        .background(Color.Gray.copy(0.2f))
                                ) {
                                    AsyncImage(
                                        model = channel.logo.ifEmpty { "https://via.placeholder.com/150" },
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = channel.name,
                                    color = when {
                                        isPlaying -> Color.Red
                                        isFocused -> Color.White
                                        else -> Color.Gray
                                    },
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (isPlaying || isFocused) FontWeight.Bold else FontWeight.Normal,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text("${channel.urls.size} srv", color = Color.Gray.copy(0.7f), fontSize = 7.sp)
                                if (isPlaying) {
                                    Spacer(Modifier.height(2.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Color.Red)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("LIVE", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(start = 12.dp) // Horizontal position
                            .offset(y = (-28).dp)    // Move UP by 8dp
                    ) {
                        Text(
                            text = "${ribbonFocusIndex + 1}/${currentChannels.size}",
                            color = Color.White.copy(0.8f),
                            fontSize = 15.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset(y = (-22).dp) // Move UP by 10dp
                    ) {
                        Text(
                            text = if (isTvDevice)
                                "↑ Servers • ←→ Navigate • OK Select"
                            else
                                "Swipe up for servers • Tap to select",
                            color = Color.Gray.copy(0.8f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

// ===== VOLUME INDICATOR =====
@Composable
fun VolumeIndicator(value: Float, maxSteps: Int, currentStep: Int) {
    Box(
        modifier = Modifier
            .width(70.dp)
            .height(180.dp)
            .background(Color.Black.copy(0.9f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            Icon(
                imageVector = when {
                    value <= 0f -> Icons.AutoMirrored.Filled.VolumeOff
                    value < 0.3f -> Icons.AutoMirrored.Filled.VolumeMute
                    value < 0.7f -> Icons.AutoMirrored.Filled.VolumeDown
                    else -> Icons.AutoMirrored.Filled.VolumeUp
                },
                contentDescription = "Volume",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .weight(1f)
                    .width(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.Gray.copy(0.4f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(value.coerceIn(0f, 1f))
                        .align(Alignment.BottomCenter)
                        .clip(RoundedCornerShape(5.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF4CAF50), Color(0xFF8BC34A))))
                )
            }
            Spacer(Modifier.height(8.dp))
            Text("${(value * 100).toInt()}%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("$currentStep/$maxSteps", color = Color.Gray, fontSize = 9.sp)
        }
    }
}

// ===== BRIGHTNESS INDICATOR =====
@Composable
fun BrightnessIndicator(value: Float) {
    Box(
        modifier = Modifier
            .width(70.dp)
            .height(180.dp)
            .background(Color.Black.copy(0.9f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            Icon(
                imageVector = when {
                    value < 0.3f -> Icons.Default.Brightness4
                    value < 0.7f -> Icons.Default.Brightness6
                    else -> Icons.Default.Brightness7
                },
                contentDescription = "Brightness",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .weight(1f)
                    .width(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.Gray.copy(0.4f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(value.coerceIn(0f, 1f))
                        .align(Alignment.BottomCenter)
                        .clip(RoundedCornerShape(5.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFFFFEB3B), Color(0xFFFFC107))))
                )
            }
            Spacer(Modifier.height(8.dp))
            Text("${(value * 100).toInt()}%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}