// TVRemoteHandler.kt - Complete TV remote handling
import android.view.KeyEvent

object TVRemoteHandler {

    data class TVRemoteConfig(
        val hasChannelUpDown: Boolean = true,
        val hasColorButtons: Boolean = false, // Sony remotes
        val hasNumberPad: Boolean = false,
        val hasGuideButton: Boolean = true,
        val hasInfoButton: Boolean = true,
        val supportsLongPress: Boolean = true
    )

    // Map common TV remote keys to actions
    enum class TVRemoteAction {
        CHANNEL_UP,
        CHANNEL_DOWN,
        SHOW_GUIDE,
        SHOW_INFO,
        TOGGLE_SUBTITLES,
        TOGGLE_FAVORITE,
        JUMP_TO_CHANNEL, // For number pad
        SWITCH_INPUT,
        LAST_CHANNEL,
        PLAY_PAUSE,
        STOP,
        RECORD
    }

    fun handleKeyEvent(
        keyCode: Int,
        event: KeyEvent,
        config: TVRemoteConfig = TVRemoteConfig()
    ): TVRemoteAction? {
        return when (keyCode) {
            // Standard TV remote buttons
            KeyEvent.KEYCODE_CHANNEL_UP -> TVRemoteAction.CHANNEL_UP
            KeyEvent.KEYCODE_CHANNEL_DOWN -> TVRemoteAction.CHANNEL_DOWN
            KeyEvent.KEYCODE_GUIDE -> TVRemoteAction.SHOW_GUIDE
            KeyEvent.KEYCODE_INFO -> TVRemoteAction.SHOW_INFO
            KeyEvent.KEYCODE_CAPTIONS -> TVRemoteAction.TOGGLE_SUBTITLES
            KeyEvent.KEYCODE_LAST_CHANNEL -> TVRemoteAction.LAST_CHANNEL
            KeyEvent.KEYCODE_TV_INPUT -> TVRemoteAction.SWITCH_INPUT

            // Sony/Samsung color buttons
            KeyEvent.KEYCODE_PROG_RED -> if (config.hasColorButtons) TVRemoteAction.TOGGLE_FAVORITE else TVRemoteAction.CHANNEL_UP
            KeyEvent.KEYCODE_PROG_GREEN -> if (config.hasColorButtons) TVRemoteAction.SHOW_GUIDE else TVRemoteAction.CHANNEL_DOWN
            KeyEvent.KEYCODE_PROG_YELLOW -> TVRemoteAction.SHOW_INFO
            KeyEvent.KEYCODE_PROG_BLUE -> TVRemoteAction.TOGGLE_SUBTITLES

            // Number pad for direct channel access (1-9, 0)
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                if (config.hasNumberPad) {
                    TVRemoteAction.JUMP_TO_CHANNEL
                } else {
                    null
                }
            }

            // Media controls
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> TVRemoteAction.PLAY_PAUSE
            KeyEvent.KEYCODE_MEDIA_STOP -> TVRemoteAction.STOP
            KeyEvent.KEYCODE_MEDIA_RECORD -> TVRemoteAction.RECORD

            // Long press handling
            else -> {
                if (event.repeatCount > 0) {
                    // Handle long press (e.g., long press CH+ for fast channel up)
                    when (keyCode) {
                        KeyEvent.KEYCODE_CHANNEL_UP,
                        KeyEvent.KEYCODE_DPAD_UP -> TVRemoteAction.CHANNEL_UP
                        KeyEvent.KEYCODE_CHANNEL_DOWN,
                        KeyEvent.KEYCODE_DPAD_DOWN -> TVRemoteAction.CHANNEL_DOWN
                        else -> null
                    }
                } else {
                    null
                }
            }
        }
    }

    // Get channel number from number pad
    fun getChannelFromNumberPad(
        currentInput: String,
        newDigit: Int
    ): String {
        return if (currentInput.length < 3) {
            currentInput + newDigit.toString()
        } else {
            newDigit.toString()
        }
    }
}