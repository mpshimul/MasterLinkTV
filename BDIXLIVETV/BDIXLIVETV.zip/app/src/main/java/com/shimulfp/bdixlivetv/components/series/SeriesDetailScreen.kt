package com.shimulfp.bdixlivetv.components.series

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.shimulfp.bdixlivetv.models.Episode
import com.shimulfp.bdixlivetv.models.Season
import com.shimulfp.bdixlivetv.models.Series

/**
 * Series Detail Screen - Shows series info with seasons and episodes
 */
@Composable
fun SeriesDetailScreen(
    series: Series,
    onBack: () -> Unit,
    onEpisodeClick: (Episode) -> Unit,
    onSeasonClick: (Season) -> Unit
) {
    var selectedSeason by remember { mutableStateOf(series.getLatestSeason()) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Backdrop & Poster Section
            item {
                SeriesHeader(series = series, onBack = onBack)
            }

            // Info Section
            item {
                SeriesInfo(series = series)
            }

            // Seasons Selector
            item {
                if (series.seasons.size > 1) {
                    SeasonSelector(
                        seasons = series.seasons,
                        selectedSeason = selectedSeason,
                        onSeasonClick = { season ->
                            onSeasonClick(season)
                            selectedSeason = season
                        }
                    )
                }
            }

            // Episodes List
            item {
                selectedSeason?.let { season ->
                    EpisodesList(
                        season = season,
                        seriesTitle = series.title,
                        onEpisodeClick = onEpisodeClick
                    )
                }
            }
        }
    }
}

@Composable
fun SeriesHeader(
    series: Series,
    onBack: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp)
    ) {
        // Backdrop
        if (series.backdrop.isNotEmpty()) {
            AsyncImage(
                model = series.backdrop,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (series.poster.isNotEmpty()) {
            AsyncImage(
                model = series.poster,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            // Placeholder gradient
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF6200EE),
                                Color(0xFF3700B3)
                            )
                        )
                    )
            )
        }

        // Gradient Overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    androidx.compose.ui.graphics.Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0xFF0A0A0A)
                        )
                    )
                )
        )

        // Back Button
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .padding(8.dp)
                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(50))
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White
            )
        }
    }
}

@Composable
fun SeriesInfo(series: Series) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // Title
        Text(
            series.title,
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        if (series.year.isNotEmpty() || series.totalEpisodes > 0) {
            Spacer(modifier = Modifier.height(8.dp))

            // Metadata Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (series.year.isNotEmpty()) {
                    InfoChip(label = series.year)
                }
                if (series.totalEpisodes > 0) {
                    InfoChip(label = "${series.totalEpisodes} Episodes")
                }
                if (series.getSeasonCount() > 1) {
                    InfoChip(label = "${series.getSeasonCount()} Seasons")
                }
                if (series.language.isNotEmpty()) {
                    InfoChip(label = series.language)
                }
            }
        }

        // Description
        if (series.description.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                series.description,
                color = Color.Gray,
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }

        // Genres
        if (series.genres.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(series.genres) { genre ->
                    SuggestionChip(
                        onClick = {},
                        label = { Text(genre, fontSize = 12.sp) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = Color(0xFF1A1A1A),
                            labelColor = Color(0xFF6200EE)
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Divider(color = Color(0xFF333333))

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun InfoChip(label: String) {
    Surface(
        color = Color(0xFF1A1A1A),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFF333333))
    ) {
        Text(
            label,
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun SeasonSelector(
    seasons: List<Season>,
    selectedSeason: Season?,
    onSeasonClick: (Season) -> Unit
) {
    Column {
        Text(
            "Seasons",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(seasons) { season ->
                SeasonChip(
                    season = season,
                    isSelected = selectedSeason?.seasonNumber == season.seasonNumber,
                    onClick = { onSeasonClick(season) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun SeasonChip(
    season: Season,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = {
            Text(
                season.title,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Color(0xFF1A1A1A),
            labelColor = Color.Gray,
            selectedContainerColor = Color(0xFF6200EE),
            selectedLabelColor = Color.White
        )
    )
}

@Composable
fun EpisodesList(
    season: Season,
    seriesTitle: String,
    onEpisodeClick: (Episode) -> Unit
) {
    Column {
        Text(
            "Episodes (${season.episodes.size})",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        season.episodes.forEach { episode ->
            EpisodeItem(
                episode = episode,
                onEpisodeClick = onEpisodeClick
            )
            Divider(color = Color(0xFF1A1A1A))
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun EpisodeItem(
    episode: Episode,
    onEpisodeClick: (Episode) -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    Surface(
        onClick = {
            onEpisodeClick(episode)
        },
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isPressed) Color(0xFF1A1A1A) else Color.Transparent)
            .clickable { isPressed = true },
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Episode Number
            Surface(
                color = Color(0xFF6200EE),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(48.dp, 48.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        episode.episodeNumber.toString(),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Episode Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    episode.getFormattedName(),
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (episode.title.isNotEmpty()) {
                    Text(
                        episode.title,
                        color = Color.Gray,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (episode.quality.isNotEmpty()) {
                    Text(
                        episode.quality,
                        color = Color(0xFF4CAF50),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            // Play Icon
            Icon(
                Icons.Filled.PlayArrow,
                contentDescription = "Play",
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}
