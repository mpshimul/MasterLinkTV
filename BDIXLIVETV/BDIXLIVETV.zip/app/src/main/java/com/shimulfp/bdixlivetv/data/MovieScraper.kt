package com.shimulfp.bdixlivetv.data

import android.content.Context
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory
import com.shimulfp.bdixlivetv.models.StreamUrl
import com.shimulfp.bdixlivetv.models.Subtitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MovieScraper {

    private const val TAG = "MovieScraper"
    private val gson = Gson()

    /**
     * Ensure Python is started
     */
    private fun ensurePythonStarted(context: Context) {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(context))
        }
    }

    /**
     * Scrape all configured BDIX movie servers WITH STOP CHECK
     */
    suspend fun scrapeAllMovies(
        context: Context,
        maxPerServer: Int = 400
    ): List<Movie> {
        return withContext(Dispatchers.IO) {
            try {
                // Check if we should stop before starting
                if (MovieScraperController.shouldStopScraping()) {
                    Log.d(TAG, "🛑 Scraping cancelled before start (GitHub data available)")
                    return@withContext emptyList()
                }

                ensurePythonStarted(context)

                val py = Python.getInstance()
                val module = py.getModule("movie_scraper")

                Log.d(TAG, "🔄 Starting movie scrape (max per server: $maxPerServer)")
                MovieScraperController.setScrapingActive(true)

                val result = module.callAttr("scrape_all_movies", maxPerServer).toString()

                // Check if we should stop after getting result
                if (MovieScraperController.shouldStopScraping()) {
                    Log.d(TAG, "🛑 Scraping cancelled after completion (GitHub data available)")
                    MovieScraperController.setScrapingActive(false)
                    return@withContext emptyList()
                }

                val movies = parseMoviesFromJson(result)

                Log.d(TAG, "✅ Scraped ${movies.size} movies successfully")
                MovieScraperController.setScrapingActive(false)

                movies

            } catch (e: Exception) {
                Log.e(TAG, "❌ Scrape error: ${e.message}", e)
                MovieScraperController.setScrapingActive(false)
                emptyList()
            }
        }
    }

    /**
     * Scrape a single server WITH STOP CHECK
     */
    suspend fun scrapeSingleServer(
        context: Context,
        baseUrl: String,
        category: String = "HINDI",
        language: String = "Hindi",
        serverName: String = "BDIX",
        maxMovies: Int = 400
    ): List<Movie> {
        return withContext(Dispatchers.IO) {
            try {
                // Check stop signal
                if (MovieScraperController.shouldStopScraping()) {
                    Log.d(TAG, "🛑 Single server scrape cancelled")
                    return@withContext emptyList()
                }

                ensurePythonStarted(context)

                val py = Python.getInstance()
                val module = py.getModule("movie_scraper")

                val result = module.callAttr(
                    "scrape_single_server",
                    baseUrl, category, language, serverName, maxMovies
                ).toString()

                // Check stop signal after completion
                if (MovieScraperController.shouldStopScraping()) {
                    Log.d(TAG, "🛑 Single server results discarded (GitHub data available)")
                    return@withContext emptyList()
                }

                parseMoviesFromJson(result)

            } catch (e: Exception) {
                Log.e(TAG, "❌ Single server scrape error: ${e.message}", e)
                emptyList()
            }
        }
    }

    /**
     * Search movies by title WITH STOP CHECK
     */
    suspend fun searchMovies(
        context: Context,
        query: String,
        maxResults: Int = 50
    ): List<Movie> {
        return withContext(Dispatchers.IO) {
            try {
                // Check stop signal
                if (MovieScraperController.shouldStopScraping()) {
                    Log.d(TAG, "🛑 Search cancelled")
                    return@withContext emptyList()
                }

                ensurePythonStarted(context)

                val py = Python.getInstance()
                val module = py.getModule("movie_scraper")

                val result = module.callAttr("search_movies", query, maxResults).toString()

                parseMoviesFromJson(result)

            } catch (e: Exception) {
                Log.e(TAG, "❌ Search error: ${e.message}", e)
                emptyList()
            }
        }
    }

    /**
     * Check if a BDIX server is reachable
     */
    suspend fun checkServerStatus(
        context: Context,
        url: String
    ): ServerStatus {
        return withContext(Dispatchers.IO) {
            try {
                ensurePythonStarted(context)

                val py = Python.getInstance()
                val module = py.getModule("movie_scraper")

                val result = module.callAttr("check_server_status", url).toString()
                val json = gson.fromJson(result, Map::class.java)

                ServerStatus(
                    url = json["url"] as? String ?: url,
                    isReachable = json["reachable"] as? Boolean ?: false,
                    statusCode = (json["status"] as? Double)?.toInt() ?: 0
                )

            } catch (e: Exception) {
                Log.e(TAG, "❌ Server check error: ${e.message}", e)
                ServerStatus(url, false, 0)
            }
        }
    }

    /**
     * Parse JSON response to Movie list
     */
    private fun parseMoviesFromJson(json: String): List<Movie> {
        return try {
            // Check for error response
            if (json.contains("\"error\"") && !json.startsWith("[")) {
                val errorMap = gson.fromJson(json, Map::class.java)
                Log.e(TAG, "API error: ${errorMap["error"]}")
                return emptyList()
            }

            val type = object : TypeToken<List<MovieJsonModel>>() {}.type
            val movieJsonList: List<MovieJsonModel> = gson.fromJson(json, type) ?: emptyList()

            movieJsonList.map { it.toMovie() }

        } catch (e: Exception) {
            Log.e(TAG, "JSON parse error: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Internal JSON model matching Python output
     */
    private data class MovieJsonModel(
        val id: String = "",
        val title: String = "",
        val originalTitle: String = "",
        val year: String = "",
        val quality: String = "HD",
        val language: String = "",
        val poster: String = "",
        val backdrop: String = "",
        val description: String = "",
        val genres: List<String> = emptyList(),
        val cast: List<String> = emptyList(),
        val director: String = "",
        val duration: String = "",
        val rating: String = "",
        val streamUrls: List<StreamUrlJson> = emptyList(),
        val subtitles: List<SubtitleJson> = emptyList(),
        val source: String = "BDIX",
        val serverName: String = "",
        val category: String = "HINDI",
        val folderUrl: String = "",
        val last_modified: String = "",
        val last_modified_timestamp: Long = 0,
        val folder_modified: String = "",
        val folder_modified_timestamp: Long = 0,
        val addedDate: Long = 0,
        val audioInfo: String = "",
        val codec: String = "",
        val isFavorite: Boolean = false,
        val watchProgress: Double = 0.0,
        val lastWatched: Long = 0

    ) {
        fun toMovie(): Movie {
            return Movie(
                id = id,
                title = title,
                originalTitle = originalTitle,
                year = year,
                quality = quality,
                language = language,
                poster = poster,
                backdrop = backdrop,
                description = description,
                genres = genres,
                cast = cast,
                director = director,
                duration = duration,
                rating = rating,
                streamUrls = streamUrls.map { it.toStreamUrl() },
                subtitles = subtitles.map { it.toSubtitle() },
                source = source,
                serverName = serverName,
                category = MovieCategory.fromApiName(category),
                folderUrl = folderUrl,
                lastModified = last_modified,
                lastModifiedTimestamp = last_modified_timestamp,
                folderModified = folder_modified,
                folderModifiedTimestamp = folder_modified_timestamp,
                addedDate = if (addedDate > 0) addedDate else System.currentTimeMillis(),
                audioInfo = audioInfo,
                codec = codec,
                isFavorite = isFavorite,
                watchProgress = watchProgress.toFloat(),
                lastWatched = lastWatched
            )
        }
    }

    private data class StreamUrlJson(
        val url: String = "",
        val quality: String = "HD",
        val server: String = "BDIX",
        val fileName: String = "",
        val isWorking: Boolean = true
    ) {
        fun toStreamUrl() = StreamUrl(url, quality, server, fileName, isWorking)
    }

    private data class SubtitleJson(
        val url: String = "",
        val language: String = "",
        val label: String = ""
    ) {
        fun toSubtitle() = Subtitle(url, language, label)
    }

    data class ServerStatus(
        val url: String,
        val isReachable: Boolean,
        val statusCode: Int
    )
}