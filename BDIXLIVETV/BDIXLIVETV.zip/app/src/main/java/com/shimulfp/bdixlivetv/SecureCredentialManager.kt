package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Base64
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object SecureCredentialManager {
    private const val TAG = "SecureCredentialManager"
    private const val PREFS_NAME = "secure_credentials"
    private const val KEY_USERNAME = "encrypted_username"
    private const val KEY_PASSWORD = "encrypted_password"
    private const val KEY_DEVICE_ID = "encrypted_device_id"
    private const val KEY_ALIAS = "aynaott_key"

    // Fallback to Firebase Remote Config
    private const val REMOTE_USERNAME_KEY = "AYNA_USERNAME"
    private const val REMOTE_PASSWORD_KEY = "AYNA_PASSWORD"
    private const val REMOTE_DEVICE_ID_KEY = "AYNA_DEVICE_ID"

    data class Credentials(
        val username: String,
        val password: String,
        val deviceId: String = ""
    )

    /**
     * Store credentials securely
     */
    suspend fun storeCredentials(
        context: Context,
        username: String,
        password: String,
        deviceId: String = ""
    ): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            // Create MasterKey
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            // Create EncryptedSharedPreferences
            val sharedPreferences = EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )

            // Store encrypted values
            with(sharedPreferences.edit()) {
                putString(KEY_USERNAME, encryptAES(context, username))
                putString(KEY_PASSWORD, encryptAES(context, password))
                if (deviceId.isNotEmpty()) {
                    putString(KEY_DEVICE_ID, encryptAES(context, deviceId))
                }
                apply()
            }

            Log.d(TAG, "Credentials stored securely")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to store credentials: ${e.message}")
            false
        }
    }

    /**
     * Retrieve credentials
     */
    suspend fun getCredentials(context: Context): Credentials = withContext(Dispatchers.IO) {
        return@withContext try {
            // Try to get from secure storage first
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            val sharedPreferences = EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )

            val encryptedUsername = sharedPreferences.getString(KEY_USERNAME, null)
            val encryptedPassword = sharedPreferences.getString(KEY_PASSWORD, null)
            val encryptedDeviceId = sharedPreferences.getString(KEY_DEVICE_ID, null)

            if (encryptedUsername != null && encryptedPassword != null) {
                val username = decryptAES(context, encryptedUsername)
                val password = decryptAES(context, encryptedPassword)
                val deviceId = encryptedDeviceId?.let { decryptAES(context, it) } ?: ""

                Log.d(TAG, "Retrieved credentials from secure storage")
                Credentials(username, password, deviceId)
            } else {
                // Fallback to Firebase Remote Config
                Log.d(TAG, "No local credentials, fetching from Firebase...")
                fetchFromFirebase(context)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error retrieving credentials: ${e.message}")
            // Fallback to Firebase
            fetchFromFirebase(context)
        }
    }

    /**
     * Fetch credentials from Firebase Remote Config
     */
    private suspend fun fetchFromFirebase(context: Context): Credentials {
        return try {
            val remoteConfig = FirebaseRemoteConfig.getInstance()

            // Fetch and activate config
            remoteConfig.fetchAndActivate().await()

            val username = remoteConfig.getString(REMOTE_USERNAME_KEY)
            val password = remoteConfig.getString(REMOTE_PASSWORD_KEY)
            val deviceId = remoteConfig.getString(REMOTE_DEVICE_ID_KEY)

            if (username.isEmpty() || password.isEmpty()) {
                throw IllegalStateException("No credentials in Firebase Remote Config")
            }

            // Store securely for future use
            storeCredentials(context, username, password, deviceId)

            Log.d(TAG, "Fetched credentials from Firebase")
            Credentials(username, password, deviceId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch from Firebase: ${e.message}")
            throw CredentialException("No credentials available")
        }
    }

    /**
     * Check if credentials exist
     */
    suspend fun hasCredentials(context: Context): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            val sharedPreferences = EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )

            sharedPreferences.contains(KEY_USERNAME) &&
                    sharedPreferences.contains(KEY_PASSWORD)
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Clear stored credentials
     */
    fun clearCredentials(context: Context) {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            val sharedPreferences = EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )

            sharedPreferences.edit().clear().apply()
            Log.d(TAG, "Credentials cleared")
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing credentials: ${e.message}")
        }
    }

    /**
     * AES Encryption using Android Keystore
     */
    private fun encryptAES(context: Context, data: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val key = getOrCreateKey()

        cipher.init(Cipher.ENCRYPT_MODE, key)

        // Store IV
        val iv = cipher.iv
        val ivPrefs = context.getSharedPreferences("crypto_ivs", Context.MODE_PRIVATE)
        ivPrefs.edit().putString(KEY_ALIAS, Base64.encodeToString(iv, Base64.NO_WRAP)).apply()

        val encryptedBytes = cipher.doFinal(data.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)
    }

    /**
     * AES Decryption using Android Keystore
     */
    private fun decryptAES(context: Context, encryptedData: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val key = getOrCreateKey()

        // Get stored IV
        val ivPrefs = context.getSharedPreferences("crypto_ivs", Context.MODE_PRIVATE)
        val ivString = ivPrefs.getString(KEY_ALIAS, null)
            ?: throw IllegalStateException("No IV found")

        val iv = Base64.decode(ivString, Base64.NO_WRAP)
        val spec = GCMParameterSpec(128, iv)

        cipher.init(Cipher.DECRYPT_MODE, key, spec)

        val encryptedBytes = Base64.decode(encryptedData, Base64.NO_WRAP)
        val decryptedBytes = cipher.doFinal(encryptedBytes)
        return String(decryptedBytes, Charsets.UTF_8)
    }

    /**
     * Get or create encryption key in Android Keystore
     */
    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore")
        keyStore.load(null)

        return if (keyStore.containsAlias(KEY_ALIAS)) {
            (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
        } else {
            val keyGenerator = KeyGenerator.getInstance(
                android.security.keystore.KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore"
            )

            val keyGenParameterSpec = android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                        android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()

            keyGenerator.init(keyGenParameterSpec)
            keyGenerator.generateKey()
        }
    }

    class CredentialException(message: String) : Exception(message)
}