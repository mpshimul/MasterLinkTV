package com.shimulfp.bdixlivetv.components.home

import androidx.compose.animation.animateColorAsState
//import androidx.compose.animation.core.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shimulfp.bdixlivetv.Channel
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.components.TvChannelCard
import com.shimulfp.bdixlivetv.components.TvMovieCard

@Composable
fun HomeContent(
    bdixChannels: List<Channel>,
    aynaChannels: List<Channel>,
    isSyncing: Boolean,
    showDebugInfo: Boolean,
    pythonStatus: String,
    isBdixAvailable: Boolean,
    isCheckingBdix: Boolean,
    bdixStatusMessage: String,
    cacheAgeMinutes: Long,
    githubTokenAvailable: Boolean,
    isBackgroundSyncing: Boolean,
    lastSyncStatus: String?,
    lastSyncTime: Long,
    onToggleDebugInfo: () -> Unit,
    onRefreshChannels: () -> Unit,
    onManualRefresh: () -> Unit,
    onRetryBdixCheck: () -> Unit,
    onManualSync: () -> Unit,
    onMoviesClick: () -> Unit,
    onMovieClick: (Movie) -> Unit,
    onMoviePlayClick: (Movie) -> Unit,
    recentMovies: List<Movie> = emptyList()
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
    ) {
        // Hero Banner
        item {
            HeroBanner(
                bdixAvailable = isBdixAvailable,
                bdixChannelsCount = bdixChannels.size,
                aynaChannelsCount = aynaChannels.size,
                githubTokenAvailable = githubTokenAvailable
            )
        }

        // Quick Actions Row
        item {
            QuickActions(
                onMoviesClick = onMoviesClick,
                bdixChannelsCount = bdixChannels.size,
                aynaChannelsCount = aynaChannels.size
            )
        }

        // Status Card
        item {
            StatusCard(
                isSyncing = isSyncing,
                pythonStatus = pythonStatus,
                isBdixAvailable = isBdixAvailable,
                isCheckingBdix = isCheckingBdix,
                bdixStatusMessage = bdixStatusMessage,
                githubTokenAvailable = githubTokenAvailable,
                isBackgroundSyncing = isBackgroundSyncing,
                bdixChannelsCount = bdixChannels.size,
                onToggleDebugInfo = onToggleDebugInfo,
                onManualRefresh = onManualRefresh,
                onManualSync = onManualSync,
                onRetryBdixCheck = onRetryBdixCheck
            )
        }

        // Syncing Indicator
        if (isSyncing) {
            item {
                SyncingIndicator(pythonStatus = pythonStatus)
            }
        }

        // BDIX Channels Section
        if (bdixChannels.isNotEmpty()) {
            item {
                ChannelRow(
                    channels = bdixChannels,
                    channelColor = if (isBdixAvailable) Color.Cyan else Color.Gray,
                    sourceName = "BDIX",
                    isEnabled = isBdixAvailable,
                    isTvOptimized = true
                )
            }

            if (!isBdixAvailable) {
                item {
                    BdixUnavailableCard(
                        bdixChannelsCount = bdixChannels.size,
                        onRetryBdixCheck = onRetryBdixCheck
                    )
                }
            }
        }

        // AynaOTT Channels Section
        if (aynaChannels.isNotEmpty()) {
            item {
                ChannelRow(
                    channels = aynaChannels,
                    channelColor = Color.Magenta,
                    sourceName = "AynaOTT",
                    isEnabled = true,
                    isTvOptimized = true
                )
            }
        }

        // Movies Section
        if (recentMovies.isNotEmpty()) {
            item {
                MoviesSection(
                    movies = recentMovies,
                    onMoviesClick = onMoviesClick,
                    onMovieClick = onMovieClick,
                    onMoviePlayClick = onMoviePlayClick
                )
            }
        }
    }
}

@Composable
private fun HeroBanner(
    bdixAvailable: Boolean,
    bdixChannelsCount: Int,
    aynaChannelsCount: Int,
    githubTokenAvailable: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color(0xFF0A0A0A), Color(0xFF1A1A1A), Color(0xFF0A0A0A))
                )
            )
            .padding(16.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Column {
            Text(
                "BDIX TV",
                color = Color.Red,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Watch Live TV & Movies",
                color = Color.White,
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // BDIX Badge
                Text(
                    text = if (bdixAvailable) "BDIX Online • $bdixChannelsCount channels"
                    else "BDIX Offline • $bdixChannelsCount channels",
                    modifier = Modifier
                        .background(
                            if (bdixAvailable) Color.Cyan.copy(alpha = 0.2f)
                            else Color.Gray.copy(alpha = 0.2f),
                            RoundedCornerShape(16.dp)
                        )
                        .border(
                            1.dp,
                            if (bdixAvailable) Color.Cyan else Color.Gray,
                            RoundedCornerShape(16.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    color = if (bdixAvailable) Color.Cyan else Color.Gray,
                    fontSize = 12.sp
                )

                // AynaOTT Badge
                Text(
                    "AynaOTT • $aynaChannelsCount channels",
                    modifier = Modifier
                        .background(Color.Magenta.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                        .border(1.dp, Color.Magenta, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    color = Color.Magenta,
                    fontSize = 12.sp
                )

                // GitHub Badge
                if (githubTokenAvailable) {
                    Text(
                        "GitHub Sync",
                        modifier = Modifier
                            .background(Color.Green.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                            .border(1.dp, Color.Green, RoundedCornerShape(16.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        color = Color.Green,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickActions(
    onMoviesClick: () -> Unit,
    bdixChannelsCount: Int,
    aynaChannelsCount: Int
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Movies Button
        Card(
            onClick = onMoviesClick,
            modifier = Modifier.weight(1f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Movie, null, tint = Color.Red, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Movies", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Watch HD Movies", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }

        // Live TV Button
        Card(
            onClick = { /* Already on home */ },
            modifier = Modifier.weight(1f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.LiveTv, null, tint = Color.Magenta, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Live TV", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("${bdixChannelsCount + aynaChannelsCount} channels", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun StatusCard(
    isSyncing: Boolean,
    pythonStatus: String,
    isBdixAvailable: Boolean,
    isCheckingBdix: Boolean,
    bdixStatusMessage: String,
    githubTokenAvailable: Boolean,
    isBackgroundSyncing: Boolean,
    bdixChannelsCount: Int,
    onToggleDebugInfo: () -> Unit,
    onManualRefresh: () -> Unit,
    onManualSync: () -> Unit,
    onRetryBdixCheck: () -> Unit
) {
    val borderColor by animateColorAsState(
        targetValue = when {
            !isBdixAvailable && bdixChannelsCount > 0 -> Color.Yellow
            isSyncing -> Color.Blue
            else -> Color.Green
        },
        animationSpec = tween(150),
        label = "borderColor"
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            !isBdixAvailable && bdixChannelsCount > 0 -> Color.Yellow.copy(alpha = 0.1f)
            isSyncing -> Color.Blue.copy(alpha = 0.1f)
            else -> Color.Green.copy(alpha = 0.1f)
        },
        animationSpec = tween(150),
        label = "bgColor"
    )

    val statusColor by animateColorAsState(
        targetValue = when {
            !isBdixAvailable && bdixChannelsCount > 0 -> Color.Yellow
            isSyncing -> Color.Blue
            else -> Color.Green
        },
        animationSpec = tween(150),
        label = "statusColor"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .background(bgColor, RoundedCornerShape(8.dp))
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onToggleDebugInfo() }
            .padding(12.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        "Channel Status",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        pythonStatus,
                        color = statusColor,
                        fontSize = 12.sp
                    )
                }

                Row {
                    if (isCheckingBdix) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    IconButton(
                        onClick = onManualRefresh,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.Refresh, "Refresh", tint = Color.White)
                    }

                    if (githubTokenAvailable) {
                        IconButton(
                            onClick = onManualSync,
                            modifier = Modifier.size(24.dp),
                            enabled = !isBackgroundSyncing
                        ) {
                            Icon(
                                Icons.Default.CloudSync,
                                "GitHub Sync",
                                tint = if (isBackgroundSyncing) Color.Blue else Color.Green
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SyncingIndicator(pythonStatus: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .background(Color.Green.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            CircularProgressIndicator(
                color = Color.Green,
                strokeWidth = 2.dp,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "Loading channels...",
                color = Color.Green,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun BdixUnavailableCard(
    bdixChannelsCount: Int,
    onRetryBdixCheck: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .background(Color(0xFF1A1A1A), RoundedCornerShape(12.dp))
            .border(1.dp, Color.Yellow, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                Icons.Default.WifiOff,
                null,
                tint = Color.Yellow,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Connect to BDIX Network",
                color = Color.Yellow,
                fontWeight = FontWeight.Bold
            )
            Text(
                "$bdixChannelsCount BDIX channels available",
                color = Color.Gray,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onRetryBdixCheck,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Yellow,
                    contentColor = Color.Black
                )
            ) {
                Text("Check Now")
            }
        }
    }
}

@Composable
private fun ChannelRow(
    channels: List<Channel>,
    channelColor: Color,
    sourceName: String,
    isEnabled: Boolean,
    isTvOptimized: Boolean = false
) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                sourceName,
                color = channelColor,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Text(
                "${channels.size} channels",
                color = channelColor,
                fontSize = 12.sp,
                modifier = Modifier
                    .background(
                        channelColor.copy(alpha = 0.2f),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }

        if (isTvOptimized) {
            // Use TV-optimized cards
            TvChannelRow(channels = channels, isEnabled = isEnabled)
        } else {
            // Use original cards
            OriginalChannelRow(channels = channels, isEnabled = isEnabled)
        }
    }
}

@Composable
private fun TvChannelRow(
    channels: List<Channel>,
    isEnabled: Boolean
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.height(180.dp)
    ) {
        itemsIndexed(channels) { index, channel ->
            TvChannelCard(
                channelName = channel.name,
                channelLogo = channel.logo,
                isSelected = false,
                isPlaying = false,
                onClick = { /* Handle channel click */ }
            )
        }
    }
}

@Composable
private fun OriginalChannelRow(
    channels: List<Channel>,
    isEnabled: Boolean
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.height(160.dp)
    ) {
        itemsIndexed(channels) { index, channel ->
            // Original channel card implementation
            // ... (use your existing channel card logic)
        }
    }
}

@Composable
private fun MoviesSection(
    movies: List<Movie>,
    onMoviesClick: () -> Unit,
    onMovieClick: (Movie) -> Unit,
    onMoviePlayClick: (Movie) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        // Header row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "🎬 Movies",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            TextButton(onClick = onMoviesClick) {
                Text("See All", color = Color.Red)
                Icon(Icons.Default.ChevronRight, null, tint = Color.Red)
            }
        }

        // Movies row
        if (movies.isNotEmpty()) {
            TvMovieRow(
                movies = movies.take(10),
                onMovieClick = onMovieClick,
                onMoviePlayClick = onMoviePlayClick
            )
        } else {
            // Loading placeholders
            LoadingPlaceholders(count = 5)
        }
    }
}

@Composable
private fun TvMovieRow(
    movies: List<Movie>,
    onMovieClick: (Movie) -> Unit,
    onMoviePlayClick: (Movie) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(movies, key = { it.id }) { movie ->
            TvMovieCard(
                movieTitle = movie.title,
                moviePoster = movie.poster,
                movieQuality = movie.quality,
                movieYear = movie.year,
                isFavorite = false,
                isSelected = false,
                onClick = { onMovieClick(movie) }
            )
        }
    }
}

@Composable
private fun LoadingPlaceholders(count: Int) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(count) {
            Box(
                modifier = Modifier
                    .width(140.dp)
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E1E1E))
                    .border(1.dp, Color(0xFF333333), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = Color.Red,
                    strokeWidth = 2.dp
                )
            }
        }
    }
}
