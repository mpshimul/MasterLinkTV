package com.shimulfp.bdixlivetv

import android.content.Context
import android.util.Log
import com.google.firebase.ktx.Firebase
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.ktx.remoteConfig
import com.google.firebase.remoteconfig.ktx.remoteConfigSettings
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

class FirebaseManager(private val context: Context) {
    private val TAG = "FirebaseManager"
    private val remoteConfig: FirebaseRemoteConfig = Firebase.remoteConfig

    init {
        val configSettings = remoteConfigSettings {
            minimumFetchIntervalInSeconds = if (BuildConfig.DEBUG) 0L else 3600L  // Changed to Long
            fetchTimeoutInSeconds = 30L  // Changed to Long
        }

        remoteConfig.setConfigSettingsAsync(configSettings)

        // Set default values with your actual credentials
        remoteConfig.setDefaultsAsync(mapOf(
            "GITHUB_TOKEN" to "",
            "AYNA_USERNAME" to "shimulfp@gmail.com", // Add your default
            "AYNA_PASSWORD" to "", // Leave empty for security
            "AYNA_DEVICE_ID" to "C6C015EFBB5C67CDBADD84E72DBF3474"
        ))

        Log.d(TAG, "FirebaseManager initialized with default username: shimulfp@gmail.com")
    }

    suspend fun fetchAndActivate(): Boolean {
        return try {
            remoteConfig.fetchAndActivate().await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching remote config: ${e.message}")
            false
        }
    }

    fun getGitHubToken(): String {
        return remoteConfig.getString("GITHUB_TOKEN")
    }

    fun getAynaUsername(): String? {
        val username = remoteConfig.getString("AYNA_USERNAME")
        return if (username.isNotEmpty()) username else null
    }

    fun getAynaPassword(): String? {
        val password = remoteConfig.getString("AYNA_PASSWORD")
        return if (password.isNotEmpty()) password else null
    }

    fun getDeviceId(): String {
        val deviceId = remoteConfig.getString("AYNA_DEVICE_ID")
        return if (deviceId.isNotEmpty()) deviceId else generateDeviceId()
    }

    // Add this method to get all credentials at once
    fun getAynaCredentials(): Triple<String?, String?, String> {
        val username = getAynaUsername()
        val password = getAynaPassword()
        val deviceId = getDeviceId()

        Log.d(TAG, "Retrieved credentials - Username: ${username?.take(5)}..., Device: ${deviceId.take(10)}...")

        return Triple(username, password, deviceId)
    }

    private fun generateDeviceId(): String {
        val prefs = context.getSharedPreferences("device_info", Context.MODE_PRIVATE)
        var deviceId = prefs.getString("device_id", null)

        if (deviceId == null) {
            deviceId = "bdix_${System.currentTimeMillis()}_${(100000..999999).random()}"
            prefs.edit().putString("device_id", deviceId).apply()
        }

        return deviceId
    }

    fun saveAynaCredentials(username: String, password: String) {
        val prefs = context.getSharedPreferences("ayna_credentials", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("username", username)
            .putString("password", password)
            .putLong("last_saved", System.currentTimeMillis())
            .apply()

        Log.d(TAG, "AynaOTT credentials saved locally")
    }

    fun shouldUpdateToken(): Boolean {
        val prefs = context.getSharedPreferences("ayna_credentials", Context.MODE_PRIVATE)
        val lastSaved = prefs.getLong("last_saved", 0)

        // Update token every 8 hours
        val eightHours = TimeUnit.HOURS.toMillis(8)
        return System.currentTimeMillis() - lastSaved > eightHours
    }
}
