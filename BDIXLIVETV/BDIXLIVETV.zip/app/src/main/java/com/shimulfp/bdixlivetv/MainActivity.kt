package com.shimulfp.bdixlivetv

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.MovieCategory
import com.shimulfp.bdixlivetv.models.StreamUrl
import com.shimulfp.bdixlivetv.viewmodel.MovieViewModel
import com.shimulfp.bdixlivetv.viewmodel.MovieUiState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
//import androidx.compose.ui.focus.focusable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.media3.common.util.UnstableApi

enum class NavTarget {
    HOME,
    ALL_CONTENT,
    MOVIES,              // Main movies screen
    MOVIE_DETAIL,        // Movie detail screen
    MOVIES_HINDI,
    MOVIES_SOUTH,
    MOVIES_HOLLYWOOD,
    SERIES_KOREAN,
    SEARCH,
    SETTINGS,
    PYTHON_TEST
}

class MainActivity : ComponentActivity() {
    private lateinit var channelViewModel: ChannelViewModel

    @UnstableApi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize ViewModel
        channelViewModel = ViewModelProvider(this)[ChannelViewModel::class.java]

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setRealFullscreen()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                this.MainScreen(channelViewModel = channelViewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        ServerPingHelper.setAppForegroundState(true)
        ServerPingHelper.forceImmediateCheck(this)
    }

    override fun onPause() {
        super.onPause()
        ServerPingHelper.setAppForegroundState(false)
    }

    private fun setRealFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    @androidx.media3.common.util.UnstableApi
    @SuppressLint("CoroutineCreationDuringComposition", "ContextCastToActivity")
    @Composable
    fun MainScreen(channelViewModel: ChannelViewModel) {
        val context = LocalContext.current as MainActivity

        // Navigation state
        var currentNav by remember { mutableStateOf(NavTarget.HOME) }
        var previousNav by remember { mutableStateOf(NavTarget.HOME) }

        // Channel states
        var allChannels by remember { mutableStateOf(emptyList<Channel>()) }
        var bdixChannels by remember { mutableStateOf(emptyList<Channel>()) }
        var aynaChannels by remember { mutableStateOf(emptyList<Channel>()) }
        var isSyncing by remember { mutableStateOf(false) }
        var showExitDialog by remember { mutableStateOf(false) }
        var initialLoadComplete by remember { mutableStateOf(false) }
        var showDebugInfo by remember { mutableStateOf(false) }
        var pythonStatus by remember { mutableStateOf("Loading...") }
        var showPythonDebugDialog by remember { mutableStateOf(false) }
        var refreshTrigger by remember { mutableIntStateOf(0) }
        var isBdixAvailable by remember { mutableStateOf(false) }
        var isCheckingBdix by remember { mutableStateOf(false) }
        var bdixStatusMessage by remember { mutableStateOf("Checking...") }
        var cacheAgeMinutes by remember { mutableStateOf(0L) }

        // GitHub sync states
        var isBackgroundSyncing by remember { mutableStateOf(false) }
        var lastSyncStatus by remember { mutableStateOf<String?>(null) }
        var lastSyncTime by remember { mutableStateOf(0L) }
        var githubTokenAvailable by remember { mutableStateOf(false) }

        // Movie states
        var selectedMovie by remember { mutableStateOf<Movie?>(null) }
        val movieViewModel: MovieViewModel = viewModel()

        // Helper function to separate channels by source
        fun separateChannelsBySource(channels: List<Channel>): Pair<List<Channel>, List<Channel>> {
            val bdixList = mutableListOf<Channel>()
            val aynaList = mutableListOf<Channel>()

            channels.forEach { channel ->
                when {
                    channel.isAynaChannel() -> aynaList.add(channel)
                    channel.isBdixChannel() -> bdixList.add(channel)
                }
            }

            return Pair(bdixList, aynaList)
        }

        // Update ViewModel when channels change
        LaunchedEffect(allChannels) {
            if (allChannels.isNotEmpty()) {
                channelViewModel.updateChannels(allChannels)
            }
        }

        // Monitor BDIX status changes
        LaunchedEffect(Unit) {
            ServerPingHelper.bdixStatus.collectLatest { status ->
                status?.let {
                    when (it) {
                        is ServerPingHelper.BdixStatus.Checking -> {
                            isCheckingBdix = true
                            bdixStatusMessage = "Checking BDIX servers..."
                        }
                        is ServerPingHelper.BdixStatus.Available -> {
                            isCheckingBdix = false
                            isBdixAvailable = true
                            val availableStatus = it as ServerPingHelper.BdixStatus.Available
                            bdixStatusMessage = "${availableStatus.reachableServers}/${availableStatus.totalServers} servers online"
                        }
                        is ServerPingHelper.BdixStatus.Unavailable -> {
                            isCheckingBdix = false
                            isBdixAvailable = false
                            bdixStatusMessage = "BDIX servers unavailable"
                        }
                        is ServerPingHelper.BdixStatus.BackgroundLimited -> {
                            isCheckingBdix = false
                            bdixStatusMessage = "Using cached status (background)"
                        }
                        ServerPingHelper.BdixStatus.Unknown -> {
                            isCheckingBdix = false
                            bdixStatusMessage = "Status unknown"
                        }
                    }
                } ?: run {
                    isCheckingBdix = false
                    bdixStatusMessage = "Status not initialized"
                }
            }
        }

        // Initialize GitHub token check
        LaunchedEffect(Unit) {
            val firebaseManager = FirebaseManager(this@MainActivity)
            val token = firebaseManager.getGitHubToken()
            githubTokenAvailable = token.isNotEmpty()

            if (githubTokenAvailable) {
                GitHubDataManager.initialize(token)
                Log.d("GITHUB_SYNC", "GitHub sync manager initialized")
            }

            val syncLogFile = File(this@MainActivity.filesDir, "github_sync_log.json")
            if (syncLogFile.exists()) {
                try {
                    val log = JSONObject(syncLogFile.readText())
                    lastSyncTime = log.optLong("last_sync_time", 0)
                } catch (e: Exception) {
                    Log.e("SYNC_LOG", "Error loading sync log: ${e.message}")
                }
            }
        }

        // Update cache age periodically
        LaunchedEffect(Unit) {
            while (true) {
                delay(10 * 1000)
                val cacheFile = File(context.filesDir, "all_channels_cache.json")
                if (cacheFile.exists()) {
                    val ageMinutes = (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000)
                    cacheAgeMinutes = ageMinutes
                }
            }
        }

        // Background GitHub sync system
        LaunchedEffect(Unit) {
            while (true) {
                delay(5 * 60 * 1000)

                if (githubTokenAvailable && !isBackgroundSyncing) {
                    val shouldSync = GitHubDataManager.shouldRunSync(this@MainActivity)

                    if (shouldSync) {
                        isBackgroundSyncing = true
                        lastSyncStatus = "🔄 Checking GitHub data..."

                        CoroutineScope(Dispatchers.IO).launch {
                            try {
                                val firebaseManager = FirebaseManager(this@MainActivity)
                                val token = firebaseManager.getGitHubToken()

                                if (token.isNotEmpty()) {
                                    GitHubDataManager.initialize(token)
                                    val result = GitHubDataManager.checkAndSyncData(this@MainActivity)

                                    lastSyncStatus = when (result) {
                                        is GitHubDataManager.SyncResult.NoToken -> "⚠️ No GitHub token"
                                        is GitHubDataManager.SyncResult.Downloaded ->
                                            "✅ Using GitHub data (${result.ageMinutes}m old)"
                                        is GitHubDataManager.SyncResult.ScrapedAndUploaded ->
                                            "✅ Fresh data scraped & uploaded (${result.channelCount} channels)"
                                        is GitHubDataManager.SyncResult.ScrapedOnly ->
                                            "✅ Fresh data scraped (${result.channelCount} channels)"
                                        is GitHubDataManager.SyncResult.ScrapingFailed ->
                                            "❌ Scraping failed"
                                        is GitHubDataManager.SyncResult.Error ->
                                            "⚠️ Sync error: ${result.message}"
                                    }

                                    lastSyncTime = System.currentTimeMillis()
                                    saveSyncLog(this@MainActivity, result)
                                } else {
                                    lastSyncStatus = "⚠️ GitHub token not available"
                                    githubTokenAvailable = false
                                }
                            } catch (e: Exception) {
                                lastSyncStatus = "❌ Sync error: ${e.message}"
                                Log.e("BACKGROUND_SYNC", "Error: ${e.message}")
                            } finally {
                                isBackgroundSyncing = false
                            }
                        }
                    }
                }
            }
        }

        // Initial loading sequence
        LaunchedEffect(Unit, refreshTrigger) {
            if (initialLoadComplete && refreshTrigger == 0) return@LaunchedEffect

            isSyncing = true
            pythonStatus = "🔄 Loading channels..."

            FirebaseSetupHelper.initializeFirebase(this@MainActivity)

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    PythonScriptsDownloader.initialize(this@MainActivity)
                } catch (e: Exception) {
                    Log.e("SCRIPTS", "Scripts init error: ${e.message}")
                }
            }

            val firebaseManager = FirebaseManager(this@MainActivity)
            firebaseManager.fetchAndActivate()
            var username = firebaseManager.getAynaUsername()
            var password = firebaseManager.getAynaPassword()

            if (username == null || password == null || password!!.isEmpty()) {
                username = "shimulfp@gmail.com"
                password = ""
            }

            val cacheResult = ChannelCacheManager.loadChannelsWithSmartCache(
                context = this@MainActivity,
                username = username,
                password = password
            )

            allChannels = cacheResult.allChannels
            val (bdixList, aynaList) = separateChannelsBySource(allChannels)
            bdixChannels = bdixList
            aynaChannels = aynaList

            val cacheFile = File(this@MainActivity.filesDir, "all_channels_cache.json")
            if (cacheFile.exists()) {
                cacheAgeMinutes = (System.currentTimeMillis() - cacheFile.lastModified()) / (60 * 1000)
            }

            pythonStatus = buildString {
                append("✅ ${allChannels.size} channels")
                if (bdixChannels.isNotEmpty()) {
                    append(" (BDIX: ${bdixChannels.size})")
                }
                if (aynaChannels.isNotEmpty()) {
                    append(" | Ayna: ${aynaChannels.size}")
                }
                if (cacheResult.isFromCache) {
                    append(" [Cached ${cacheAgeMinutes}m ago]")
                    if (cacheResult.needsBackgroundRefresh) {
                        append(" • Refreshing in background...")
                    }
                } else {
                    append(" [Live]")
                }
            }

            CoroutineScope(Dispatchers.IO).launch {
                ServerPingHelper.checkBdixServers(this@MainActivity)
            }

            isSyncing = false
            initialLoadComplete = true
            channelViewModel.updateChannels(allChannels)
        }

        // Auto-refresh check
        LaunchedEffect(Unit) {
            while (true) {
                delay(30 * 1000)

                if (allChannels.isNotEmpty()) {
                    val cacheIsOld = ChannelCacheManager.isCacheOlderThan(
                        context = this@MainActivity,
                        minutes = if (BuildConfig.DEBUG) 20 else 50
                    )

                    if (cacheIsOld) {
                        Log.d("AUTO_REFRESH", "Cache is older than threshold, triggering refresh...")

                        val firebaseManager = FirebaseManager(this@MainActivity)
                        var username = firebaseManager.getAynaUsername()
                        var password = firebaseManager.getAynaPassword()

                        if (username == null || password == null || password!!.isEmpty()) {
                            username = "shimulfp@gmail.com"
                            password = ""
                        }

                        ChannelCacheManager.startBackgroundRefresh(
                            context = this@MainActivity,
                            username = username,
                            password = password
                        )
                    }
                }
            }
        }

        // Back handler
        BackHandler {
            when (currentNav) {
                NavTarget.MOVIE_DETAIL -> {
                    currentNav = NavTarget.MOVIES
                    selectedMovie = null
                }
                NavTarget.MOVIES, NavTarget.MOVIES_HINDI, NavTarget.MOVIES_SOUTH, NavTarget.MOVIES_HOLLYWOOD -> {
                    currentNav = NavTarget.HOME
                }
                NavTarget.PYTHON_TEST -> {
                    currentNav = NavTarget.HOME
                }
                else -> {
                    showExitDialog = true
                }
            }
        }

        // Dialogs
        if (showExitDialog) {
            AlertDialog(
                onDismissRequest = { showExitDialog = false },
                title = { Text("Exit App") },
                text = { Text("Are you sure you want to exit?") },
                confirmButton = {
                    TextButton(onClick = { context.finish() }) {
                        Text("Exit", color = Color.Red)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showExitDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        if (showPythonDebugDialog) {
            AlertDialog(
                onDismissRequest = { showPythonDebugDialog = false },
                title = { Text("Python Debug Info") },
                text = {
                    Column {
                        Text("Status: $pythonStatus",
                            color = when {
                                pythonStatus.contains("✅") -> Color.Green
                                pythonStatus.contains("⚠️") -> Color.Yellow
                                pythonStatus.contains("❌") -> Color.Red
                                else -> Color.White
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Channels Loaded: ${allChannels.size}",
                            color = if (allChannels.isNotEmpty()) Color.Green else Color.Red
                        )
                        Text("BDIX Available: $isBdixAvailable",
                            color = if (isBdixAvailable) Color.Green else Color.Red
                        )
                        Text("BDIX Status: $bdixStatusMessage",
                            color = Color.Gray
                        )
                        Text("Cache Age: ${cacheAgeMinutes} minutes",
                            color = if (cacheAgeMinutes > 2) Color.Yellow else Color.Green
                        )
                        if (githubTokenAvailable) {
                            Text("GitHub Sync: Enabled", color = Color.Green)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showPythonDebugDialog = false }) {
                        Text("Close")
                    }
                }
            )
        }

        // Main Layout
        Row(Modifier.fillMaxSize().background(Color(0xFF0A0A0A))) {
            // Sidebar
            Column(
                Modifier
                    .fillMaxHeight()
                    .width(260.dp)
                    .background(Color(0xFF111111))
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Text("BDIX TV", color = Color.Red, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(24.dp))

                // Navigation Items
                NavItem("Home", Icons.Filled.Home, selected = currentNav == NavTarget.HOME) {
                    currentNav = NavTarget.HOME
                }
                NavItem("All Content", Icons.Filled.Explore, selected = currentNav == NavTarget.ALL_CONTENT) {
                    currentNav = NavTarget.ALL_CONTENT
                }
                NavItem("Quick Play", Icons.Filled.PlayArrow, selected = false) {
                    playLastWatched(context, allChannels)
                }

                Spacer(Modifier.height(16.dp))

                // Movies Section - UPDATED
                var expandedMovies by remember { mutableStateOf(false) }
                NavItem(
                    "Movies",
                    Icons.Filled.Movie,
                    selected = currentNav == NavTarget.MOVIES ||
                            currentNav == NavTarget.MOVIES_HINDI ||
                            currentNav == NavTarget.MOVIES_SOUTH ||
                            currentNav == NavTarget.MOVIES_HOLLYWOOD ||
                            currentNav == NavTarget.MOVIE_DETAIL
                ) {
                    if (expandedMovies) {
                        // If already expanded, go to main movies page
                        currentNav = NavTarget.MOVIES
                    }
                    expandedMovies = !expandedMovies
                }

                if (expandedMovies) {
                    SubNavItem("All Movies", selected = currentNav == NavTarget.MOVIES) {
                        currentNav = NavTarget.MOVIES
                    }
                    SubNavItem("Hindi Movies", selected = currentNav == NavTarget.MOVIES_HINDI) {
                        movieViewModel.selectCategory(MovieCategory.HINDI)
                        currentNav = NavTarget.MOVIES
                    }
                    SubNavItem("South Hindi Dubbed", selected = currentNav == NavTarget.MOVIES_SOUTH) {
                        movieViewModel.selectCategory(MovieCategory.SOUTH_DUBBED)
                        currentNav = NavTarget.MOVIES
                    }
                    SubNavItem("Hollywood", selected = currentNav == NavTarget.MOVIES_HOLLYWOOD) {
                        movieViewModel.selectCategory(MovieCategory.HOLLYWOOD)
                        currentNav = NavTarget.MOVIES
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                NavItem("Python Test", Icons.Filled.Code, selected = currentNav == NavTarget.PYTHON_TEST) {
                    showPythonDebugDialog = true
                }
                NavItem("Search", Icons.Filled.Search, selected = currentNav == NavTarget.SEARCH) {
                    currentNav = NavTarget.SEARCH
                }
                NavItem("Settings", Icons.Filled.Settings, selected = currentNav == NavTarget.SETTINGS) {
                    currentNav = NavTarget.SETTINGS
                }
            }

            // Main Content
            Box(Modifier.fillMaxSize().weight(1f)) {
                when (currentNav) {
                    NavTarget.HOME -> HomeContent(
                        bdixChannels = bdixChannels,
                        aynaChannels = aynaChannels,
                        isSyncing = isSyncing,
                        showDebugInfo = showDebugInfo,
                        pythonStatus = pythonStatus,
                        isBdixAvailable = isBdixAvailable,
                        isCheckingBdix = isCheckingBdix,
                        bdixStatusMessage = bdixStatusMessage,
                        cacheAgeMinutes = cacheAgeMinutes,
                        githubTokenAvailable = githubTokenAvailable,
                        isBackgroundSyncing = isBackgroundSyncing,
                        lastSyncStatus = lastSyncStatus,
                        lastSyncTime = lastSyncTime,
                        onToggleDebugInfo = { showDebugInfo = !showDebugInfo },
                        onRefreshChannels = { refreshTrigger++ },
                        onManualRefresh = {
                            CoroutineScope(Dispatchers.IO).launch {
                                manualRefresh(context, allChannels, bdixChannels, aynaChannels)
                            }
                        },
                        onRetryBdixCheck = {
                            CoroutineScope(Dispatchers.IO).launch {
                                ServerPingHelper.forceImmediateCheck(context)
                            }
                        },
                        onManualSync = {
                            CoroutineScope(Dispatchers.IO).launch {
                                manualGitHubSync(context)
                            }
                        },
                        onMoviesClick = {
                            currentNav = NavTarget.MOVIES
                        },
                        // ADD THESE TWO NEW CALLBACKS:
                        onMovieClick = { movie ->
                            selectedMovie = movie
                            currentNav = NavTarget.MOVIE_DETAIL
                        },
                        onMoviePlayClick = { movie ->
                            launchMoviePlayer(movie)
                        }
                    )

                    NavTarget.ALL_CONTENT -> FullGridContent("All Content", allChannels)

                    // Movies screens
                    NavTarget.MOVIES -> {
                        MoviesScreen(
                            viewModel = movieViewModel,
                            onMovieClick = { movie ->
                                launchMoviePlayer(movie)
                            },
                            onMovieDetailClick = { movie ->
                                selectedMovie = movie
                                currentNav = NavTarget.MOVIE_DETAIL
                            }
                        )
                    }

                    NavTarget.MOVIE_DETAIL -> {
                        selectedMovie?.let { movie ->
                            MovieDetailScreen(
                                movie = movie,
                                isFavorite = movieViewModel.isFavorite(movie.id),
                                relatedMovies = movieViewModel.getRelatedMovies(movie),
                                onPlayClick = { streamUrl ->
                                    launchMoviePlayer(movie, streamUrl)
                                },
                                onBackClick = {
                                    currentNav = NavTarget.MOVIES
                                    selectedMovie = null
                                },
                                onFavoriteClick = {
                                    movieViewModel.toggleFavorite(movie)
                                },
                                onRelatedMovieClick = { related ->
                                    selectedMovie = related
                                }
                            )
                        } ?: run {
                            currentNav = NavTarget.MOVIES
                        }
                    }

                    NavTarget.MOVIES_HINDI, NavTarget.MOVIES_SOUTH, NavTarget.MOVIES_HOLLYWOOD -> {
                        MoviesScreen(
                            viewModel = movieViewModel,
                            onMovieClick = { movie ->
                                launchMoviePlayer(movie)
                            },
                            onMovieDetailClick = { movie ->
                                selectedMovie = movie
                                currentNav = NavTarget.MOVIE_DETAIL
                            }
                        )
                    }

                    NavTarget.SERIES_KOREAN -> FullGridContent("Korean Series", emptyList())

                    NavTarget.SEARCH -> SearchScreen(
                        movieViewModel = movieViewModel,
                        onMovieClick = { movie ->
                            launchMoviePlayer(movie)
                        },
                        onChannelClick = { index, channels ->
                            launchPlayer(index, channels)
                        },
                        allChannels = allChannels
                    )

                    NavTarget.SETTINGS -> SettingsContent(
                        onRefresh = { refreshTrigger++ },
                        githubTokenAvailable = githubTokenAvailable,
                        isBackgroundSyncing = isBackgroundSyncing,
                        lastSyncStatus = lastSyncStatus,
                        lastSyncTime = lastSyncTime,
                        movieViewModel = movieViewModel
                    )

                    NavTarget.PYTHON_TEST -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Python Test", color = Color.White, fontSize = 24.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(pythonStatus, color = Color.Gray)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    CoroutineScope(Dispatchers.IO).launch {
                                        val result = PythonHelper.testPython(context)
                                        pythonStatus = if (result) "✅ Python working!" else "❌ Python failed"
                                    }
                                }
                            ) {
                                Text("Test Python")
                            }
                        }
                    }
                }
            }
        }
    }

    // ============ MOVIES SCREEN ============

    @Composable
    fun MoviesScreen(
        viewModel: MovieViewModel,
        onMovieClick: (Movie) -> Unit,
        onMovieDetailClick: (Movie) -> Unit
    ) {
        val uiState by viewModel.uiState.collectAsState()
        val allMovies by viewModel.allMovies.collectAsState()
        val displayedMovies by viewModel.displayedMovies.collectAsState()
        val recentlyAdded by viewModel.recentlyAdded.collectAsState()
        val continueWatching by viewModel.continueWatching.collectAsState()
        val favorites by viewModel.favorites.collectAsState()
        val selectedCategory by viewModel.selectedCategory.collectAsState()
        val isRefreshing by viewModel.isRefreshing.collectAsState()

        val favoriteIds = remember(favorites) { favorites.map { it.id }.toSet() }

        val movieCounts = remember(allMovies) {
            val counts = mutableMapOf<MovieCategory, Int>()
            counts[MovieCategory.ALL] = allMovies.size
            MovieCategory.values().filter { it != MovieCategory.ALL }.forEach { category ->
                counts[category] = allMovies.count { it.category == category }
            }
            counts
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0A0A))
        ) {
            when (uiState) {
                is MovieUiState.Loading -> {
                    Box(Modifier.fillMaxSize(), Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color.Red)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Loading movies...", color = Color.Gray)
                        }
                    }
                }

                is MovieUiState.Error -> {
                    Box(Modifier.fillMaxSize(), Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.Error, null, tint = Color.Red, modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Error loading movies", color = Color.White, fontSize = 18.sp)
                            Text((uiState as MovieUiState.Error).message, color = Color.Gray, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.loadMoviesWithGitHubSync(forceRefresh = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                            ) {
                                Text("Retry")
                            }
                        }
                    }
                }

                is MovieUiState.Empty -> {
                    Box(Modifier.fillMaxSize(), Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.Movie, null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No movies found", color = Color.Gray, fontSize = 16.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.loadMoviesWithGitHubSync(forceRefresh = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                            ) {
                                Text("Refresh")
                            }
                        }
                    }
                }

                is MovieUiState.Success -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        // Hero Banner
                        item {
                            MovieHeroBanner(
                                movie = recentlyAdded.firstOrNull(),
                                onPlayClick = { recentlyAdded.firstOrNull()?.let(onMovieClick) },
                                onInfoClick = { recentlyAdded.firstOrNull()?.let(onMovieDetailClick) }
                            )
                        }

                        // Category Chips
                        item {
                            MovieCategoryChips(
                                selectedCategory = selectedCategory,
                                onCategorySelect = { viewModel.selectCategory(it) },
                                movieCounts = movieCounts
                            )
                        }

                        // Status bar
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${displayedMovies.size} movies",
                                    color = Color.Gray,
                                    fontSize = 12.sp
                                )

                                Row {
                                    if (isRefreshing) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            strokeWidth = 2.dp,
                                            color = Color.Red
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                    }

                                    IconButton(
                                        onClick = { viewModel.loadMoviesWithGitHubSync(forceRefresh = true) },
                                        enabled = !isRefreshing
                                    ) {
                                        Icon(
                                            Icons.Filled.Refresh,
                                            contentDescription = "Refresh",
                                            tint = if (isRefreshing) Color.Gray else Color.White
                                        )
                                    }
                                }
                            }
                        }

                        // Continue Watching
                        if (continueWatching.isNotEmpty()) {
                            item {
                                MovieRow(
                                    title = "▶️ Continue Watching",
                                    movies = continueWatching,
                                    onMovieClick = onMovieClick,
                                    onMovieLongClick = onMovieDetailClick,
                                    showProgress = true,
                                    favoriteIds = favoriteIds,
                                    accentColor = Color.Yellow
                                )
                            }
                        }

                        // Favorites
                        if (favorites.isNotEmpty()) {
                            item {
                                MovieRow(
                                    title = "❤️ My Favorites",
                                    movies = favorites,
                                    onMovieClick = onMovieClick,
                                    onMovieLongClick = onMovieDetailClick,
                                    favoriteIds = favoriteIds,
                                    accentColor = Color.Red
                                )
                            }
                        }

                        // Recently Added
                        if (selectedCategory == MovieCategory.ALL && recentlyAdded.isNotEmpty()) {
                            item {
                                MovieRow(
                                    title = "🆕 Recently Added",
                                    movies = recentlyAdded,
                                    onMovieClick = onMovieClick,
                                    onMovieLongClick = onMovieDetailClick,
                                    favoriteIds = favoriteIds,
                                    accentColor = Color.Green
                                )
                            }
                        }

                        // Category-specific rows
                        if (selectedCategory == MovieCategory.ALL) {
                            MovieCategory.values()
                                .filter { it != MovieCategory.ALL }
                                .forEach { category ->
                                    val categoryMovies = allMovies.filter { it.category == category }
                                    if (categoryMovies.isNotEmpty()) {
                                        item {
                                            MovieRow(
                                                title = category.displayName,
                                                movies = categoryMovies.take(20),
                                                onMovieClick = onMovieClick,
                                                onMovieLongClick = onMovieDetailClick,
                                                onSeeAllClick = { viewModel.selectCategory(category) },
                                                favoriteIds = favoriteIds
                                            )
                                        }
                                    }
                                }
                        } else {
                            // Filtered movies grid
                            item {
                                Text(
                                    text = selectedCategory.displayName,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                                )
                            }

                            item {
                                LazyVerticalGrid(
                                    columns = GridCells.Adaptive(minSize = 140.dp),
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.height(600.dp)
                                ) {
                                    items(displayedMovies, key = { it.id }) { movie ->
                                        MovieCard(
                                            movie = movie,
                                            onClick = { onMovieClick(movie) },
                                            onLongClick = { onMovieDetailClick(movie) },
                                            isFavorite = movie.id in favoriteIds
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ============ MOVIE DETAIL SCREEN ============

    @Composable
    fun MovieDetailScreen(
        movie: Movie,
        isFavorite: Boolean,
        relatedMovies: List<Movie>,
        onPlayClick: (StreamUrl) -> Unit,
        onBackClick: () -> Unit,
        onFavoriteClick: () -> Unit,
        onRelatedMovieClick: (Movie) -> Unit
    ) {
        var selectedServer by remember { mutableStateOf(movie.streamUrls.firstOrNull()) }
        var showServerDialog by remember { mutableStateOf(false) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0A0A))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // Hero Section
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    if (movie.poster.isNotEmpty()) {
                        AsyncImage(
                            model = movie.poster,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color(0xFF0A0A0A).copy(alpha = 0.9f),
                                        Color(0xFF0A0A0A)
                                    )
                                )
                            )
                    )

                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .padding(16.dp)
                            .align(Alignment.TopStart)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                    }
                }

                // Content
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .offset(y = (-60).dp)
                ) {
                    Text(
                        text = movie.title,
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Meta info
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (movie.year.isNotEmpty()) {
                            InfoChip(text = movie.year)
                        }
                        InfoChip(text = movie.quality, color = Color.Green)
                        InfoChip(text = movie.language, color = Color.Cyan)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Genres
                    if (movie.genres.isNotEmpty()) {
                        Text(
                            text = movie.genres.joinToString(" • "),
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { selectedServer?.let { onPlayClick(it) } },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                            enabled = selectedServer != null
                        ) {
                            Icon(Icons.Filled.PlayArrow, null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Play")
                        }

                        if (movie.streamUrls.size > 1) {
                            OutlinedButton(
                                onClick = { showServerDialog = true },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, Color.White)
                            ) {
                                Icon(Icons.Filled.Dns, null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(selectedServer?.server ?: "Server", color = Color.White)
                            }
                        }

                        OutlinedButton(
                            onClick = onFavoriteClick,
                            border = BorderStroke(1.dp, if (isFavorite) Color.Red else Color.White)
                        ) {
                            Icon(
                                if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                null,
                                tint = if (isFavorite) Color.Red else Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Server info
                    Text("Available Servers (${movie.streamUrls.size})",
                        color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    movie.streamUrls.forEach { stream ->
                        ServerItem(
                            streamUrl = stream,
                            isSelected = stream == selectedServer,
                            onClick = { selectedServer = stream }
                        )
                    }

                    // Additional info
                    if (movie.audioInfo.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Audio", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(movie.audioInfo, color = Color.Gray, fontSize = 14.sp)
                    }

                    if (movie.codec.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Codec: ${movie.codec}", color = Color.Gray, fontSize = 12.sp)
                    }

                    // Related movies
                    if (relatedMovies.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(24.dp))
                        Text("Related Movies", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(relatedMovies, key = { it.id }) { related ->
                                MovieCard(
                                    movie = related,
                                    onClick = { onRelatedMovieClick(related) },
                                    modifier = Modifier.width(120.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(48.dp))
                }
            }
        }

        // Server dialog
        if (showServerDialog) {
            AlertDialog(
                onDismissRequest = { showServerDialog = false },
                title = { Text("Select Server") },
                text = {
                    Column {
                        movie.streamUrls.forEach { stream ->
                            Card(
                                onClick = {
                                    selectedServer = stream
                                    showServerDialog = false
                                },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (stream == selectedServer)
                                        Color.Red.copy(alpha = 0.3f) else Color(0xFF2A2A2A)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.Dns, null,
                                        tint = if (stream.isWorking) Color.Green else Color.Red
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(stream.server, color = Color.White, fontWeight = FontWeight.Medium)
                                        Text(stream.quality, color = Color.Gray, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showServerDialog = false }) { Text("Close") }
                }
            )
        }
    }

    // ============ MOVIE COMPONENTS ============

    @Composable
    fun MovieHeroBanner(
        movie: Movie?,
        onPlayClick: () -> Unit,
        onInfoClick: () -> Unit
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
        ) {
            if (movie?.poster?.isNotEmpty() == true) {
                AsyncImage(
                    model = movie.poster,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color(0xFF1A1A2E), Color(0xFF16213E))
                            )
                        )
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFF0A0A0A).copy(alpha = 0.8f),
                                Color(0xFF0A0A0A)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(24.dp)
            ) {
                if (movie != null) {
                    Text(
                        text = movie.title,
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (movie.year.isNotEmpty()) {
                            InfoChip(text = movie.year)
                        }
                        InfoChip(text = movie.quality, color = Color.Green)
                        InfoChip(text = movie.language, color = Color.Cyan)
                        if (movie.streamUrls.isNotEmpty()) {
                            InfoChip(text = "${movie.streamUrls.size} servers")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = onPlayClick,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                        ) {
                            Icon(Icons.Filled.PlayArrow, null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Play Now")
                        }

                        OutlinedButton(
                            onClick = onInfoClick,
                            border = BorderStroke(1.dp, Color.White)
                        ) {
                            Icon(Icons.Filled.Info, null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("More Info", color = Color.White)
                        }
                    }
                } else {
                    Text(
                        text = "BDIX Movies",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Watch HD Movies from BDIX Servers",
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun MovieCategoryChips(
        selectedCategory: MovieCategory,
        onCategorySelect: (MovieCategory) -> Unit,
        movieCounts: Map<MovieCategory, Int>
    ) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(MovieCategory.values().toList()) { category ->
                val isSelected = category == selectedCategory
                val count = movieCounts[category] ?: 0

                FilterChip(
                    selected = isSelected,
                    onClick = { onCategorySelect(category) },
                    label = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(category.displayName)
                            if (count > 0) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "($count)",
                                    fontSize = 10.sp,
                                    color = if (isSelected) Color.White.copy(alpha = 0.7f) else Color.Gray
                                )
                            }
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color.Red,
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF2A2A2A),
                        labelColor = Color.Gray
                    )
                )
            }
        }
    }

    @Composable
    fun MovieRow(
        title: String,
        movies: List<Movie>,
        onMovieClick: (Movie) -> Unit,
        onMovieLongClick: ((Movie) -> Unit)? = null,
        onSeeAllClick: (() -> Unit)? = null,
        showProgress: Boolean = false,
        favoriteIds: Set<String> = emptySet(),
        accentColor: Color = Color.White
    ) {
        if (movies.isEmpty()) return

        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = accentColor,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${movies.size} movies",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )

                    if (onSeeAllClick != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(onClick = onSeeAllClick) {
                            Text("See All", color = accentColor, fontSize = 12.sp)
                            Icon(
                                Icons.Filled.ChevronRight,
                                null,
                                tint = accentColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(movies, key = { it.id }) { movie ->
                    MovieCard(
                        movie = movie,
                        onClick = { onMovieClick(movie) },
                        onLongClick = { onMovieLongClick?.invoke(movie) },
                        showProgress = showProgress,
                        isFavorite = movie.id in favoriteIds
                    )
                }
            }
        }
    }

    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    fun MovieCard(
        movie: Movie,
        onClick: () -> Unit,
        onLongClick: (() -> Unit)? = null,
        showProgress: Boolean = false,
        isFavorite: Boolean = false,
        modifier: Modifier = Modifier
    ) {
        var isFocused by remember { mutableStateOf(false) }

        // Animated scale - bigger when focused
        val scale by animateFloatAsState(
            targetValue = if (isFocused) 1.1f else 1f,
            animationSpec = tween(durationMillis = 150),
            label = "scale"
        )

        // Animated border color - red when focused
        val borderColor by animateColorAsState(
            targetValue = if (isFocused) Color.Red else Color(0xFF333333),
            animationSpec = tween(durationMillis = 150),
            label = "borderColor"
        )

        // Border width - thicker when focused
        val borderWidth = if (isFocused) 4.dp else 1.dp

        Column(
            modifier = modifier
                .width(140.dp)
                .scale(scale)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick
                )
                .onFocusChanged { focusState ->
                    isFocused = focusState.isFocused
                }
                .focusable()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E1E1E))
                    .border(
                        width = borderWidth,
                        color = borderColor,
                        shape = RoundedCornerShape(12.dp)
                    )
            ) {
                // Poster image
                if (movie.poster.isNotEmpty()) {
                    AsyncImage(
                        model = movie.poster,
                        contentDescription = movie.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    // Placeholder when no poster
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Filled.Movie,
                                null,
                                tint = Color.Gray,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = movie.title.take(15),
                                color = Color.Gray,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                maxLines = 2
                            )
                        }
                    }
                }

                // Quality badge (top right)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .background(
                            Color(movie.getQualityBadgeColor()),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = movie.quality,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Favorite heart icon (top left)
                if (isFavorite) {
                    Icon(
                        Icons.Filled.Favorite,
                        "Favorite",
                        tint = Color.Red,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .size(16.dp)
                    )
                }

                // Year badge (bottom left)
                if (movie.year.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(6.dp)
                            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(movie.year, color = Color.White, fontSize = 10.sp)
                    }
                }

                // ========== FOCUS OVERLAY - VERY VISIBLE ==========
                if (isFocused) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.2f),
                                        Color.Red.copy(alpha = 0.7f)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Big play button
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Filled.PlayArrow,
                                    "Play",
                                    tint = Color.Red,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Press OK",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Watch progress bar (if applicable)
                if (showProgress && movie.watchProgress > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(Color.Gray.copy(alpha = 0.5f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(movie.watchProgress)
                                .background(Color.Red)
                        )
                    }
                }
            }

            // Movie title - brighter when focused
            Text(
                text = movie.title,
                color = if (isFocused) Color.White else Color.Gray,
                fontSize = if (isFocused) 13.sp else 12.sp,
                fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 8.dp)
            )

            // Language and server info
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(top = 2.dp)
            ) {
                Text(
                    movie.language,
                    color = if (isFocused) Color.Cyan else Color.Cyan.copy(alpha = 0.7f),
                    fontSize = 10.sp
                )
                if (movie.serverName.isNotEmpty()) {
                    Text("•", color = Color.Gray, fontSize = 10.sp)
                    Text(movie.serverName, color = Color.Gray, fontSize = 10.sp)
                }
            }
        }
    }

    // ============ HOME MOVIE CARD (Simpler version for home screen) ============

    @Composable
    fun HomeMovieCard(
        movie: Movie,
        onClick: () -> Unit,
        onPlayClick: () -> Unit
    ) {
        var isFocused by remember { mutableStateOf(false) }

        val scale by animateFloatAsState(
            targetValue = if (isFocused) 1.12f else 1f,
            animationSpec = tween(durationMillis = 150),
            label = "scale"
        )

        val borderColor by animateColorAsState(
            targetValue = if (isFocused) Color.Red else Color(0xFF333333),
            animationSpec = tween(durationMillis = 150),
            label = "border"
        )

        Column(
            modifier = Modifier
                .width(140.dp)
                .scale(scale)
                .clip(RoundedCornerShape(12.dp))
                .clickable { onClick() }
                .onFocusChanged { focusState ->
                    isFocused = focusState.isFocused
                }
                .focusable()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E1E1E))
                    .border(
                        width = if (isFocused) 4.dp else 1.dp,
                        color = borderColor,
                        shape = RoundedCornerShape(12.dp)
                    )
            ) {
                // Poster
                if (movie.poster.isNotEmpty()) {
                    AsyncImage(
                        model = movie.poster,
                        contentDescription = movie.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.Movie,
                            null,
                            tint = Color.Gray,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                // Quality badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .background(
                            Color(movie.getQualityBadgeColor()),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = movie.quality,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // ========== FOCUS OVERLAY ==========
                if (isFocused) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.3f),
                                        Color.Red.copy(alpha = 0.7f)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .background(Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Filled.PlayArrow,
                                    "Play",
                                    tint = Color.Red,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "View Details",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Title
            Text(
                text = movie.title,
                color = if (isFocused) Color.White else Color.Gray,
                fontSize = if (isFocused) 12.sp else 11.sp,
                fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }

    @Composable
    fun ServerItem(
        streamUrl: StreamUrl,
        isSelected: Boolean,
        onClick: () -> Unit
    ) {
        Card(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isSelected) Color.Red.copy(alpha = 0.2f) else Color(0xFF1A1A1A)
            ),
            border = if (isSelected) BorderStroke(1.dp, Color.Red) else null
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    null,
                    tint = if (isSelected) Color.Red else Color.Gray
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(streamUrl.server, color = Color.White, fontWeight = FontWeight.Medium)
                    Text(streamUrl.quality, color = Color.Gray, fontSize = 12.sp)
                    if (streamUrl.fileName.isNotEmpty()) {
                        Text(
                            streamUrl.fileName.take(50) + if (streamUrl.fileName.length > 50) "..." else "",
                            color = Color.Gray,
                            fontSize = 10.sp
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (streamUrl.isWorking) Color.Green else Color.Red, CircleShape)
                )
            }
        }
    }

    @Composable
    fun InfoChip(text: String, color: Color = Color.Gray) {
        Box(
            modifier = Modifier
                .background(color.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(text = text, color = color, fontSize = 12.sp)
        }
    }

    // ============ SEARCH SCREEN ============

    @Composable
    fun SearchScreen(
        movieViewModel: MovieViewModel,
        onMovieClick: (Movie) -> Unit,
        onChannelClick: (Int, List<Channel>) -> Unit,
        allChannels: List<Channel>
    ) {
        var searchQuery by remember { mutableStateOf("") }
        val searchResults by movieViewModel.searchResults.collectAsState()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                "Search",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    movieViewModel.search(it)
                },
                label = { Text("Search movies and channels...") },
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = Color.Gray) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = {
                            searchQuery = ""
                            movieViewModel.clearSearch()
                        }) {
                            Icon(Icons.Filled.Clear, null, tint = Color.Gray)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Red,
                    unfocusedBorderColor = Color.Gray,
                    focusedLabelColor = Color.Red
                ),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (searchQuery.isNotEmpty()) {
                // Search results
                LazyColumn {
                    // Movie results
                    if (searchResults.isNotEmpty()) {
                        item {
                            Text(
                                "Movies (${searchResults.size})",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }

                        items(searchResults.take(10), key = { it.id }) { movie ->
                            MovieSearchResultItem(
                                movie = movie,
                                onClick = { onMovieClick(movie) }
                            )
                        }
                    }

                    // Channel results
                    val channelResults = allChannels.filter {
                        it.name.contains(searchQuery, ignoreCase = true)
                    }
                    if (channelResults.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "Channels (${channelResults.size})",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }

                        itemsIndexed(channelResults.take(10)) { index, channel ->
                            ChannelSearchResultItem(
                                channel = channel,
                                onClick = { onChannelClick(index, channelResults) }
                            )
                        }
                    }

                    // No results
                    if (searchResults.isEmpty() && channelResults.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No results found", color = Color.Gray)
                            }
                        }
                    }
                }
            } else {
                // Show suggestions or recent searches
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Filled.Search,
                            null,
                            tint = Color.Gray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Search for movies and channels", color = Color.Gray)
                    }
                }
            }
        }
    }

    @Composable
    fun MovieSearchResultItem(movie: Movie, onClick: () -> Unit) {
        Card(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp, 90.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF2A2A2A))
                ) {
                    if (movie.poster.isNotEmpty()) {
                        AsyncImage(
                            model = movie.poster,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            Icons.Filled.Movie,
                            null,
                            tint = Color.Gray,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(movie.title, color = Color.White, fontWeight = FontWeight.Medium)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(movie.year, color = Color.Gray, fontSize = 12.sp)
                        Text(movie.quality, color = Color.Green, fontSize = 12.sp)
                        Text(movie.language, color = Color.Cyan, fontSize = 12.sp)
                    }
                    Text(
                        movie.category.displayName,
                        color = Color.Gray,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Icon(Icons.Filled.PlayCircle, null, tint = Color.Red)
            }
        }
    }

    @Composable
    fun ChannelSearchResultItem(channel: Channel, onClick: () -> Unit) {
        Card(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF2A2A2A)),
                    contentAlignment = Alignment.Center
                ) {
                    if (channel.logo.isNotEmpty()) {
                        AsyncImage(
                            model = channel.logo,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize().padding(4.dp),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Text(channel.name.take(2), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(channel.name, color = Color.White, fontWeight = FontWeight.Medium)
                    Text(
                        "${channel.urls.size} servers • ${channel.source}",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }

                Icon(Icons.Filled.LiveTv, null, tint = Color.Magenta)
            }
        }
    }

    // ============ SETTINGS CONTENT ============

    @Composable
    fun SettingsContent(
        onRefresh: () -> Unit,
        githubTokenAvailable: Boolean,
        isBackgroundSyncing: Boolean,
        lastSyncStatus: String?,
        lastSyncTime: Long,
        movieViewModel: MovieViewModel? = null
    ) {
        val context = LocalContext.current as MainActivity
        val firebaseManager = remember { FirebaseManager(context) }
        var username by remember { mutableStateOf(firebaseManager.getAynaUsername() ?: "") }
        var password by remember { mutableStateOf("") }
        var deviceId by remember { mutableStateOf(firebaseManager.getDeviceId()) }
        var showPassword by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf<String?>(null) }
        var isSaving by remember { mutableStateOf(false) }
        var cacheStatus by remember { mutableStateOf<ChannelCacheManager.CacheStatus?>(null) }
        var serverStatus by remember { mutableStateOf("Checking...") }
        var isCheckingServers by remember { mutableStateOf(false) }
        var movieCacheInfo by remember { mutableStateOf<String?>(null) }

        LaunchedEffect(Unit) {
            cacheStatus = ChannelCacheManager.getCacheStatus(context)

            isCheckingServers = true
            CoroutineScope(Dispatchers.IO).launch {
                val isReachable = ServerPingHelper.quickCheck(context)
                serverStatus = if (isReachable) "✅ All servers reachable" else "❌ Some servers offline"
                isCheckingServers = false
            }

            // Get movie cache info
            movieViewModel?.let {
                val info = it.getCacheInfo()
                movieCacheInfo = if (info.exists) {
                    "Movies: ${info.sizeKb}KB, ${info.ageMinutes}m old"
                } else {
                    "Movies: No cache"
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            item {
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
            }

            // Python Scripts Auto-Update Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Python Scripts Auto-Update",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        var scriptsStatus by remember { mutableStateOf("Loading...") }
                        var isUpdating by remember { mutableStateOf(false) }

                        LaunchedEffect(Unit) {
                            scriptsStatus = PythonScriptsDownloader.getStatusInfo(context)
                        }

                        Text("GitHub: mpshimul/BDIX-TV/scripts/python", color = Color.Cyan, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(scriptsStatus, color = Color.Gray, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    isUpdating = true
                                    CoroutineScope(Dispatchers.IO).launch {
                                        val updated = PythonScriptsDownloader.forceUpdate(context)
                                        scriptsStatus = if (updated) "✅ Updated from GitHub!" else "❌ Update failed"
                                        isUpdating = false
                                        PythonHelper.resetPythonState()
                                    }
                                },
                                enabled = !isUpdating,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Green)
                            ) {
                                if (isUpdating) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Updating...")
                                } else {
                                    Icon(Icons.Filled.Update, null, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Update Now")
                                }
                            }

                            Button(
                                onClick = {
                                    PythonScriptsDownloader.clearScripts(context)
                                    PythonHelper.resetPythonState()
                                    scriptsStatus = "🧹 Scripts cleared. Will auto-download on next use."
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                            ) {
                                Icon(Icons.Filled.Delete, null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Clear All")
                            }
                        }
                    }
                }
            }

            // Movie Cache Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "Movie Cache",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Button(
                                onClick = {
                                    movieViewModel?.clearCacheAndReload()
                                    message = "✅ Movie cache cleared"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Clear", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(movieCacheInfo ?: "Loading...", color = Color.Gray, fontSize = 12.sp)

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { movieViewModel?.loadMoviesWithGitHubSync(forceRefresh = true) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
                        ) {
                            Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Refresh Movies")
                        }
                    }
                }
            }

            // Server Status Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Server Status", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                            if (isCheckingServers) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                            } else {
                                Button(
                                    onClick = {
                                        CoroutineScope(Dispatchers.IO).launch {
                                            isCheckingServers = true
                                            val isReachable = ServerPingHelper.quickCheck(context)
                                            serverStatus = if (isReachable) "✅ All servers reachable" else "❌ Some servers offline"
                                            isCheckingServers = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Re-check", fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = serverStatus,
                            color = when {
                                serverStatus.contains("✅") -> Color.Green
                                serverStatus.contains("❌") -> Color.Red
                                else -> Color.Yellow
                            },
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Channel Cache Status Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "Channel Cache",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Button(
                                onClick = {
                                    CoroutineScope(Dispatchers.IO).launch {
                                        ChannelCacheManager.clearAllCache(context)
                                        cacheStatus = ChannelCacheManager.getCacheStatus(context)
                                        message = "✅ All cache cleared"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Clear All", fontSize = 12.sp)
                            }
                        }

                        if (cacheStatus != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            cacheStatus?.combinedCache?.let { cache ->
                                val timeAgo = formatTimeAgo(cache.lastUpdated)
                                Text(
                                    "Combined: ${cache.channelCount} channels",
                                    color = if (cache.isExpired) Color.Yellow else Color.Green,
                                    fontSize = 14.sp
                                )
                                Text(
                                    "Updated: $timeAgo ${if (cache.isExpired) "(Expired)" else "(Fresh)"}",
                                    color = Color.Gray,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // AynaOTT Credentials Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "AynaOTT Credentials",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("Email/Username") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Red,
                                unfocusedBorderColor = Color.Gray
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Red,
                                unfocusedBorderColor = Color.Gray
                            ),
                            visualTransformation = if (showPassword) {
                                androidx.compose.ui.text.input.VisualTransformation.None
                            } else {
                                androidx.compose.ui.text.input.PasswordVisualTransformation()
                            },
                            trailingIcon = {
                                IconButton(onClick = { showPassword = !showPassword }) {
                                    Icon(
                                        if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                        null,
                                        tint = Color.Gray
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    if (username.isEmpty() || password.isEmpty()) {
                                        message = "Please enter both username and password"
                                        return@Button
                                    }
                                    isSaving = true
                                    firebaseManager.saveAynaCredentials(username, password)
                                    message = "✅ Credentials saved locally"
                                    isSaving = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isSaving) "Saving..." else "Save")
                            }

                            Button(
                                onClick = {
                                    onRefresh()
                                    message = "✅ Refreshing channels..."
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Refresh Channels")
                            }
                        }

                        if (!message.isNullOrEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = message!!,
                                color = if (message!!.contains("✅")) Color.Green else Color.Red,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            // App Information Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("App Information", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("BDIX TV App", color = Color.Gray, fontSize = 14.sp)
                        Text("Version 1.0", color = Color.Gray, fontSize = 14.sp)
                        Text("Python 3.8 with Chaquopy", color = Color.Gray, fontSize = 14.sp)
                        Text("Sources: AynaOTT, KSB, BasNet, RedForce", color = Color.Gray, fontSize = 14.sp)
                        Text("Movie Servers: DHAKA-FLIX-7, DHAKA-FLIX-14", color = Color.Gray, fontSize = 14.sp)
                        Text("Device ID: $deviceId", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }

    // ============ HOME CONTENT (UPDATED) ============

    @Composable
    fun HomeContent(
        bdixChannels: List<Channel>,
        aynaChannels: List<Channel>,
        isSyncing: Boolean,
        showDebugInfo: Boolean,
        pythonStatus: String,
        isBdixAvailable: Boolean,
        isCheckingBdix: Boolean,
        bdixStatusMessage: String,
        cacheAgeMinutes: Long,
        githubTokenAvailable: Boolean,
        isBackgroundSyncing: Boolean,
        lastSyncStatus: String?,
        lastSyncTime: Long,
        onToggleDebugInfo: () -> Unit,
        onRefreshChannels: () -> Unit,
        onManualRefresh: () -> Unit,
        onRetryBdixCheck: () -> Unit,
        onManualSync: () -> Unit,
        onMoviesClick: () -> Unit,
        onMovieClick: (Movie) -> Unit,           // <-- ADD THIS LINE
        onMoviePlayClick: (Movie) -> Unit        // <-- ADD THIS LINE
    ) {
        LazyColumn(Modifier.fillMaxSize()) {
            // Hero Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color(0xFF0A0A0A), Color(0xFF1A1A1A), Color(0xFF0A0A0A))
                            )
                        )
                        .padding(16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Column {
                        Text("BDIX TV", color = Color.Red, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text("Watch Live TV & Movies", color = Color.White, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                if (isBdixAvailable) "BDIX Online • ${bdixChannels.size} channels"
                                else "BDIX Offline • ${bdixChannels.size} channels",
                                modifier = Modifier
                                    .background(
                                        if (isBdixAvailable) Color.Cyan.copy(alpha = 0.2f)
                                        else Color.Gray.copy(alpha = 0.2f),
                                        RoundedCornerShape(16.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isBdixAvailable) Color.Cyan else Color.Gray,
                                        RoundedCornerShape(16.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                color = if (isBdixAvailable) Color.Cyan else Color.Gray,
                                fontSize = 12.sp
                            )

                            Text(
                                "AynaOTT • ${aynaChannels.size} channels",
                                modifier = Modifier
                                    .background(Color.Magenta.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                    .border(1.dp, Color.Magenta, RoundedCornerShape(16.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                color = Color.Magenta,
                                fontSize = 12.sp
                            )

                            if (githubTokenAvailable) {
                                Text(
                                    "GitHub Sync",
                                    modifier = Modifier
                                        .background(Color.Green.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                        .border(1.dp, Color.Green, RoundedCornerShape(16.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                                    color = Color.Green,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // Quick Actions Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Movies Button
                    Card(
                        onClick = onMoviesClick,
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Movie, null, tint = Color.Red, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Movies", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Watch HD Movies", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }

                    // Live TV Button
                    Card(
                        onClick = { /* Already on home */ },
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.LiveTv, null, tint = Color.Magenta, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Live TV", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("${bdixChannels.size + aynaChannels.size} channels", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Status card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .background(
                            when {
                                !isBdixAvailable && bdixChannels.isNotEmpty() -> Color.Yellow.copy(alpha = 0.1f)
                                isSyncing -> Color.Blue.copy(alpha = 0.1f)
                                else -> Color.Green.copy(alpha = 0.1f)
                            },
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            when {
                                !isBdixAvailable && bdixChannels.isNotEmpty() -> Color.Yellow
                                isSyncing -> Color.Blue
                                else -> Color.Green
                            },
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onToggleDebugInfo() }
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Channel Status", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    pythonStatus,
                                    color = when {
                                        !isBdixAvailable && bdixChannels.isNotEmpty() -> Color.Yellow
                                        isSyncing -> Color.Blue
                                        else -> Color.Green
                                    },
                                    fontSize = 12.sp
                                )
                            }

                            Row {
                                if (isCheckingBdix) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                }

                                IconButton(onClick = onManualRefresh, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Filled.Refresh, "Refresh", tint = Color.White)
                                }

                                if (githubTokenAvailable) {
                                    IconButton(
                                        onClick = onManualSync,
                                        modifier = Modifier.size(24.dp),
                                        enabled = !isBackgroundSyncing
                                    ) {
                                        Icon(
                                            Icons.Filled.CloudSync,
                                            "GitHub Sync",
                                            tint = if (isBackgroundSyncing) Color.Blue else Color.Green
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Syncing indicator
            if (isSyncing) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .background(Color.Green.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CircularProgressIndicator(color = Color.Green, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Loading channels...", color = Color.Green, fontSize = 12.sp)
                        }
                    }
                }
            }

            // BDIX Channels Section
            item {
                if (bdixChannels.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "BDIX Channels",
                            color = if (isBdixAvailable) Color.Cyan else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )

                        Text(
                            "${bdixChannels.size} channels",
                            color = if (isBdixAvailable) Color.Cyan else Color.Gray,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .background(
                                    if (isBdixAvailable) Color.Cyan.copy(alpha = 0.2f) else Color.Gray.copy(alpha = 0.2f),
                                    RoundedCornerShape(16.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    if (isBdixAvailable) {
                        ChannelRow(
                            channels = bdixChannels,
                            channelColor = Color.Cyan,
                            sourceName = "BDIX",
                            isEnabled = true
                        )
                    } else {
                        ChannelRow(
                            channels = bdixChannels.take(10),
                            channelColor = Color.Gray,
                            sourceName = "BDIX (Offline)",
                            isEnabled = false
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                                .background(Color(0xFF1A1A1A), RoundedCornerShape(12.dp))
                                .border(1.dp, Color.Yellow, RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.WifiOff, null, tint = Color.Yellow, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Connect to BDIX Network", color = Color.Yellow, fontWeight = FontWeight.Bold)
                                Text("${bdixChannels.size} BDIX channels available", color = Color.Gray, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = onRetryBdixCheck,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.Yellow,
                                        contentColor = Color.Black
                                    )
                                ) {
                                    Text("Check Now")
                                }
                            }
                        }
                    }
                }
            }

            // AynaOTT Channels Section
            if (aynaChannels.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("AynaOTT Channels", color = Color.Magenta, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "${aynaChannels.size} channels",
                            color = Color.Magenta,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .background(Color.Magenta.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    ChannelRow(
                        channels = aynaChannels,
                        channelColor = Color.Magenta,
                        sourceName = "AynaOTT",
                        isEnabled = true
                    )
                }
            }

            // Movies Section (Preview) - UPDATED TO SHOW ACTUAL MOVIES
            // ============ MOVIES SECTION - FIXED ============
            item {
                val movieViewModel: MovieViewModel = viewModel()
                val recentMovies by movieViewModel.recentlyAdded.collectAsState()

                // Load movies when this section appears
                LaunchedEffect(Unit) {
                    movieViewModel.loadMoviesWithGitHubSync()
                }

                // Header row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "🎬 Movies",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    TextButton(onClick = onMoviesClick) {
                        Text("See All", color = Color.Red)
                        Icon(Icons.Filled.ChevronRight, null, tint = Color.Red)
                    }
                }

                // Movies row
                if (recentMovies.isEmpty()) {
                    // Loading placeholders
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(5) {
                            Box(
                                modifier = Modifier
                                    .width(140.dp)
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1E1E1E))
                                    .border(1.dp, Color(0xFF333333), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = Color.Red,
                                    strokeWidth = 2.dp
                                )
                            }
                        }
                    }
                } else {
                    // Actual movies with click handlers
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(recentMovies.take(10), key = { it.id }) { movie ->
                            HomeMovieCard(
                                movie = movie,
                                onClick = { onMovieClick(movie) },        // Goes to detail page
                                onPlayClick = { onMoviePlayClick(movie) } // Direct play
                            )
                        }
                    }
                }
            }
        }
    }

    // ============ CHANNEL COMPONENTS ============

    @Composable
    fun ChannelRow(
        channels: List<Channel>,
        channelColor: Color,
        sourceName: String,
        isEnabled: Boolean
    ) {
        if (channels.isEmpty()) return

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.height(160.dp) // Increased height for scaling
        ) {
            itemsIndexed(channels) { index, channel ->
                var isFocused by remember { mutableStateOf(false) }

                val scale by animateFloatAsState(
                    targetValue = if (isFocused) 1.15f else 1.0f,
                    animationSpec = tween(durationMillis = 150),
                    label = "scale"
                )

                val borderColor by animateColorAsState(
                    targetValue = when {
                        isFocused -> Color.Red
                        isEnabled -> channelColor.copy(alpha = 0.3f)
                        else -> Color.Gray.copy(alpha = 0.2f)
                    },
                    animationSpec = tween(durationMillis = 150),
                    label = "border"
                )

                val backgroundColor by animateColorAsState(
                    targetValue = when {
                        isFocused -> Color(0xFF2A2A2A)
                        isEnabled -> Color(0xFF1A1A1A)
                        else -> Color(0xFF111111)
                    },
                    animationSpec = tween(durationMillis = 150),
                    label = "background"
                )

                Column(
                    Modifier
                        .width(110.dp)
                        .scale(scale)
                        .clickable(
                            enabled = isEnabled,
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            if (isEnabled) {
                                launchPlayer(index, channels)
                            }
                        }
                        .onFocusChanged { focusState ->
                            isFocused = focusState.isFocused
                        }
                        .focusable()
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(backgroundColor)
                            .border(
                                width = if (isFocused) 4.dp else 1.dp,
                                color = borderColor,
                                shape = RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        // Channel logo or text
                        if (channel.logo.isNotEmpty() && channel.logo.startsWith("http")) {
                            AsyncImage(
                                model = channel.logo,
                                contentDescription = channel.name,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp),
                                contentScale = ContentScale.Fit,
                                alpha = if (isEnabled) 1f else 0.5f
                            )
                        } else {
                            Text(
                                channel.name.take(3),
                                color = when {
                                    isFocused -> Color.White
                                    isEnabled -> channelColor
                                    else -> Color.Gray
                                },
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // ========== FOCUS OVERLAY ==========
                        if (isFocused && isEnabled) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color.Red.copy(alpha = 0.7f)
                                            )
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        Icons.Filled.PlayCircle,
                                        "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Text(
                                        "WATCH",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Channel name - highlighted when focused
                    Text(
                        channel.name,
                        color = when {
                            isFocused -> Color.White
                            isEnabled -> Color.Gray
                            else -> Color.DarkGray
                        },
                        fontSize = if (isFocused) 11.sp else 10.sp,
                        fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                    )
                }
            }
        }
    }

    @Composable
    fun NavItem(title: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
        var isFocused by remember { mutableStateOf(false) }

        val backgroundColor by animateColorAsState(
            targetValue = when {
                isFocused -> Color.Red.copy(alpha = 0.3f)
                selected -> Color(0xFF2A2A2A)
                else -> Color.Transparent
            },
            animationSpec = tween(durationMillis = 150),
            label = "bg"
        )

        val borderColor by animateColorAsState(
            targetValue = if (isFocused) Color.Red else Color.Transparent,
            animationSpec = tween(durationMillis = 150),
            label = "border"
        )

        Card(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .border(
                    width = if (isFocused) 2.dp else 0.dp,
                    color = borderColor,
                    shape = RoundedCornerShape(8.dp)
                )
                .onFocusChanged { isFocused = it.isFocused }
                .focusable(),
            colors = CardDefaults.cardColors(containerColor = backgroundColor)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    icon,
                    title,
                    tint = when {
                        isFocused -> Color.Red
                        selected -> Color.Red
                        else -> Color.Gray
                    }
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    title,
                    color = when {
                        isFocused -> Color.White
                        selected -> Color.White
                        else -> Color.Gray
                    },
                    fontWeight = if (isFocused || selected) FontWeight.Bold else FontWeight.Normal
                )

                // Arrow indicator when focused
                if (isFocused) {
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(
                        Icons.Filled.ChevronRight,
                        null,
                        tint = Color.Red,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }

    @Composable
    fun SubNavItem(title: String, selected: Boolean, onClick: () -> Unit) {
        var isFocused by remember { mutableStateOf(false) }

        val backgroundColor by animateColorAsState(
            targetValue = when {
                isFocused -> Color.Red.copy(alpha = 0.2f)
                selected -> Color(0xFF3A3A3A)
                else -> Color.Transparent
            },
            animationSpec = tween(durationMillis = 150),
            label = "bg"
        )

        Card(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, top = 2.dp, bottom = 2.dp)
                .border(
                    width = if (isFocused) 2.dp else 0.dp,
                    color = if (isFocused) Color.Red else Color.Transparent,
                    shape = RoundedCornerShape(8.dp)
                )
                .onFocusChanged { isFocused = it.isFocused }
                .focusable(),
            colors = CardDefaults.cardColors(containerColor = backgroundColor)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(if (isFocused) 8.dp else 4.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isFocused -> Color.Red
                                selected -> Color.Red
                                else -> Color.Gray
                            }
                        )
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    title,
                    color = when {
                        isFocused -> Color.White
                        selected -> Color.White
                        else -> Color.Gray
                    },
                    fontSize = 14.sp,
                    fontWeight = if (isFocused) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }

    @Composable
    fun FullGridContent(title: String, channels: List<Channel>) {
        Column {
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.padding(16.dp)
            )

            if (channels.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("No channels available", color = Color.Gray)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(channels) { index, channel ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E1E1E))
                                .clickable { launchPlayer(index, channels) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f)
                                    .background(Color(0xFF0A0A0A)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (channel.logo.isNotEmpty() && channel.logo.startsWith("http")) {
                                    AsyncImage(
                                        model = channel.logo,
                                        contentDescription = channel.name,
                                        modifier = Modifier.fillMaxSize().padding(8.dp),
                                        contentScale = ContentScale.Fit
                                    )
                                } else {
                                    Text(channel.name.take(2), color = Color.White, fontSize = 20.sp)
                                }
                            }
                            Text(
                                channel.name,
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 1,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                            Text(
                                "${channel.urls.size} servers • ${channel.source}",
                                color = Color.Gray,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // ============ PLAYER LAUNCHERS ============

    private fun launchPlayer(index: Int, list: List<Channel>) {
        getSharedPreferences("TV_DATA", MODE_PRIVATE).edit()
            .putInt("last_channel_index", index).apply()
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("CHANNEL_INDEX", index)
            putParcelableArrayListExtra("CHANNEL_LIST", ArrayList(list))
        })
    }

    @androidx.media3.common.util.UnstableApi
    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    private fun launchMoviePlayer(movie: Movie, streamUrl: StreamUrl? = null) {
        val url = streamUrl?.url ?: movie.getBestStreamUrl() ?: return

        startActivity(Intent(this, MoviePlayerActivity::class.java).apply {
            putExtra("MOVIE_ID", movie.id)
            putExtra("MOVIE_TITLE", movie.title)
            putExtra("MOVIE_URL", url)
            putExtra("MOVIE_QUALITY", streamUrl?.quality ?: movie.quality)
            putExtra("MOVIE_POSTER", movie.poster)
            putParcelableArrayListExtra("STREAM_URLS", ArrayList(movie.streamUrls))
        })
    }

    private fun playLastWatched(context: Context, channels: List<Channel>) {
        if (channels.isEmpty()) return
        val lastIndex = getSharedPreferences("TV_DATA", MODE_PRIVATE).getInt("last_channel_index", 0)
        val safeIndex = if (lastIndex < channels.size) lastIndex else 0
        launchPlayer(safeIndex, channels)
    }

    // ============ HELPER FUNCTIONS ============

    private fun formatTimeAgo(timestamp: Long): String {
        val diff = System.currentTimeMillis() - timestamp
        val minutes = diff / (60 * 1000)
        val hours = diff / (60 * 60 * 1000)
        val days = diff / (24 * 60 * 60 * 1000)

        return when {
            days > 0 -> "${days}d ago"
            hours > 0 -> "${hours}h ago"
            minutes > 0 -> "${minutes}m ago"
            else -> "Just now"
        }
    }

    private suspend fun manualRefresh(
        context: Context,
        allChannels: List<Channel>,
        bdixChannels: List<Channel>,
        aynaChannels: List<Channel>
    ) {
        val firebaseManager = FirebaseManager(context)
        var username = firebaseManager.getAynaUsername()
        var password = firebaseManager.getAynaPassword()

        if (username == null || password == null || password!!.isEmpty()) {
            username = "shimulfp@gmail.com"
            password = ""
        }

        ChannelCacheManager.manualRefresh(
            context = context,
            username = username,
            password = password
        )
    }

    private suspend fun manualGitHubSync(context: Context) {
        val firebaseManager = FirebaseManager(context)
        val token = firebaseManager.getGitHubToken()

        if (token.isNotEmpty()) {
            GitHubDataManager.initialize(token)
            val result = GitHubDataManager.checkAndSyncData(context)
            saveSyncLog(context, result)
        }
    }

    private fun saveSyncLog(context: Context, result: GitHubDataManager.SyncResult) {
        try {
            val logFile = File(context.filesDir, "github_sync_log.json")
            val log = JSONObject().apply {
                put("last_sync_time", System.currentTimeMillis())
                put("last_sync_date", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))

                val resultType = when (result) {
                    is GitHubDataManager.SyncResult.Downloaded -> "DOWNLOADED"
                    is GitHubDataManager.SyncResult.ScrapedAndUploaded -> "SCRAPED_UPLOADED"
                    is GitHubDataManager.SyncResult.ScrapedOnly -> "SCRAPED_ONLY"
                    is GitHubDataManager.SyncResult.ScrapingFailed -> "SCRAPING_FAILED"
                    is GitHubDataManager.SyncResult.Error -> "ERROR"
                    else -> "OTHER"
                }
                put("last_result", resultType)
            }
            logFile.writeText(log.toString())
        } catch (e: Exception) {
            Log.e("SYNC_LOG", "Error saving log: ${e.message}")
        }
    }
}