package com.shimulfp.bdixlivetv.utils

import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.ProgressBar
import androidx.annotation.IdRes

/**
 * ViewBindingHelper - Type-safe view finding helper
 *
 * This prevents ClassCastException crashes by:
 * 1. Checking actual view type before casting
 * 2. Providing helpful error messages
 * 3. Supporting logging for debugging
 *
 * USAGE:
 * ```kotlin
 * val rootView = findViewById<View>(android.R.id.content)
 * playPauseButton = rootView.findImageButton(R.id.movie_play_pause_button)
 * serverButton = rootView.findButton(R.id.movie_server_button)
 * ```
 */
object ViewBindingHelper {

    private const val TAG = "ViewBindingHelper"

    fun findButton(parent: View, @IdRes id: Int): Button {
        val view = parent.findViewById<View>(id)
            ?: throw IllegalStateException("View with ID $id not found")

        if (view is Button) return view

        throw IllegalStateException(
            "View with ID $id is ${view::class.simpleName}, " +
            "but was expected to be Button.\n" +
            "FIX: Change findViewById<Button>(R.id.$id) " +
            "to findViewById<${view::class.simpleName}>(R.id.$id) " +
            "in your Kotlin code, OR change XML <Button> to <${view::class.simpleName}>"
        )
    }

    fun findImageButton(parent: View, @IdRes id: Int): ImageButton {
        val view = parent.findViewById<View>(id)
            ?: throw IllegalStateException("View with ID $id not found")

        if (view is ImageButton) return view

        throw IllegalStateException(
            "View with ID $id is ${view::class.simpleName}, " +
            "but was expected to be ImageButton.\n" +
            "FIX: Change findViewById<ImageButton>(R.id.$id) " +
            "to findViewById<${view::class.simpleName}>(R.id.$id) " +
            "in your Kotlin code, OR change XML <${view::class.simpleName}> to <ImageButton>"
        )
    }

    fun findTextView(parent: View, @IdRes id: Int): TextView {
        val view = parent.findViewById<View>(id)
            ?: throw IllegalStateException("View with ID $id not found")

        if (view is TextView) return view

        throw IllegalStateException(
            "View with ID $id is ${view::class.simpleName}, " +
            "but was expected to be TextView"
        )
    }

    fun findImageView(parent: View, @IdRes id: Int): ImageView {
        val view = parent.findViewById<View>(id)
            ?: throw IllegalStateException("View with ID $id not found")

        if (view is ImageView) return view

        throw IllegalStateException(
            "View with ID $id is ${view::class.simpleName}, " +
            "but was expected to be ImageView"
        )
    }

    fun findRelativeLayout(parent: View, @IdRes id: Int): RelativeLayout {
        val view = parent.findViewById<View>(id)
            ?: throw IllegalStateException("View with ID $id not found")

        if (view is RelativeLayout) return view

        throw IllegalStateException(
            "View with ID $id is ${view::class.simpleName}, " +
            "but was expected to be RelativeLayout"
        )
    }

    fun findSeekBar(parent: View, @IdRes id: Int): SeekBar {
        val view = parent.findViewById<View>(id)
            ?: throw IllegalStateException("View with ID $id not found")

        if (view is SeekBar) return view

        throw IllegalStateException(
            "View with ID $id is ${view::class.simpleName}, " +
            "but was expected to be SeekBar"
        )
    }

    fun findProgressBar(parent: View, @IdRes id: Int): ProgressBar {
        val view = parent.findViewById<View>(id)
            ?: throw IllegalStateException("View with ID $id not found")

        if (view is ProgressBar) return view

        throw IllegalStateException(
            "View with ID $id is ${view::class.simpleName}, " +
            "but was expected to be ProgressBar"
        )
    }

    fun logViewTypes(parent: View, vararg ids: Int) {
        Log.d(TAG, "=== View Type Debug Info ===")
        ids.forEach { id ->
            val view = parent.findViewById<View>(id)
            if (view != null) {
                Log.d(TAG, "ID: $id -> Type: ${view::class.simpleName}")
            } else {
                Log.d(TAG, "ID: $id -> NOT FOUND")
            }
        }
    }
}

// Extension functions for convenient usage
fun View.findButton(@IdRes id: Int) = ViewBindingHelper.findButton(this, id)
fun View.findImageButton(@IdRes id: Int) = ViewBindingHelper.findImageButton(this, id)
fun View.findTextView(@IdRes id: Int) = ViewBindingHelper.findTextView(this, id)
fun View.findImageView(@IdRes id: Int) = ViewBindingHelper.findImageView(this, id)
fun View.findRelativeLayout(@IdRes id: Int) = ViewBindingHelper.findRelativeLayout(this, id)
fun View.findSeekBar(@IdRes id: Int) = ViewBindingHelper.findSeekBar(this, id)
fun View.findProgressBar(@IdRes id: Int) = ViewBindingHelper.findProgressBar(this, id)
