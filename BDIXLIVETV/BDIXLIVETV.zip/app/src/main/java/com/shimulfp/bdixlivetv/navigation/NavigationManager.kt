package com.shimulfp.bdixlivetv.navigation

import androidx.compose.runtime.*
import com.shimulfp.bdixlivetv.Channel
import com.shimulfp.bdixlivetv.models.Movie
import com.shimulfp.bdixlivetv.models.StreamUrl

/**
 * Centralized navigation management for the app
 * Handles all screen transitions and state
 */

class NavigationManager {
    private val _currentNav = mutableStateOf(NavTarget.HOME)
    private val _previousNav = mutableStateOf(NavTarget.HOME)
    private val _selectedMovie = mutableStateOf<Movie?>(null)

    val currentNav: State<NavTarget> = _currentNav
    val previousNav: State<NavTarget> = _previousNav
    val selectedMovie: State<Movie?> = _selectedMovie

    // Navigation stack for back button handling
    private val navStack = mutableListOf<NavTarget>()

    fun navigateTo(target: NavTarget) {
        if (target == NavTarget.PYTHON_TEST) {
            // Special case - show dialog
            return
        }

        // Push current to stack
        if (_currentNav.value != target) {
            navStack.add(_currentNav.value)
        }

        _currentNav.value = target
    }

    fun navigateBack(): Boolean {
        if (navStack.isNotEmpty()) {
            val target = navStack.removeAt(navStack.size - 1)
            _currentNav.value = target
            return true
        }
        return false
    }

    fun selectMovie(movie: Movie) {
        _selectedMovie.value = movie
    }

    fun clearSelectedMovie() {
        _selectedMovie.value = null
    }

    fun resetToHome() {
        _currentNav.value = NavTarget.HOME
        _previousNav.value = NavTarget.HOME
        _selectedMovie.value = null
        navStack.clear()
    }

    companion object {
        @Stable
        fun getInstance(): NavigationManager {
            return NavigationManager()
        }
    }
}

enum class NavTarget {
    HOME,
    ALL_CONTENT,
    MOVIES,
    MOVIE_DETAIL,
    MOVIES_HINDI,
    MOVIES_SOUTH,
    MOVIES_HOLLYWOOD,
    SERIES_KOREAN,
    SEARCH,
    SETTINGS,
    PYTHON_TEST
}

/**
 * Navigation state holder for MainActivity
 */
data class NavigationState(
    val currentNav: NavTarget = NavTarget.HOME,
    val previousNav: NavTarget = NavTarget.HOME,
    val selectedMovie: Movie? = null
) {
    fun navigateTo(target: NavTarget): NavigationState {
        return copy(
            currentNav = target,
            previousNav = currentNav
        )
    }

    fun navigateBack(): NavigationState {
        return copy(
            currentNav = previousNav,
            previousNav = NavTarget.HOME
        )
    }

    fun selectMovie(movie: Movie): NavigationState {
        return copy(
            currentNav = NavTarget.MOVIE_DETAIL,
            selectedMovie = movie
        )
    }

    fun resetToHome(): NavigationState {
        return NavigationState()
    }
}

/**
 * Screen-specific state holders
 */

data class HomeScreenState(
    val bdixChannels: List<Channel> = emptyList(),
    val aynaChannels: List<Channel> = emptyList(),
    val isSyncing: Boolean = false,
    val pythonStatus: String = "Loading...",
    val isBdixAvailable: Boolean = false,
    val isCheckingBdix: Boolean = false,
    val bdixStatusMessage: String = "Checking...",
    val cacheAgeMinutes: Long = 0L,
    val githubTokenAvailable: Boolean = false,
    val isBackgroundSyncing: Boolean = false,
    val lastSyncStatus: String? = null,
    val lastSyncTime: Long = 0L,
    val recentMovies: List<Movie> = emptyList(),
    val showDebugInfo: Boolean = false
)

data class MoviesScreenState(
    val selectedCategory: MovieCategory = MovieCategory.ALL,
    val displayedMovies: List<Movie> = emptyList(),
    val recentlyAdded: List<Movie> = emptyList(),
    val continueWatching: List<Movie> = emptyList(),
    val favorites: List<Movie> = emptyList(),
    val isRefreshing: Boolean = false,
    val uiState: MovieUiState = MovieUiState.Loading
)

data class SearchScreenState(
    val searchQuery: String = "",
    val searchResults: List<Movie> = emptyList(),
    val allChannels: List<Channel> = emptyList()
)

data class SettingsScreenState(
    val githubTokenAvailable: Boolean = false,
    val isBackgroundSyncing: Boolean = false,
    val lastSyncStatus: String? = null,
    val lastSyncTime: Long = 0L,
    val pythonScriptsStatus: String = "Loading...",
    val isUpdatingScripts: Boolean = false,
    val movieCacheInfo: String? = null,
    val serverStatus: String = "Checking...",
    val isCheckingServers: Boolean = false,
    val channelCacheInfo: String? = null,
    val aynaUsername: String = "",
    val aynaPassword: String = ""
)

/**
 * Helper functions for navigation
 */

fun shouldShowBackButton(currentNav: NavTarget): Boolean {
    return when (currentNav) {
        NavTarget.HOME -> false
        NavTarget.SEARCH -> false
        else -> true
    }
}

fun getScreenTitle(currentNav: NavTarget): String {
    return when (currentNav) {
        NavTarget.HOME -> "BDIX TV"
        NavTarget.ALL_CONTENT -> "All Content"
        NavTarget.MOVIES -> "Movies"
        NavTarget.MOVIE_DETAIL -> "Movie Details"
        NavTarget.MOVIES_HINDI -> "Hindi Movies"
        NavTarget.MOVIES_SOUTH -> "South Dubbed"
        NavTarget.MOVIES_HOLLYWOOD -> "Hollywood"
        NavTarget.SERIES_KOREAN -> "Korean Series"
        NavTarget.SEARCH -> "Search"
        NavTarget.SETTINGS -> "Settings"
        NavTarget.PYTHON_TEST -> "Python Test"
    }
}

// Import these from your existing models
enum class MovieCategory {
    ALL,
    HINDI,
    SOUTH_DUBBED,
    HOLLYWOOD;

    val displayName: String
        get() = when (this) {
            ALL -> "All Movies"
            HINDI -> "Hindi"
            SOUTH_DUBBED -> "South Dubbed"
            HOLLYWOOD -> "Hollywood"
        }
}

sealed class MovieUiState {
    data object Loading : MovieUiState()
    data object Empty : MovieUiState()
    data class Success(val movies: List<Movie>) : MovieUiState()
    data class Error(val message: String) : MovieUiState()
}

/**
 * Movie data model placeholder
 * Update this with your actual Movie model
 */
data class Movie(
    val id: String,
    val title: String,
    val poster: String,
    val quality: String,
    val year: String,
    val language: String,
    val category: MovieCategory,
    val genres: List<String>,
    val streamUrls: List<StreamUrl>,
    val audioInfo: String,
    val codec: String,
    val serverName: String,
    val watchProgress: Float = 0f
)

/**
 * Action callbacks for MainActivity
 */
data class NavigationActions(
    val onRefreshChannels: () -> Unit,
    val onManualRefresh: () -> Unit,
    val onRetryBdixCheck: () -> Unit,
    val onManualSync: () -> Unit,
    val onMovieClick: (Movie) -> Unit,
    val onMoviePlayClick: (Movie) -> Unit,
    val onChannelClick: (Int, List<Channel>) -> Unit,
    val onSaveCurrentProgress: () -> Unit,
    val onActivityFinish: () -> Unit
)
