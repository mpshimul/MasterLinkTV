"""
AynaOTT Scraper with Caching - Gets channels with token and cache management
Now with URL validation!
"""

import json
import time
import requests
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Any, Optional, Tuple

from aynaott_auth_refresh import AynaOTTAuthRefresh
from channel_cache import get_channel_cache

# Disable SSL warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class URLValidator:
    """Validates if stream URLs are actually playable"""
    
    def __init__(self, timeout: int = 5, max_workers: int = 15):
        self.timeout = timeout
        self.max_workers = max_workers
        self.valid_count = 0
        self.invalid_count = 0
    
    def validate_single_url(self, url: str) -> Tuple[str, bool, str]:
        """
        Validate a single URL
        Returns: (url, is_valid, reason)
        """
        try:
            if not url or not url.startswith('http'):
                return (url, False, "Invalid URL format")
            
            # Create session
            session = requests.Session()
            session.verify = False
            session.timeout = self.timeout
            
            # Common headers to mimic a player
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive',
            }
            
            # For HLS streams (.m3u8), we need to check the manifest
            if '.m3u8' in url.lower():
                return self._validate_hls(session, url, headers)
            else:
                return self._validate_direct(session, url, headers)
                
        except requests.exceptions.Timeout:
            return (url, False, "Timeout")
        except requests.exceptions.ConnectionError:
            return (url, False, "Connection error")
        except Exception as e:
            return (url, False, f"Error: {str(e)[:50]}")
    
    def _validate_hls(self, session: requests.Session, url: str, headers: dict) -> Tuple[str, bool, str]:
        """Validate HLS (.m3u8) stream"""
        try:
            response = session.get(url, headers=headers, timeout=self.timeout, stream=True)
            
            # Check status code
            if response.status_code != 200:
                return (url, False, f"HTTP {response.status_code}")
            
            # Read first part of content
            content = response.text[:2000]
            
            # Check if it's a valid HLS manifest
            if '#EXTM3U' in content:
                # Valid HLS manifest
                if '#EXT-X-STREAM-INF' in content or '#EXTINF' in content:
                    return (url, True, "Valid HLS")
                else:
                    return (url, True, "Valid M3U8")
            else:
                return (url, False, "Not a valid HLS manifest")
                
        except Exception as e:
            return (url, False, f"HLS error: {str(e)[:30]}")
    
    def _validate_direct(self, session: requests.Session, url: str, headers: dict) -> Tuple[str, bool, str]:
        """Validate direct stream URL"""
        try:
            # Use HEAD request first (faster)
            response = session.head(url, headers=headers, timeout=self.timeout, allow_redirects=True)
            
            if response.status_code == 200:
                content_type = response.headers.get('Content-Type', '').lower()
                
                # Check for video/audio content types
                valid_types = ['video', 'audio', 'application/octet-stream', 
                              'application/x-mpegurl', 'application/vnd.apple.mpegurl']
                
                if any(vt in content_type for vt in valid_types):
                    return (url, True, "Valid stream")
                elif content_type:
                    return (url, True, f"Content: {content_type[:30]}")
                else:
                    return (url, True, "URL accessible")
            
            elif response.status_code == 405:
                # HEAD not allowed, try GET
                response = session.get(url, headers=headers, timeout=self.timeout, stream=True)
                if response.status_code == 200:
                    return (url, True, "Valid (GET)")
                return (url, False, f"HTTP {response.status_code}")
            
            else:
                return (url, False, f"HTTP {response.status_code}")
                
        except Exception as e:
            return (url, False, f"Direct error: {str(e)[:30]}")
    
    def validate_channels(self, channels: List[Dict[str, Any]], 
                         progress_callback=None) -> List[Dict[str, Any]]:
        """
        Validate all channels and return only valid ones
        """
        if not channels:
            return []
        
        print(f"\n🔍 VALIDATING {len(channels)} CHANNEL URLs...")
        print(f"   Using {self.max_workers} workers, {self.timeout}s timeout")
        
        valid_channels = []
        self.valid_count = 0
        self.invalid_count = 0
        start_time = time.time()
        
        # Create list of (index, channel, url) for validation
        to_validate = []
        for idx, channel in enumerate(channels):
            urls = channel.get('urls', [])
            if urls and len(urls) > 0:
                to_validate.append((idx, channel, urls[0]))
            else:
                stream_url = channel.get('stream_url', '')
                if stream_url:
                    to_validate.append((idx, channel, stream_url))
        
        # Validate concurrently
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_channel = {
                executor.submit(self.validate_single_url, item[2]): item
                for item in to_validate
            }
            
            for future in as_completed(future_to_channel):
                idx, channel, url = future_to_channel[future]
                
                try:
                    validated_url, is_valid, reason = future.result(timeout=self.timeout + 2)
                    
                    if is_valid:
                        valid_channels.append(channel)
                        self.valid_count += 1
                    else:
                        self.invalid_count += 1
                        # Uncomment to see invalid channels:
                        # print(f"   ❌ {channel.get('name', 'Unknown')}: {reason}")
                    
                    # Progress update
                    total_done = self.valid_count + self.invalid_count
                    if total_done % 20 == 0:
                        elapsed = time.time() - start_time
                        rate = total_done / elapsed if elapsed > 0 else 0
                        print(f"   Progress: {total_done}/{len(to_validate)} "
                              f"(✅{self.valid_count} ❌{self.invalid_count}) "
                              f"[{rate:.1f}/sec]")
                        
                        if progress_callback:
                            progress_callback(total_done, len(to_validate), 
                                            self.valid_count, self.invalid_count)
                    
                except Exception as e:
                    self.invalid_count += 1
        
        elapsed = time.time() - start_time
        
        print(f"\n✅ VALIDATION COMPLETE in {elapsed:.1f}s")
        print(f"   ✅ Valid: {self.valid_count}")
        print(f"   ❌ Invalid: {self.invalid_count}")
        print(f"   📊 Success rate: {(self.valid_count/len(to_validate)*100):.1f}%")
        
        return valid_channels


class AynaOTTCachedScraper:
    def __init__(self, data_dir: str = ""):
        self.data_dir = data_dir
        self.auth = AynaOTTAuthRefresh(data_dir)
        self.channel_cache = get_channel_cache(data_dir)
        self.DEVICE_ID = "C6C015EFBB5C67CDBADD84E72DBF3474"
        self.OPERATOR_ID = "1fb1b4c7-dbd9-469e-88a2-c207dc195869"
        
        # Threading config
        self.MAX_WORKERS = 10
        self.TIMEOUT = 8
        
        # URL Validator
        self.validator = URLValidator(timeout=5, max_workers=15)
        
        # Validation toggle
        self.VALIDATE_URLS = True  # Set to False to skip validation
        
        print(f"📱 AynaOTT Cached Scraper initialized")
        print(f"   URL Validation: {'ENABLED' if self.VALIDATE_URLS else 'DISABLED'}")
    
    def get_channels(self, username: str = "", password: str = "", 
                    force_refresh: bool = False,
                    validate_urls: bool = True) -> List[Dict[str, Any]]:
        """
        Get channels with caching logic
        """
        print("\n🔄 GETTING AYNAOTT CHANNELS")
        
        # Check cache first (unless forcing refresh)
        if not force_refresh:
            cached_channels = self.channel_cache.get_channels()
            if cached_channels:
                cache_age = self.channel_cache.get_cache_age()
                if cache_age:
                    hours = cache_age.total_seconds() / 3600
                    print(f"✅ Using cached channels ({hours:.1f} hours old)")
                else:
                    print(f"✅ Using cached channels")
                return cached_channels
        
        print("🔍 Cache expired or force refresh, fetching new channels...")
        
        # Ensure we have a valid token
        if not self.auth.ensure_valid_token(username, password):
            print("❌ Cannot get valid token")
            return []
        
        # Get channel definitions
        channel_definitions = self._get_channel_definitions()
        if not channel_definitions:
            print("❌ No channel definitions")
            return []
        
        # Get stream URLs
        print(f"🔗 Getting stream URLs for {len(channel_definitions)} channels...")
        raw_channels = self._get_stream_urls_concurrent(channel_definitions)
        
        if not raw_channels:
            print("❌ No channels with stream URLs")
            return []
        
        # Restructure for Android
        android_channels = self._restructure_channels(raw_channels)
        
        # ========== VALIDATE URLs ==========
        if validate_urls and self.VALIDATE_URLS and android_channels:
            print(f"\n🔍 Starting URL validation...")
            original_count = len(android_channels)
            
            android_channels = self.validator.validate_channels(android_channels)
            
            removed_count = original_count - len(android_channels)
            print(f"   Removed {removed_count} invalid channels")
        # ===================================
        
        # Cache the results
        if android_channels:
            self.channel_cache.save_channels(android_channels, source="ayna")
            print(f"✅ Cached {len(android_channels)} VALID channels")
        
        return android_channels or []
    
    def _get_channel_definitions(self) -> List[Dict[str, Any]]:
        """Get all channel definitions"""
        try:
            all_channels = []
            page = 1
            per_page = 50
            
            print("📡 Fetching channel definitions...")
            
            while True:
                channels_url = "https://web.aynaott.com/api/player/channels"
                params = {
                    "language": "en",
                    "operator_id": self.OPERATOR_ID,
                    "device_id": self.DEVICE_ID,
                    "density": "1",
                    "client": "browser",
                    "platform": "web",
                    "os": "windows",
                    "page": str(page),
                    "per_page": str(per_page)
                }
                
                response = self.auth.get_session().get(channels_url, params=params, timeout=10)
                
                if response.status_code != 200:
                    break
                
                data = response.json()
                if data.get('code') != 1 or not data.get('content'):
                    break
                
                content = data['content']
                channels_data = content.get('data', [])
                
                if not channels_data:
                    break
                
                all_channels.extend(channels_data)
                
                # Check pagination
                current_page = content.get('current_page', page)
                last_page = content.get('last_page', 1)
                
                if current_page >= last_page:
                    break
                
                page += 1
                time.sleep(0.2)
            
            print(f"✅ Found {len(all_channels)} channel definitions")
            return all_channels
            
        except Exception as e:
            print(f"❌ Error: {e}")
            return []
    
    def _get_stream_url_single(self, channel: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Get stream URL for single channel"""
        try:
            channel_id = channel.get('id')
            if not channel_id:
                return None
            
            thread_session = requests.Session()
            thread_session.verify = False
            thread_session.timeout = self.TIMEOUT
            thread_session.headers.update(self.auth.get_headers())
            
            url = "https://web.aynaott.com/api/player/streams"
            params = {
                "language": "en",
                "operator_id": self.OPERATOR_ID,
                "device_id": self.DEVICE_ID,
                "density": "1",
                "client": "browser",
                "platform": "web",
                "os": "windows",
                "media_id": channel_id
            }
            
            response = thread_session.get(url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                if data.get("code") == 1 and data.get("content"):
                    content = data["content"]
                    if content and len(content) > 0:
                        stream_url = content[0].get("src", {}).get("url")
                        if stream_url and stream_url.startswith('http'):
                            return {
                                "name": channel.get('title', 'Unknown'),
                                "stream_url": stream_url,
                                "logo": channel.get('image') or channel.get('landscapeImage', ''),
                                "category": channel.get('category', 'General'),
                                "source": "ayna",
                                "id": channel_id
                            }
            
            return None
            
        except Exception:
            return None
    
    def _get_stream_urls_concurrent(self, channel_definitions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Get stream URLs using multi-workers"""
        if not channel_definitions:
            return []
        
        print(f"⚡ Getting streams with {self.MAX_WORKERS} workers...")
        
        results = []
        successful = 0
        start_time = time.time()
        
        with ThreadPoolExecutor(max_workers=self.MAX_WORKERS) as executor:
            future_to_channel = {
                executor.submit(self._get_stream_url_single, channel): channel 
                for channel in channel_definitions
            }
            
            for future in as_completed(future_to_channel):
                try:
                    result = future.result(timeout=self.TIMEOUT + 2)
                    if result:
                        results.append(result)
                        successful += 1
                        
                        # Progress update
                        if successful % 10 == 0:
                            elapsed = time.time() - start_time
                            rate = successful / elapsed if elapsed > 0 else 0
                            print(f"   {successful}/{len(channel_definitions)} "
                                  f"({rate:.1f} channels/sec)")
                        
                except Exception:
                    pass
        
        elapsed = time.time() - start_time
        print(f"✅ Stream URLs completed in {elapsed:.1f}s")
        print(f"   {successful} successful out of {len(channel_definitions)}")
        
        return results
    
    def _restructure_channels(self, raw_channels: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Restructure channels for Android"""
        android_channels = []
        
        for channel in raw_channels:
            name = channel.get('name', 'Unknown').upper().strip()
            stream_url = channel.get('stream_url')
            
            if not stream_url:
                continue
            
            android_channels.append({
                'name': name,
                'urls': [stream_url],
                'logo': channel.get('logo', ''),
                'category': channel.get('category', 'General'),
                'source': 'ayna'
            })
        
        # Sort alphabetically
        android_channels.sort(key=lambda x: x['name'])
        
        return android_channels
    
    def clear_cache(self):
        """Clear channel cache"""
        self.channel_cache.clear_cache()
    
    def get_cache_info(self) -> Dict[str, Any]:
        """Get cache information"""
        cache_age = self.channel_cache.get_cache_age()
        token_age = self.auth.token_manager.get_tokens_age()
        
        info = {
            "has_cache": bool(self.channel_cache.get_channels()),
            "cache_expired": self.channel_cache.is_expired(),
            "token_valid": self.auth.token_manager.is_token_valid(),
        }
        
        if cache_age:
            info["cache_age_hours"] = cache_age.total_seconds() / 3600
        
        if token_age:
            info["token_age_hours"] = token_age.total_seconds() / 3600
        
        return info


def get_channels_with_cache(data_dir: str, username: str, password: str, 
                           force_refresh: bool = False,
                           validate_urls: bool = True):
    """
    Main function for Android
    """
    try:
        scraper = AynaOTTCachedScraper(data_dir)
        channels = scraper.get_channels(username, password, force_refresh, validate_urls)
        return channels
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return []


# ========== STANDALONE TEST ==========
if __name__ == "__main__":
    print("=" * 60)
    print("🧪 TESTING URL VALIDATION")
    print("=" * 60)
    
    # Test URLs
    test_urls = [
        "https://example.com/stream.m3u8",
        "https://httpbin.org/get",
        "https://invalid.nonexistent.url/test.m3u8",
    ]
    
    validator = URLValidator(timeout=5)
    
    for url in test_urls:
        result = validator.validate_single_url(url)
        status = "✅" if result[1] else "❌"
        print(f"{status} {result[0][:50]}... -> {result[2]}")