"""
Simple bootstrap for testing
"""

import json
from typing import List, Dict, Any

def get_test_channels() -> List[Dict[str, Any]]:
    """Get test channels"""
    return [
        {
            "name": "ATN BANGLA",
            "urls": ["https://cdn1.skynewsbd.com:8081/hls/atn.m3u8"],
            "logo": "https://upload.wikimedia.org/wikipedia/en/4/4e/ATN_Bangla_logo.svg",
            "category": "Entertainment",
            "source": "test"
        },
        {
            "name": "CHANNEL I",
            "urls": ["https://cdn1.skynewsbd.com:8081/hls/channel.m3u8"],
            "logo": "https://upload.wikimedia.org/wikipedia/en/7/7e/Channel_i_logo.svg",
            "category": "Entertainment",
            "source": "test"
        },
        {
            "name": "NTV",
            "urls": ["https://cdn1.skynewsbd.com:8081/hls/ntv.m3u8"],
            "logo": "https://upload.wikimedia.org/wikipedia/commons/2/2a/Ntv_logo.svg",
            "category": "News",
            "source": "test"
        }
    ]