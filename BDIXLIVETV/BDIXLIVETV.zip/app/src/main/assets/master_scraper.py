"""
Master Scraper - Actually scrapes other sources (KSB, BasNet, RedForce)
"""

import json
import os
import sys
import time
import re
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse
from typing import List, Dict, Any, Optional

# Add current directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Fallback Image URL
DEFAULT_LOGO = "https://raw.githubusercontent.com/shimu/BDIX-TV/main/assets/default_logo.png"

def get_unified_name(name):
    """Optimized name unification"""
    if not name:
        return "Unknown"
    
    name = str(name).upper().strip()
    
    # Special cases
    if name in ["GAZI TV", "GAZI", "GTV BD", "GTV HD", "GTV", "GAZI TV HD"]:
        return "GTV"
    
    # Remove quality suffixes
    name = name.replace(" HD", "").replace(" SD", "").replace(".HD", "").replace(".SD", "")
    
    # Common aliases
    aliases = {
        "EKATTUR": "EKATTOR TV",
        "INDEPENDENT": "INDEPENDENT TV",
        "ALJAZEETA": "ALJAZEERA",
        "ASIAH TV": "ASIAN TV",
        "NICK": "NICKELODEON",
        "SONY ENT": "SONY ENTERTAINMENT",
        "SONY MAX 2": "SONY MAX",
        "SONY YAY": "SONY YAY HINDI",
        "SONY AATH": "SONY AAT",
        "& PICTURE": "AND PICTURE",
        "AND PICTURS": "AND PICTURE",
        "GEO NEWS": "GEO TV",
        "ZING": "ZING TV",
        "ZOOM": "ZOOM TV",
        "DISNEY JUNIAR": "DISNEY JUNIOR",
    }
    
    return aliases.get(name, name)

def get_sort_key(channel_name):
    """Create sort key for alphabetical sorting"""
    name = channel_name.upper()
    
    # Remove prefixes
    prefixes = ["THE ", "A ", "AN "]
    for prefix in prefixes:
        if name.startswith(prefix):
            name = name[len(prefix):]
            break
    
    sort_name = name.lstrip("0123456789.- ")
    
    # Handle numbers at start
    if channel_name[:1].isdigit():
        match = re.match(r'^(\d+)', channel_name)
        if match:
            num = match.group(1)
            sort_name = num.zfill(5) + channel_name[len(num):]
    
    return sort_name

def convert_embed_to_m3u8(embed_url: str) -> Optional[str]:
    """Convert embed.html URL to m3u8 URL"""
    if not embed_url or 'embed.html' not in embed_url:
        return None
    
    # Replace /embed.html with /index.m3u8
    m3u8_url = embed_url.replace('/embed.html', '/index.m3u8')
    
    # Fix double slashes properly
    try:
        parsed = urlparse(m3u8_url)
        # Reconstruct with single slashes in path
        path = parsed.path.replace('//', '/')
        m3u8_url = f"{parsed.scheme}://{parsed.netloc}{path}"
        if parsed.query:
            m3u8_url += f"?{parsed.query}"
    except:
        # Fallback for simple cases
        m3u8_url = m3u8_url.replace('://', '___TEMP___').replace('//', '/').replace('___TEMP___', '://')
    
    return m3u8_url

def process_channel_item(item: Dict, source: str) -> Optional[Dict]:
    """Process a channel item from any source"""
    if not isinstance(item, dict):
        return None
    
    # Get name
    name = None
    name_fields = ['name', 'title', 'channel_name', 'channel', 'stream_name']
    for field in name_fields:
        if field in item:
            name_value = item[field]
            if isinstance(name_value, str) and name_value.strip():
                name = name_value.strip()
                break
    
    if not name:
        return None
    
    # Get URL
    url = None
    url_fields = ['url', 'stream_url', 'm3u8_url', 'playback_url', 'stream', 'link', 'play_url']
    for field in url_fields:
        if field in item:
            url_value = item[field]
            if isinstance(url_value, str) and url_value.strip():
                url = url_value.strip()
                break
    
    if not url:
        return None
    
    # Convert KSB embed URLs to m3u8
    if source == 'ksb' and 'embed.html' in url:
        url = convert_embed_to_m3u8(url)
        if not url:
            return None
    
    # Get logo
    logo = ""
    logo_fields = ['logo', 'image', 'thumbnail', 'icon']
    for field in logo_fields:
        if field in item:
            logo_value = item[field]
            if isinstance(logo_value, str) and logo_value.strip():
                logo = logo_value.strip()
                break
    
    # Get category
    category = "General"
    category_fields = ['category', 'group', 'type', 'genre']
    for field in category_fields:
        if field in item:
            category_value = item[field]
            if isinstance(category_value, str) and category_value.strip():
                category = category_value.strip()
                break
    
    # Add source info
    return {
        'name': name,
        'url': url,
        'logo': logo,
        'category': category,
        'source': source,
        'original_name': name  # Keep original for debugging
    }

def get_other_sources_channels() -> List[Dict[str, Any]]:
    """
    Actually scrapes channels from KSB, BasNet, RedForce
    Returns real working stream URLs
    """
    print("🔄 Getting channels from other sources with actual scraping...")
    
    # Create a simple MasterScraper instance
    scraper = SimpleMasterScraper()
    return scraper.run()

class SimpleMasterScraper:
    def __init__(self, output_dir=None):
        self.output_dir = output_dir
        
        # Channel files
        self.redforce_file = os.path.join(current_dir, "redforce.json")
        self.basnet_file = os.path.join(current_dir, "basnet.json")
        self.ksb_file = os.path.join(current_dir, "ksb.json")
        
        # Initialize scrapers
        self.scrapers = {}
        self.initialize_scrapers()
    
    def initialize_scrapers(self):
        """Initialize available scrapers"""
        print("🔧 Initializing scrapers...")
        
        # Check and initialize RedForce
        if os.path.exists(self.redforce_file):
            try:
                from redforce import TargetedRedForceCrawler
                self.scrapers['redforce'] = {
                    'crawler': TargetedRedForceCrawler(None, self.redforce_file),
                    'method': 'crawl_all'
                }
                print("✓ RedForce: Ready")
            except ImportError as e:
                print(f"⚠️ RedForce: {e}")
        else:
            print(f"⚠️ RedForce: File not found - {self.redforce_file}")
        
        # Check and initialize BasNet
        if os.path.exists(self.basnet_file):
            try:
                from basnet import SmartRequestCrawler
                self.scrapers['basnet'] = {
                    'crawler': SmartRequestCrawler(None, self.basnet_file),
                    'method': 'crawl_smart'
                }
                print("✓ BasNet: Ready")
            except ImportError as e:
                print(f"⚠️ BasNet: {e}")
        else:
            print(f"⚠️ BasNet: File not found - {self.basnet_file}")
        
        # Check and initialize KSB
        if os.path.exists(self.ksb_file):
            try:
                from ksb import OptimizedChannelCrawler
                self.scrapers['ksb'] = {
                    'crawler': OptimizedChannelCrawler(None, self.ksb_file),
                    'method': 'crawl_concurrent'
                }
                print("✓ KSB: Ready")
            except ImportError as e:
                print(f"⚠️ KSB: {e}")
        else:
            print(f"⚠️ KSB: File not found - {self.ksb_file}")
    
    def run_scraper(self, scraper_name: str):
        """Run a specific scraper"""
        if scraper_name not in self.scrapers:
            print(f"⚠️ {scraper_name}: Scraper not available")
            return []
        
        scraper_info = self.scrapers[scraper_name]
        crawler = scraper_info['crawler']
        method_name = scraper_info['method']
        
        print(f"🚀 Starting {scraper_name}...")
        start_time = time.time()
        
        try:
            # Get the method
            method = getattr(crawler, method_name)
            
            # Call with appropriate parameters
            if method_name == 'crawl_all':
                result = method(max_workers=10)  # Reduced for Android
            elif method_name == 'crawl_smart':
                result = method(max_workers=10, delay=0.3)  # Reduced for Android
            elif method_name == 'crawl_concurrent':
                result = method(max_workers=10)  # Reduced for Android
            else:
                result = method()
            
            elapsed = time.time() - start_time
            
            # Process results
            processed_channels = []
            if result:
                for item in result:
                    processed = process_channel_item(item, scraper_name)
                    if processed:
                        processed_channels.append(processed)
            
            print(f"✅ {scraper_name}: {len(processed_channels)} channels in {elapsed:.1f}s")
            return processed_channels
            
        except Exception as e:
            elapsed = time.time() - start_time
            print(f"❌ {scraper_name} failed after {elapsed:.1f}s: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    def run_all_scrapers(self):
        """Run all scrapers in parallel"""
        if not self.scrapers:
            print("❌ No scrapers available!")
            return {}
        
        print(f"Running {len(self.scrapers)} scrapers...")
        scrape_start = time.time()
        
        results = {}
        
        with ThreadPoolExecutor(max_workers=len(self.scrapers)) as executor:
            # Submit all scraping tasks
            future_to_scraper = {
                executor.submit(self.run_scraper, scraper_name): scraper_name 
                for scraper_name in self.scrapers.keys()
            }
            
            # Collect results
            for future in as_completed(future_to_scraper):
                scraper_name = future_to_scraper[future]
                try:
                    channels = future.result(timeout=30)  # Reduced timeout
                    results[scraper_name] = channels
                except Exception as e:
                    print(f"❌ {scraper_name} execution failed: {e}")
                    results[scraper_name] = []
        
        scrape_time = time.time() - scrape_start
        print(f"⏱️ All scraping completed in {scrape_time:.1f} seconds")
        
        return results
    
    def merge_channels(self, all_results: Dict[str, List[Dict]]) -> List[Dict]:
        """Merge channels from all sources using unified names"""
        print("Merging and unifying channels...")
        
        master_dict = {}
        
        for source_name, source_channels in all_results.items():
            if not source_channels:
                continue
            
            for channel in source_channels:
                # Get unified name
                clean_name = get_unified_name(channel['name'])
                url = channel['url']
                logo = channel['logo']
                category = channel['category']
                original_source = channel['source']
                
                if not url:
                    continue
                
                if clean_name not in master_dict:
                    # New channel
                    master_dict[clean_name] = {
                        "name": clean_name,
                        "logo": logo if logo else DEFAULT_LOGO,
                        "category": category,
                        "urls": [url],
                        "sources": [original_source],
                        "original_names": [channel.get('original_name', clean_name)]
                    }
                else:
                    # Existing channel
                    existing = master_dict[clean_name]
                    
                    # Add URL if not already present
                    if url not in existing["urls"]:
                        existing["urls"].append(url)
                    
                    # Add source if not already present
                    if original_source not in existing["sources"]:
                        existing["sources"].append(original_source)
                    
                    # Update logo if current is default and new one exists
                    if existing["logo"] == DEFAULT_LOGO and logo:
                        existing["logo"] = logo
                    
                    # Keep original names for reference
                    orig_name = channel.get('original_name', clean_name)
                    if orig_name not in existing["original_names"]:
                        existing["original_names"].append(orig_name)
        
        # Create final list
        final_list = []
        for clean_name, channel_data in master_dict.items():
            final_channel = {
                "name": channel_data["name"],
                "logo": channel_data["logo"],
                "category": channel_data["category"],
                "urls": channel_data["urls"][:3],  # Max 3 URLs per channel
                "source": ",".join(channel_data["sources"]),
                "original_names": channel_data["original_names"][:3]  # For debugging
            }
            final_list.append(final_channel)
        
        # Sort alphabetically
        final_list.sort(key=lambda x: get_sort_key(x['name']))
        
        return final_list
    
    def run(self) -> List[Dict]:
        """Main method to run the master scraper"""
        overall_start = time.time()
        
        # Run all scrapers
        all_results = self.run_all_scrapers()
        
        if not any(all_results.values()):
            print("❌ No channels found from any source!")
            return []
        
        # Merge channels
        merged_channels = self.merge_channels(all_results)
        
        total_time = time.time() - overall_start
        
        print(f"✅ Total: {len(merged_channels)} channels in {total_time:.1f}s")
        
        return merged_channels

def get_fallback_channels() -> List[Dict[str, Any]]:
    """Get fallback channels when scraping fails"""
    return [
        {
            "name": "ATN BANGLA",
            "urls": ["https://cdn1.skynewsbd.com:8081/hls/atn.m3u8"],
            "logo": "https://upload.wikimedia.org/wikipedia/en/4/4e/ATN_Bangla_logo.svg",
            "category": "Entertainment",
            "source": "fallback"
        },
        {
            "name": "CHANNEL I",
            "urls": ["https://cdn1.skynewsbd.com:8081/hls/channel.m3u8"],
            "logo": "https://upload.wikimedia.org/wikipedia/en/7/7e/Channel_i_logo.svg",
            "category": "Entertainment",
            "source": "fallback"
        },
        {
            "name": "NTV",
            "urls": ["https://cdn1.skynewsbd.com:8081/hls/ntv.m3u8"],
            "logo": "https://upload.wikimedia.org/wikipedia/commons/2/2a/Ntv_logo.svg",
            "category": "News",
            "source": "fallback"
        }
    ]

def merge_channels(all_channels):
    """Merge channels from all sources using unified names"""
    if not all_channels:
        return get_fallback_channels()
    
    master_dict = {}
    
    for channel in all_channels:
        if not isinstance(channel, dict):
            continue
        
        clean_name = get_unified_name(channel.get('name', ''))
        url = channel.get('url', '') if 'url' in channel else (channel.get('urls', [''])[0] if channel.get('urls') else '')
        logo = channel.get('logo', '')
        category = channel.get('category', 'General')
        source = channel.get('source', 'unknown')
        original_name = channel.get('original_name', clean_name)
        
        if not url or not clean_name or clean_name == 'Unknown':
            continue
        
        if clean_name not in master_dict:
            # New channel
            master_dict[clean_name] = {
                "name": clean_name,
                "logo": logo if logo else DEFAULT_LOGO,
                "category": category,
                "urls": [url],
                "sources": [source],
                "original_names": [original_name]
            }
        else:
            # Existing channel
            existing = master_dict[clean_name]
            
            # Add URL if not already present
            if url not in existing["urls"]:
                existing["urls"].append(url)
            
            # Add source if not already present
            if source not in existing["sources"]:
                existing["sources"].append(source)
            
            # Update logo if current is default and new one exists
            if existing["logo"] == DEFAULT_LOGO and logo:
                existing["logo"] = logo
            
            # Keep original names for reference
            if original_name not in existing["original_names"]:
                existing["original_names"].append(original_name)
    
    # Create final list
    final_list = []
    for clean_name, channel_data in master_dict.items():
        final_channel = {
            "name": channel_data["name"],
            "logo": channel_data["logo"],
            "category": channel_data["category"],
            "urls": channel_data["urls"][:3],  # Max 3 URLs per channel
            "source": ",".join(channel_data["sources"]),
            "original_names": channel_data["original_names"][:3]
        }
        final_list.append(final_channel)
    
    return final_list

# Legacy functions for compatibility
def merge_all_sources_with_sync_simple() -> List[Dict[str, Any]]:
    """Legacy function"""
    channels = get_other_sources_channels()
    return merge_channels(channels)

# Android integration functions
def merge_all_sources_with_sync(username, password, device_id, github_token, enable_ayna=False):
    """
    Main function for Android app integration
    This will be called from Kotlin code
    """
    try:
        print(f"🔧 Master Scraper Parameters:")
        print(f"  - Username: {username}")
        print(f"  - Device ID: {device_id}")
        print(f"  - GitHub Token: {'*' * min(8, len(github_token)) if github_token else 'None'}")
        print(f"  - Enable AynaOTT: {enable_ayna}")
        
        # Get channels from other sources
        channels = get_other_sources_channels()
        
        # Merge and unify channels
        merged_channels = merge_channels(channels)
        
        print(f"✅ Total channels: {len(merged_channels)}")
        
        # Convert to simple format for Android
        android_channels = []
        for channel in merged_channels:
            android_channels.append({
                'name': channel['name'],
                'urls': channel['urls'],
                'logo': channel['logo'],
                'category': channel['category'],
                'source': channel['source']
            })
        
        print(f"✅ Returning {len(android_channels)} channels to Android")
        return android_channels
        
    except Exception as e:
        print(f"❌ Error in merge_all_sources_with_sync: {e}")
        import traceback
        traceback.print_exc()
        return get_fallback_channels()

def test_scraping():
    """Test the scrapers"""
    print("🧪 Testing other sources scrapers...")
    
    channels = get_other_sources_channels()
    
    if channels:
        print(f"✅ Success! Got {len(channels)} raw channels")
        
        # Merge channels
        merged_channels = merge_channels(channels)
        print(f"✅ After merging: {len(merged_channels)} unique channels")
        
        print("\n📺 Sample channels:")
        for i, ch in enumerate(merged_channels[:5]):
            print(f"  {i+1}. {ch['name'][:25]:25} | {ch['category']} | {ch['source']}")
            if ch.get('urls'):
                print(f"     URL: {ch['urls'][0][:50]}...")
    else:
        print("❌ No channels found")
        print("Using fallback channels...")
        channels = get_fallback_channels()
        print(f"Fallback: {len(channels)} channels")
        merged_channels = channels
    
    return merged_channels

if __name__ == "__main__":
    test_scraping()