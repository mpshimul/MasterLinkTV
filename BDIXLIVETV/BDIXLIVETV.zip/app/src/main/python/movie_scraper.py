"""
BDIX Movie Scraper - FIXED SORTING
Sorts by folder modified date (when content was ADDED), not by movie year
"""

import requests
from bs4 import BeautifulSoup
import json
import re
from urllib.parse import urljoin, unquote
from datetime import datetime
import hashlib
import time
import sys

# ============ CONFIGURATION ============

BDIX_SERVERS = [
    {
        "name": "English Movies",
        "base_url": "http://172.16.50.7/DHAKA-FLIX-7/English%20Movies/",
        "category": "HOLLYWOOD",
        "language": "English",
        "enabled": True
    },
    {
        "name": "Hindi Movies",
        "base_url": "http://172.16.50.14/DHAKA-FLIX-14/Hindi%20Movies/",
        "category": "HINDI",
        "language": "Hindi",
        "enabled": True
    },
    {
        "name": "South Hindi Dubbed",
        "base_url": "http://172.16.50.14/DHAKA-FLIX-14/SOUTH%20INDIAN%20MOVIES/Hindi%20Dubbed/",
        "category": "SOUTH_DUBBED",
        "language": "Hindi Dubbed",
        "enabled": True
    }
]

VIDEO_EXTENSIONS = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.webm', '.m4v', '.ts']
IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp']
POSTER_FILENAMES = ['a_AL_.jpg', 'poster.jpg', 'cover.jpg', 'folder.jpg', 'thumb.jpg', 
                    'a11.jpg', 'a20_.jpg', 'a.jpg', 'a_1_.jpg']

REQUEST_TIMEOUT = 15
MAX_DEPTH = 3
VERBOSE = True

def log(msg):
    if VERBOSE:
        print(msg)
        sys.stdout.flush()

# ============ MAIN SCRAPER CLASS ============

class BdixMovieScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        })
        self.movies_found = 0
    
    def scrape_all_servers(self, max_movies_per_server=400):
        """Scrape all servers and return movies sorted by FOLDER MODIFIED DATE"""
        all_movies = []
        
        log(f"[INFO] Starting scrape of {len(BDIX_SERVERS)} servers...")
        
        for i, server in enumerate(BDIX_SERVERS, 1):
            if not server.get('enabled', True):
                continue
            
            log(f"\n[{i}/{len(BDIX_SERVERS)}] {server['name']}")
            
            try:
                movies = self.scrape_server(
                    base_url=server['base_url'],
                    category=server['category'],
                    language=server['language'],
                    server_name=server['name'],
                    max_movies=max_movies_per_server
                )
                all_movies.extend(movies)
                log(f"[✓] Found {len(movies)} movies")
            except Exception as e:
                log(f"[✗] Error: {e}")
        
        # ⭐ CRITICAL: Sort by folder_modified_timestamp (DESCENDING = newest first)
        log(f"\n[INFO] Sorting {len(all_movies)} movies by folder modified date...")
        
        all_movies.sort(
            key=lambda x: x.get('folder_modified_timestamp', 0), 
            reverse=True  # Newest first!
        )
        
        # Debug: Show top 5 after sorting
        log("\n[DEBUG] Top 5 after sorting:")
        for i, m in enumerate(all_movies[:5], 1):
            log(f"  {i}. [{m.get('year', '?')}] {m.get('title', '?')[:30]} - Folder: {m.get('folder_modified', 'N/A')}")
        
        log(f"\n[✓] Total: {len(all_movies)} movies (sorted by newest added)")
        
        return all_movies
    
    def scrape_server(self, base_url, category, language, server_name, max_movies=400):
        """Scrape a single server"""
        movies = []
        
        try:
            # Get year folders
            entries = self.get_directory_entries(base_url)
            
            # Get only directories (year folders)
            directories = [e for e in entries if e['is_directory']]
            
            # ⭐ IMPORTANT: Sort year folders by THEIR modified date (not by year number!)
            # This way (2025) folder modified on 2026-01-28 comes before (2024) modified on 2026-01-26
            directories.sort(key=lambda x: x.get('last_modified_timestamp', 0), reverse=True)
            
            log(f"  → {len(directories)} year folders (sorted by modified date)")
            
            # Debug: Show folder order
            for d in directories[:3]:
                log(f"    • {d['name']} - Modified: {d.get('last_modified', 'N/A')}")
            
            # Process each year folder
            for idx, year_folder in enumerate(directories):
                if len(movies) >= max_movies:
                    log(f"  → Reached max {max_movies}")
                    break
                
                folder_name = year_folder['name']
                folder_url = year_folder['url']
                folder_modified = year_folder.get('last_modified', '')
                folder_modified_ts = year_folder.get('last_modified_timestamp', 0)
                
                # Progress
                pct = ((idx + 1) / len(directories)) * 100
                print(f"\r  Processing: [{idx+1}/{len(directories)}] {pct:.0f}% - {folder_name}", end="")
                sys.stdout.flush()
                
                # Get year from folder name
                year_value = self._extract_year(folder_name)
                
                if self._is_year_folder(folder_name):
                    # Scrape movies inside this year folder
                    folder_movies = self._scrape_year_folder(
                        folder_url=folder_url,
                        category=category,
                        language=language,
                        server_name=server_name,
                        year_value=year_value,
                        folder_modified=folder_modified,
                        folder_modified_ts=folder_modified_ts,
                        max_movies=max_movies - len(movies)
                    )
                    movies.extend(folder_movies)
                else:
                    # Direct movie folder
                    movie = self._scrape_movie_folder(
                        folder_url=folder_url,
                        folder_name=folder_name,
                        category=category,
                        language=language,
                        server_name=server_name,
                        folder_modified=folder_modified,
                        folder_modified_ts=folder_modified_ts
                    )
                    if movie:
                        movies.append(movie)
            
            print()  # New line after progress
            
        except Exception as e:
            log(f"  [ERROR] {e}")
            import traceback
            traceback.print_exc()
        
        return movies
    
    def _scrape_year_folder(self, folder_url, category, language, server_name,
                            year_value, folder_modified, folder_modified_ts, max_movies=400):
        """Scrape movies inside a year folder"""
        movies = []
        
        try:
            entries = self.get_directory_entries(folder_url)
            
            # Sort by modified date within the folder too
            entries.sort(key=lambda x: x.get('last_modified_timestamp', 0), reverse=True)
            
            for entry in entries:
                if len(movies) >= max_movies:
                    break
                
                if entry['is_directory']:
                    # Movie folder
                    movie = self._scrape_movie_folder(
                        folder_url=entry['url'],
                        folder_name=entry['name'],
                        category=category,
                        language=language,
                        server_name=server_name,
                        movie_modified=entry.get('last_modified', ''),
                        movie_modified_ts=entry.get('last_modified_timestamp', 0),
                        year_override=year_value,
                        # ⭐ Pass the YEAR FOLDER's modified date - this is key!
                        folder_modified=folder_modified,
                        folder_modified_ts=folder_modified_ts
                    )
                    if movie:
                        movies.append(movie)
                
                elif self._is_video_file(entry['name']):
                    # Direct video file
                    movie = self._create_movie_from_file(
                        entry, folder_url, category, language, server_name,
                        year_value, folder_modified, folder_modified_ts
                    )
                    if movie:
                        movies.append(movie)
        
        except Exception as e:
            log(f"    [ERROR] Year folder: {e}")
        
        return movies
    
    def _scrape_movie_folder(self, folder_url, folder_name, category, language, server_name,
                             movie_modified='', movie_modified_ts=0, year_override='',
                             folder_modified='', folder_modified_ts=0):
        """Scrape a movie folder to find video and poster"""
        
        try:
            entries = self.get_directory_entries(folder_url)
            
            video_file = None
            poster_file = None
            all_videos = []
            
            for entry in entries:
                if entry['is_directory']:
                    continue
                
                name = entry['name']
                
                if self._is_video_file(name):
                    all_videos.append(entry)
                    if video_file is None or self._is_better_quality(name, video_file['name']):
                        video_file = entry
                
                elif self._is_image_file(name):
                    name_lower = name.lower()
                    is_poster = any(
                        name_lower == p.lower() or name_lower.startswith(p.split('.')[0].lower())
                        for p in POSTER_FILENAMES
                    )
                    if is_poster or poster_file is None:
                        poster_file = entry
            
            if video_file:
                movie_info = self._parse_movie_name(folder_name)
                movie_id = hashlib.md5(video_file['url'].encode()).hexdigest()[:12]
                
                # Determine year
                year = movie_info.get('year') or year_override or ''
                
                # ⭐ Use folder_modified_ts for sorting (this is when content was ADDED)
                # If not available, fall back to movie's own modified time
                sort_timestamp = folder_modified_ts if folder_modified_ts > 0 else movie_modified_ts
                sort_date = folder_modified if folder_modified else movie_modified
                
                movie = {
                    'id': f"bdix_{movie_id}",
                    'title': movie_info['title'],
                    'originalTitle': folder_name,
                    'year': year,
                    'quality': movie_info['quality'],
                    'language': language,
                    'poster': poster_file['url'] if poster_file else '',
                    'backdrop': '',
                    'description': '',
                    'genres': movie_info.get('genres', ['Drama']),
                    'cast': [],
                    'director': '',
                    'duration': '',
                    'rating': '',
                    'streamUrls': self._build_stream_urls(all_videos, server_name),
                    'subtitles': [],
                    'source': 'BDIX',
                    'serverName': server_name,
                    'category': category,
                    'folderUrl': folder_url,
                    
                    # Movie's own modified time
                    'last_modified': movie_modified,
                    'last_modified_timestamp': movie_modified_ts,
                    
                    # ⭐ YEAR FOLDER's modified time - USE THIS FOR SORTING!
                    'folder_modified': sort_date,
                    'folder_modified_timestamp': sort_timestamp,
                    
                    'addedDate': int(time.time() * 1000),
                    'isFavorite': False,
                    'watchProgress': 0.0,
                    'lastWatched': 0
                }
                
                # Additional info
                video_info = self._parse_movie_name(video_file['name'])
                if video_info.get('audio_info'):
                    movie['audioInfo'] = video_info['audio_info']
                if video_info.get('codec'):
                    movie['codec'] = video_info['codec']
                
                return movie
        
        except Exception as e:
            pass  # Silently skip problematic folders
        
        return None
    
    def _create_movie_from_file(self, file_entry, parent_url, category, language, server_name,
                                year_value='', folder_modified='', folder_modified_ts=0):
        """Create movie from standalone video file"""
        try:
            name = file_entry['name']
            info = self._parse_movie_name(name)
            movie_id = hashlib.md5(file_entry['url'].encode()).hexdigest()[:12]
            
            year = info.get('year') or year_value or ''
            
            return {
                'id': f"bdix_{movie_id}",
                'title': info['title'],
                'originalTitle': name,
                'year': year,
                'quality': info['quality'],
                'language': language,
                'poster': '',
                'streamUrls': [{
                    'url': file_entry['url'],
                    'quality': info['quality'],
                    'server': server_name,
                    'isWorking': True
                }],
                'source': 'BDIX',
                'serverName': server_name,
                'category': category,
                'genres': info.get('genres', ['Drama']),
                'last_modified': file_entry.get('last_modified', ''),
                'last_modified_timestamp': file_entry.get('last_modified_timestamp', 0),
                'folder_modified': folder_modified,
                'folder_modified_timestamp': folder_modified_ts,
                'addedDate': int(time.time() * 1000),
                'isFavorite': False,
                'watchProgress': 0.0
            }
        except:
            return None
    
    def get_directory_entries(self, url):
        """Fetch and parse directory listing"""
        entries = []
        
        try:
            response = self.session.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Try pre tag first (most common)
            pre = soup.find('pre')
            if pre:
                entries = self._parse_pre_listing(pre, url)
            
            # Fallback to table
            if not entries:
                table = soup.find('table')
                if table:
                    entries = self._parse_table_listing(table, url)
            
            # Generic fallback
            if not entries:
                entries = self._parse_generic_listing(soup, url)
        
        except Exception as e:
            pass
        
        return entries
    
    def _parse_pre_listing(self, pre, base_url):
        """Parse pre-tag directory listing"""
        entries = []
        text = pre.get_text()
        lines = text.split('\n')
        
        for link in pre.find_all('a', href=True):
            href = link.get('href', '')
            name = unquote(link.text.strip())
            
            if href in ['../', '../', '/', '?'] or name in ['..', '../', 'Parent Directory']:
                continue
            
            is_dir = href.endswith('/')
            full_url = urljoin(base_url, href)
            
            # Find modification date
            last_mod = ''
            last_mod_ts = 0
            
            for line in lines:
                if name in line:
                    # Match: "28-Jan-2026 05:32" or "2026-01-28 05:32"
                    match = re.search(
                        r'(\d{2}-\w{3}-\d{4}\s+\d{2}:\d{2})|(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})',
                        line
                    )
                    if match:
                        last_mod = match.group()
                        last_mod_ts = self._parse_date(last_mod)
                    break
            
            entries.append({
                'name': name.rstrip('/'),
                'url': full_url,
                'is_directory': is_dir,
                'last_modified': last_mod,
                'last_modified_timestamp': last_mod_ts
            })
        
        return entries
    
    def _parse_table_listing(self, table, base_url):
        """Parse table-based directory listing"""
        entries = []
        
        for row in table.find_all('tr'):
            cols = row.find_all('td')
            if len(cols) < 2:
                continue
            
            link = row.find('a', href=True)
            if not link:
                continue
            
            href = link.get('href', '')
            name = unquote(link.text.strip() or href.rstrip('/'))
            
            if href in ['../', '../', '/'] or name in ['Parent Directory', '..']:
                continue
            
            is_dir = href.endswith('/')
            
            last_mod = ''
            last_mod_ts = 0
            for col in cols:
                match = re.search(
                    r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})|(\d{2}-\w{3}-\d{4}\s+\d{2}:\d{2})',
                    col.text
                )
                if match:
                    last_mod = match.group()
                    last_mod_ts = self._parse_date(last_mod)
                    break
            
            entries.append({
                'name': name.rstrip('/'),
                'url': urljoin(base_url, href),
                'is_directory': is_dir,
                'last_modified': last_mod,
                'last_modified_timestamp': last_mod_ts
            })
        
        return entries
    
    def _parse_generic_listing(self, soup, base_url):
        """Generic fallback parser"""
        entries = []
        
        for link in soup.find_all('a', href=True):
            href = link.get('href', '')
            name = unquote(link.text.strip() or href)
            
            if href in ['../', '../', '/', '#'] or name in ['..', '../', 'Parent Directory']:
                continue
            if href.startswith('?') or href.startswith('mailto:'):
                continue
            
            entries.append({
                'name': name.rstrip('/'),
                'url': urljoin(base_url, href),
                'is_directory': href.endswith('/'),
                'last_modified': '',
                'last_modified_timestamp': 0
            })
        
        return entries
    
    def _parse_date(self, date_str):
        """Convert date string to Unix timestamp"""
        formats = [
            '%d-%b-%Y %H:%M',   # 28-Jan-2026 05:32
            '%Y-%m-%d %H:%M',   # 2026-01-28 05:32
            '%d-%B-%Y %H:%M',   # 28-January-2026 05:32
        ]
        for fmt in formats:
            try:
                dt = datetime.strptime(date_str.strip(), fmt)
                return int(dt.timestamp())
            except:
                continue
        return 0
    
    def _extract_year(self, folder_name):
        """Extract year from folder name like (2025)"""
        match = re.search(r'(19|20)\d{2}', folder_name)
        return match.group() if match else ""
    
    def _is_year_folder(self, name):
        """Check if folder name is a year folder"""
        return bool(re.match(r'^[\(\[]?(19|20)\d{2}(-\d{4})?[\)\]]?$', name.strip()))
    
    def _is_video_file(self, name):
        return any(name.lower().endswith(ext) for ext in VIDEO_EXTENSIONS)
    
    def _is_image_file(self, name):
        return any(name.lower().endswith(ext) for ext in IMAGE_EXTENSIONS)
    
    def _is_better_quality(self, new, current):
        order = ['cam', 'hdcam', 'dvdrip', '480p', '720p', 'webdl', 'webrip', 'bluray', '1080p', '2160p', '4k']
        def score(n):
            lower = n.lower()
            for i, q in enumerate(order):
                if q in lower:
                    return i
            return 5
        return score(new) > score(current)
    
    def _build_stream_urls(self, video_entries, server_name):
        urls = []
        for entry in video_entries:
            info = self._parse_movie_name(entry['name'])
            urls.append({
                'url': entry['url'],
                'quality': info['quality'],
                'server': server_name,
                'fileName': entry['name'],
                'isWorking': True
            })
        # Sort by quality
        quality_order = {'4K': 0, '2160p': 0, '1080p': 1, 'BluRay': 2, 'WEB-DL': 3, '720p': 4, 'HDRip': 5}
        urls.sort(key=lambda x: quality_order.get(x['quality'], 99))
        return urls
    
    def _parse_movie_name(self, filename):
        """Parse movie info from filename"""
        name = filename
        for ext in VIDEO_EXTENSIONS:
            if name.lower().endswith(ext):
                name = name[:-len(ext)]
                break
        
        # Year
        year = ''
        m = re.search(r'[\(\[\s]?(19|20)\d{2}[\)\]\s]?', name)
        if m:
            year = re.search(r'(19|20)\d{2}', m.group()).group()
        
        # Quality
        quality = 'HD'
        for pattern, q in [
            (r'2160p|4K|UHD', '4K'), (r'1080p', '1080p'), (r'720p', '720p'),
            (r'480p', '480p'), (r'BluRay|BRRip', 'BluRay'), (r'WEB-?DL|WEBRip', 'WEB-DL'),
            (r'HDRip', 'HDRip'),
        ]:
            if re.search(pattern, name, re.IGNORECASE):
                quality = q
                break
        
        # Audio
        audio = ''
        am = re.search(r'\[?(Dual Audio|Hindi|English|Tamil|Telugu)[^\]]*\]?', name, re.IGNORECASE)
        if am:
            audio = am.group().strip('[]')
        
        # Codec
        codec = ''
        cm = re.search(r'(x264|x265|HEVC)', name, re.IGNORECASE)
        if cm:
            codec = cm.group()
        
        # Clean title
        title = name
        for p in [
            r'[\(\[]?(19|20)\d{2}[\)\]]?', r'(2160p|1080p|720p|480p|4K)',
            r'(BluRay|WEB-?DL|WEBRip|HDRip)', r'(x264|x265|HEVC|10bit)',
            r'\[.*?\]', r'\(.*?\)', r'(UNCUT|EXTENDED|REMASTERED)',
            r'(ESub|ESubs)', r'(Dual Audio)', r'-\s*\w+$',
        ]:
            title = re.sub(p, ' ', title, flags=re.IGNORECASE)
        
        title = re.sub(r'[\.\-_]+', ' ', title)
        title = ' '.join(w.capitalize() for w in title.split()).strip()
        
        return {
            'title': title or filename,
            'year': year,
            'quality': quality,
            'audio_info': audio,
            'codec': codec,
            'genres': ['Drama']
        }


# ============ API FUNCTIONS (Called from Android) ============

def scrape_all_movies(max_per_server=400):
    """Main function - scrape all servers, return sorted by newest added"""
    try:
        scraper = BdixMovieScraper()
        movies = scraper.scrape_all_servers(max_movies_per_server=max_per_server)
        return json.dumps(movies, ensure_ascii=False)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return json.dumps({'error': str(e), 'movies': []})


def scrape_single_server(base_url, category='HINDI', language='Hindi', server_name='BDIX', max_movies=400):
    """Scrape single server"""
    try:
        scraper = BdixMovieScraper()
        movies = scraper.scrape_server(base_url, category, language, server_name, max_movies)
        # Sort by folder modified
        movies.sort(key=lambda x: x.get('folder_modified_timestamp', 0), reverse=True)
        return json.dumps(movies, ensure_ascii=False)
    except Exception as e:
        return json.dumps({'error': str(e), 'movies': []})


def search_movies(query, max_per_server=400):
    """Search movies by title"""
    try:
        scraper = BdixMovieScraper()
        all_movies = scraper.scrape_all_servers(max_movies_per_server=max_per_server)
        
        query_lower = query.lower()
        results = [m for m in all_movies 
                   if query_lower in m.get('title', '').lower() 
                   or query_lower in m.get('originalTitle', '').lower()]
        
        return json.dumps(results[:50], ensure_ascii=False)
    except Exception as e:
        return json.dumps({'error': str(e), 'results': []})


def check_server_status(base_url):
    """Check if server is reachable"""
    try:
        r = requests.head(base_url, timeout=10)
        return json.dumps({
            'url': base_url,
            'status': r.status_code,
            'reachable': r.status_code == 200
        })
    except Exception as e:
        return json.dumps({
            'url': base_url,
            'status': 0,
            'reachable': False,
            'error': str(e)
        })


# ============ TEST ============

if __name__ == '__main__':
    print("=" * 70)
    print("  BDIX Movie Scraper - Testing Sorting")
    print("=" * 70)
    
    result = scrape_all_movies(max_per_server=400)
    movies = json.loads(result)
    
    if isinstance(movies, list):
        print(f"\n✓ Found {len(movies)} movies")
        print("\n" + "=" * 70)
        print("  TOP 15 MOVIES (Should be sorted by RECENTLY ADDED, not by year)")
        print("=" * 70)
        
        for i, m in enumerate(movies[:15], 1):
            year = m.get('year', '?')
            title = m.get('title', '?')[:35]
            folder_mod = m.get('folder_modified', 'N/A')
            folder_ts = m.get('folder_modified_timestamp', 0)
            
            print(f"\n  {i:2}. [{year}] {title}")
            print(f"      📁 Folder Modified: {folder_mod}")
            print(f"      🕐 Timestamp: {folder_ts}")
        
        # Check if sorting is correct
        print("\n" + "=" * 70)
        print("  SORTING CHECK")
        print("=" * 70)
        
        timestamps = [m.get('folder_modified_timestamp', 0) for m in movies[:10]]
        is_sorted = all(timestamps[i] >= timestamps[i+1] for i in range(len(timestamps)-1))
        
        if is_sorted:
            print("  ✓ Movies are correctly sorted (newest first)")
        else:
            print("  ✗ WARNING: Movies are NOT sorted correctly!")
            print(f"    Timestamps: {timestamps}")
    else:
        print(f"Error: {movies}")
    
    print("\n" + "=" * 70)