"""
BDIX Series Scraper - Scrapes TV Series with Seasons and Episodes
Detects series folders and organizes them by season/episode
"""

import requests
from bs4 import BeautifulSoup
import json
import re
from urllib.parse import urljoin, unquote
from datetime import datetime
import hashlib
import time
import sys
import os

# ============ CONFIGURATION ============

# Series servers configuration
SERIES_SERVERS = [
    {
        "name": "Korean Dramas",
        "base_url": "http://172.16.50.14/DHAKA-FLIX-14/KOREAN%20TV%20%26%20WEB%20Series/",
        "category": "KOREAN",
        "language": "Korean",
        "enabled": True,
        "has_index_folders": False  # Direct series folders
    },
    {
        "name": "All Series",
        "base_url": "http://172.16.50.12/DHAKA-FLIX-12/TV-WEB-Series/",
        "category": "ALL_SERIES",
        "language": "English",
        "enabled": True,
        "has_index_folders": True  # Has alphabetical index folders (A-L, M-R, S-Z)
    }
]

VIDEO_EXTENSIONS = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.webm', '.m4v', '.ts']
IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp']
POSTER_FILENAMES = ['poster.jpg', 'cover.jpg', 'folder.jpg', 'thumb.jpg',
                    'a_AL_.jpg', 'a11.jpg', 'a20_.jpg', 'a.jpg', 'a_1_.jpg',
                    'season_poster.jpg', 'series_poster.jpg']

REQUEST_TIMEOUT = 15
MAX_DEPTH = 3
VERBOSE = True

def log(msg):
    """Log message if verbose mode is on"""
    if VERBOSE:
        print(msg)
        sys.stdout.flush()

# ============ MAIN SCRAPER CLASS ============

class BdixSeriesScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        })
        self.series_found = 0

    def scrape_all_servers(self, max_series_per_server=250):
        """Scrape all servers and return series sorted by folder modified date"""
        all_series = []

        log(f"[INFO] Starting series scrape of {len(SERIES_SERVERS)} servers...")

        for i, server in enumerate(SERIES_SERVERS, 1):
            if not server.get('enabled', True):
                continue

            log(f"\n[{i}/{len(SERIES_SERVERS)}] {server['name']}")

            try:
                series_list = self.scrape_server(
                    base_url=server['base_url'],
                    category=server['category'],
                    language=server['language'],
                    server_name=server['name'],
                    max_series=max_series_per_server,
                    has_index_folders=server.get('has_index_folders', False)
                )
                all_series.extend(series_list)
                log(f"[✓] Found {len(series_list)} series")
            except Exception as e:
                log(f"[✗] Error: {e}")

        # Sort by folder modified timestamp (newest first)
        log(f"\n[INFO] Sorting {len(all_series)} series by folder modified date...")

        all_series.sort(
            key=lambda x: x.get('folder_modified_timestamp', 0),
            reverse=True
        )

        log(f"\n[✓] Total: {len(all_series)} series (sorted by newest added)")

        return all_series

    def scrape_server(self, base_url, category, language, server_name, max_series=250, has_index_folders=False):
        """Scrape a single server for series"""
        series_list = []

        try:
            if has_index_folders:
                # For servers with index folders (like All Series), first get index folders
                entries = self.get_directory_entries(base_url)
                index_folders = [e for e in entries if e['is_directory']]

                log(f"  → Found {len(index_folders)} index folders")

                # Collect all series from all index folders
                all_series_folders = []
                for idx_folder in index_folders:
                    idx_entries = self.get_directory_entries(idx_folder['url'])
                    series_folders = [e for e in idx_entries if e['is_directory']]
                    all_series_folders.extend(series_folders)

                directories = all_series_folders
            else:
                # Direct series folders (like Korean Dramas)
                entries = self.get_directory_entries(base_url)
                directories = [e for e in entries if e['is_directory']]

            # Sort by modified date (newest series first)
            directories.sort(key=lambda x: x.get('last_modified_timestamp', 0), reverse=True)

            log(f"  → {len(directories)} series folders found")

            # Process each series folder
            for idx, series_folder in enumerate(directories):
                if len(series_list) >= max_series:
                    log(f"  → Reached max {max_series} series")
                    break

                folder_name = series_folder['name']
                folder_url = series_folder['url']
                folder_modified = series_folder.get('last_modified', '')
                folder_modified_ts = series_folder.get('last_modified_timestamp', 0)

                # Progress
                pct = ((idx + 1) / len(directories)) * 100
                print(f"\r  Processing: [{idx+1}/{len(directories)}] {pct:.0f}% - {folder_name}", end="")
                sys.stdout.flush()

                # Scrape this series
                series = self._scrape_series_folder(
                    folder_url=folder_url,
                    folder_name=folder_name,
                    category=category,
                    language=language,
                    server_name=server_name,
                    folder_modified=folder_modified,
                    folder_modified_ts=folder_modified_ts
                )

                if series:
                    series_list.append(series)

            print()  # New line after progress

        except Exception as e:
            log(f"  [ERROR] {e}")
            import traceback
            traceback.print_exc()

        return series_list

    def _scrape_series_folder(self, folder_url, folder_name, category, language, server_name,
                             folder_modified, folder_modified_ts):
        """Scrape a series folder to find seasons and episodes"""

        try:
            entries = self.get_directory_entries(folder_url)

            # Check if this has season folders (Season 1, Season 2, etc.)
            season_folders = []
            standalone_videos = []

            for entry in entries:
                if entry['is_directory']:
                    season_folders.append(entry)
                elif self._is_video_file(entry['name']):
                    standalone_videos.append(entry)

            # Parse series name
            series_info = self._parse_series_name(folder_name)
            series_id = hashlib.md5(folder_url.encode()).hexdigest()[:12]

            # Detect category from folder name (if category is ALL_SERIES or ALL)
            if category in ['ALL_SERIES', 'ALL']:
                detected_category = self._detect_category_from_name(folder_name, default_category='ENGLISH')
            else:
                detected_category = category

            # Determine series structure
            if season_folders:
                # Has season folders - scrape each season
                seasons = self._scrape_seasons(
                    season_folders,
                    folder_url,
                    category,
                    language,
                    server_name,
                    series_info
                )
            elif standalone_videos:
                # Direct videos in series folder - single season
                seasons = [self._create_single_season(
                    standalone_videos,
                    folder_url,
                    series_info,
                    category,
                    language,
                    server_name
                )]
            else:
                # No videos found
                return None

            # Get series poster
            poster = self._find_poster(entries, folder_url) or series_info.get('poster', '')

            # Count total episodes
            total_episodes = sum(len(season.get('episodes', [])) for season in seasons)

            # Create series object
            series = {
                'id': f"series_{series_id}",
                'title': series_info['title'],
                'originalTitle': folder_name,
                'year': series_info.get('year', ''),
                'rating': '',
                'quality': series_info.get('quality', 'HD'),
                'poster': poster,
                'backdrop': '',
                'description': series_info.get('description', ''),
                'genres': series_info.get('genres', ['Drama']),
                'cast': [],
                'director': '',
                'language': language,
                'seasons': seasons,
                'subtitles': [],
                'source': 'BDIX',
                'serverName': server_name,
                'category': detected_category,
                'folderUrl': folder_url,
                'lastModified': folder_modified,
                'lastModifiedTimestamp': folder_modified_ts,
                'folderModified': folder_modified,
                'folderModifiedTimestamp': folder_modified_ts,
                'addedDate': int(time.time() * 1000),
                'isFavorite': False,
                'totalEpisodes': total_episodes,
                'status': 'Completed'
            }

            return series

        except Exception as e:
            log(f"    [ERROR] Series folder: {e}")
            return None

    def _scrape_seasons(self, season_folders, series_url, category, language, server_name, series_info):
        """Scrape all season folders"""
        seasons = []

        # Sort season folders by season number
        season_folders.sort(key=lambda x: self._extract_season_number(x['name']))

        for season_folder in season_folders:
            season_number = self._extract_season_number(season_folder['name'])
            if season_number == 0:
                continue

            season_url = season_folder['url']

            # Get episodes in this season
            entries = self.get_directory_entries(season_url)

            # Filter videos
            episode_entries = [e for e in entries if not e['is_directory'] and self._is_video_file(e['name'])]

            if not episode_entries:
                continue

            # Create episodes
            episodes = []
            for ep_entry in episode_entries:
                episode = self._create_episode(
                    ep_entry,
                    season_url,
                    season_number,
                    category,
                    language,
                    server_name
                )
                if episode:
                    episodes.append(episode)

            # Sort episodes by episode number
            episodes.sort(key=lambda x: x.get('episodeNumber', 0))

            # Get season poster
            season_entries = self.get_directory_entries(season_url)
            season_poster = self._find_poster(season_entries, season_url)

            # Create season
            season = {
                'seasonNumber': season_number,
                'title': f"Season {season_number}",
                'description': '',
                'poster': season_poster or '',
                'year': series_info.get('year', ''),
                'episodeCount': len(episodes),
                'episodes': episodes,
                'folderUrl': season_url
            }

            seasons.append(season)

        return seasons

    def _create_single_season(self, video_entries, series_url, series_info, category, language, server_name):
        """Create a single season from standalone videos"""
        episodes = []

        for video_entry in video_entries:
            episode = self._create_episode(
                video_entry,
                series_url,
                1,  # Single season
                category,
                language,
                server_name
            )
            if episode:
                episodes.append(episode)

        # Sort episodes by name (should extract episode number)
        episodes.sort(key=lambda x: x.get('episodeNumber', 0))

        season = {
            'seasonNumber': 1,
            'title': 'Season 1',
            'description': series_info.get('description', ''),
            'poster': '',
            'year': series_info.get('year', ''),
            'episodeCount': len(episodes),
            'episodes': episodes,
            'folderUrl': series_url
        }

        return season

    def _create_episode(self, video_entry, parent_url, season_number, category, language, server_name):
        """Create an episode from a video file"""
        try:
            file_name = video_entry['name']
            file_url = video_entry['url']

            # Parse episode name
            ep_info = self._parse_episode_name(file_name)
            episode_number = ep_info.get('episodeNumber', 0)

            # Parse quality
            quality = self._extract_quality(file_name)

            episode_id = hashlib.md5(file_url.encode()).hexdigest()[:12]

            episode = {
                'id': f"ep_{episode_id}",
                'episodeNumber': episode_number,
                'title': ep_info.get('title', ''),
                'description': '',
                'duration': '',
                'quality': quality,
                'poster': '',
                'streamUrls': [{
                    'url': file_url,
                    'quality': quality,
                    'server': server_name,
                    'fileName': file_name,
                    'isWorking': True
                }],
                'subtitles': [],
                'airDate': '',
                'folderUrl': parent_url,
                'lastModified': video_entry.get('last_modified', ''),
                'watchProgress': 0.0,
                'lastWatched': 0
            }

            return episode

        except Exception as e:
            return None

    def get_directory_entries(self, url):
        """Fetch and parse directory listing"""
        entries = []

        try:
            response = self.session.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()

            soup = BeautifulSoup(response.text, 'html.parser')

            # Try pre tag first
            pre = soup.find('pre')
            if pre:
                entries = self._parse_pre_listing(pre, url)

            # Fallback to table
            if not entries:
                table = soup.find('table')
                if table:
                    entries = self._parse_table_listing(table, url)

            # Generic fallback
            if not entries:
                entries = self._parse_generic_listing(soup, url)

        except Exception as e:
            pass

        return entries

    def _parse_pre_listing(self, pre, base_url):
        """Parse pre-tag directory listing"""
        entries = []

        # Get all text content
        text = pre.get_text()
        lines = text.split('\n')

        for link in pre.find_all('a', href=True):
            href = link.get('href', '')
            name = unquote(link.text.strip())

            if href in ['../', '../', '/', '?'] or name in ['..', '../', 'Parent Directory']:
                continue

            full_url = urljoin(base_url, href)
            is_directory = href.endswith('/')

            # Extract modification date from the line containing this link
            mod_date, mod_timestamp = self._extract_date_from_text(text, name)

            entries.append({
                'name': name,
                'url': full_url,
                'is_directory': is_directory,
                'last_modified': mod_date,
                'last_modified_timestamp': mod_timestamp
            })

        return entries

    def _parse_table_listing(self, table, base_url):
        """Parse table directory listing"""
        entries = []

        for row in table.find_all('tr')[1:]:  # Skip header row
            cells = row.find_all('td')
            if len(cells) < 2:
                continue

            name_cell = cells[1].find('a')
            if not name_cell:
                continue

            name = unquote(name_cell.text.strip())
            href = name_cell.get('href', '')

            if href in ['../', '../', '/', '?'] or name in ['..', '../', 'Parent Directory']:
                continue

            full_url = urljoin(base_url, href)
            is_directory = href.endswith('/')

            # Extract modification date from the last cells
            mod_date, mod_timestamp = self._extract_date_from_cells(cells)

            entries.append({
                'name': name,
                'url': full_url,
                'is_directory': is_directory,
                'last_modified': mod_date,
                'last_modified_timestamp': mod_timestamp
            })

        return entries

    def _parse_generic_listing(self, soup, base_url):
        """Generic directory listing parser"""
        entries = []
        text = soup.get_text()

        for link in soup.find_all('a', href=True):
            href = link.get('href', '')
            name = unquote(link.text.strip())

            if href in ['../', '../', '/', '?'] or name in ['..', '../', 'Parent Directory']:
                continue

            full_url = urljoin(base_url, href)
            is_directory = href.endswith('/')

            # Extract modification date
            mod_date, mod_timestamp = self._extract_date_from_text(text, name)

            entries.append({
                'name': name,
                'url': full_url,
                'is_directory': is_directory,
                'last_modified': mod_date,
                'last_modified_timestamp': mod_timestamp
            })

        return entries

    def _extract_date_from_text(self, text, name):
        """Extract modification date from directory listing text"""
        try:
            # Find the line containing the folder/file name
            lines = text.split('\n')
            for line in lines:
                if name in line:
                    # Try to extract date from this line
                    date_str, timestamp = self._parse_date_string(line)
                    if timestamp > 0:
                        return date_str, timestamp
        except Exception as e:
            pass

        # Fallback: use current time
        now = int(time.time())
        return datetime.fromtimestamp(now).strftime('%Y-%m-%d %H:%M'), now

    def _extract_date_from_cells(self, cells):
        """Extract modification date from table cells"""
        try:
            # Typically date is in the last or second-to-last cell
            for cell in cells[-3:]:  # Check last 3 cells
                cell_text = cell.get_text().strip()
                if cell_text:
                    date_str, timestamp = self._parse_date_string(cell_text)
                    if timestamp > 0:
                        return date_str, timestamp
        except Exception as e:
            pass

        # Fallback: use current time
        now = int(time.time())
        return datetime.fromtimestamp(now).strftime('%Y-%m-%d %H:%M'), now

    def _parse_date_string(self, text):
        """Parse date string from various formats"""
        if not text:
            return "", 0

        # Common Apache directory listing date formats:
        # 1. "Jan 15 10:30" or "Jan 15 2024"
        # 2. "2024-01-15 10:30"
        # 3. "15-Jan-2024"
        # 4. "15.01.2024"
        
        # Try different patterns
        patterns = [
            (r'(\d{4})-(\d{2})-(\d{2})', '%Y-%m-%d'),  # 2024-01-15
            (r'(\d{2})-(\d{2})-(\d{4})', '%d-%m-%Y'),  # 15-01-2024
            (r'(\d{2})\.(\d{2})\.(\d{4})', '%d.%m.%Y'),  # 15.01.2024
            (r'(\d{2})\.(\d{2})\.(\d{2})', '%d.%m.%y'),  # 15.01.24
        ]

        for pattern, fmt in patterns:
            match = re.search(pattern, text)
            if match:
                try:
                    date_str = f"{match.group(1)}-{match.group(2)}-{match.group(3)}"
                    # Reformat to YYYY-MM-DD
                    if fmt == '%d-%m-%Y' or fmt == '%d.%m.%Y':
                        date_str = f"{match.group(3)}-{match.group(2)}-{match.group(1)}"
                    elif fmt == '%d.%m.%y':
                        year = int(match.group(3))
                        year += 2000 if year < 50 else 1900
                        date_str = f"{year}-{match.group(2)}-{match.group(1)}"
                    
                    # Parse to timestamp
                    dt = datetime.strptime(date_str, '%Y-%m-%d')
                    return date_str, int(dt.timestamp())
                except:
                    continue

        # Try "Jan 15 2024" or "Jan 15 10:30" format
        try:
            # Check if line contains a date
            date_match = re.search(r'([A-Za-z]{3})\s+(\d{1,2})\s+(\d{4}|\d{2}:\d{2})', text)
            if date_match:
                month_str, day, year_or_time = date_match.groups()
                
                months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                         'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
                if month_str in months:
                    month = months.index(month_str) + 1
                    
                    if ':' in year_or_time:
                        # Format: "Jan 15 10:30" - assume current year
                        year = datetime.now().year
                        time_part = year_or_time
                        date_str = f"{year}-{month:02d}-{int(day):02d} {time_part}"
                    else:
                        # Format: "Jan 15 2024"
                        year = int(year_or_time)
                        date_str = f"{year}-{month:02d}-{int(day):02d} 12:00"
                    
                    dt = datetime.strptime(date_str, '%Y-%m-%d %H:%M')
                    return date_str, int(dt.timestamp())
        except:
            pass

        return "", 0

    def _find_poster(self, entries, base_url):
        """Find poster image in entries"""
        for entry in entries:
            if entry['is_directory']:
                continue

            name = entry['name'].lower()
            if any(name == p.lower() or name.startswith(p.split('.')[0].lower()) for p in POSTER_FILENAMES):
                return entry['url']

            # Any image file
            if any(name.endswith(ext) for ext in IMAGE_EXTENSIONS):
                return entry['url']

        return ''

    def _parse_series_name(self, name):
        """Parse series name and extract metadata"""
        info = {
            'title': name,
            'year': '',
            'quality': '',
            'genres': ['Drama'],
            'description': '',
            'poster': ''
        }

        # Extract year
        year_match = re.search(r'\((\d{4})\)|\[*(\d{4})\]*|\s(19\d{2}|20\d{2})\s', name)
        if year_match:
            info['year'] = year_match.group(1) or year_match.group(2)

        # Extract quality
        quality_match = re.search(r'(4K|1080p|720p|480p|2160p|BluRay|WEB-DL|WEBRip|HDTV)', name, re.IGNORECASE)
        if quality_match:
            info['quality'] = quality_match.group(1).upper()

        # Clean title
        info['title'] = re.sub(r'\s*[\[\(].*?[\]\)]\s*', ' ', name)
        info['title'] = re.sub(r'\s+(1080p|720p|480p|4K|2160p|BluRay|WEB-DL|WEBRip|HDTV)\s*', '', info['title'], flags=re.IGNORECASE)
        info['title'] = info['title'].strip()

        return info

    def _parse_episode_name(self, filename):
        """Parse episode file name and extract clean title with audio info"""
        info = {
            'episodeNumber': 0,
            'title': ''
        }

        # Try to extract episode number
        # Common patterns: E01, E1, Episode 1, Ep.1, S01E01, etc.
        ep_patterns = [
            r'[Ee][Pp]?\.?(\d+)',  # E01, Ep.01, E1
            r'[Ee]pisode\s*(\d+)',  # Episode 1
            r'S\d{1,2}[Ee](\d+)',  # S01E01
            r'(\d+)\.mkv',  # 01.mkv
            r'(\d+)\.mp4',  # 01.mp4
        ]

        for pattern in ep_patterns:
            match = re.search(pattern, filename, re.IGNORECASE)
            if match:
                info['episodeNumber'] = int(match.group(1))
                break

        # Extract audio information first
        audio_info = self._extract_audio_info(filename)

        # Clean the title - remove extension
        title = re.sub(r'\.mkv$|\.mp4$|\.avi$|\.mkv\.hevc$', '', filename, flags=re.IGNORECASE)

        # Remove episode number patterns
        title = re.sub(r'^\d+[-_.\s]*', '', title)  # Remove leading numbers
        title = re.sub(r'[Ss]\d{1,2}[Ee]\d{1,2}[-_.\s]*', '', title)  # Remove S01E01
        title = re.sub(r'[Ee][Pp]?\.?\d+[-_.\s]*', '', title)  # Remove E01

        # Remove quality tags (various formats)
        quality_patterns = [
            r'\b\d{3,4}p\b',  # 720p, 1080p, 2160p
            r'\b4K\b',  # 4K
            r'\bBluRay\b',
            r'\bBDRip\b',
            r'\bBRRip\b',
            r'\bWEB-DL\b',
            r'\bWEBRip\b',
            r'\bWEB\b',
            r'\bHDTV\b',
            r'\bHDTVRip\b',
            r'\bHDTS\b',
            r'\bCAMRip\b',
            r'\bDVDRip\b',
            r'\bDvDRip\b',
            r'\bDVDSCR\b',
            r'\bHC\.HDRip\b',
            r'\bHC\.WEBRip\b',
            r'\bHDRip\b',
            r'\bXviD\b',
            r'\bx264\b',
            r'\bx265\b',
            r'\bHEVC\b',
            r'\b10bit\b',
            r'\b8bit\b',
        ]
        for pattern in quality_patterns:
            title = re.sub(pattern, '', title, flags=re.IGNORECASE)

        # Remove encoder/group tags
        encoder_patterns = [
            r'\[-?\w+\]',  # [MsMod], [-MsMod]
            r'\[\w+\]',  # [ESubs], [MSubs]
            r'~\w+',  # ~MsMod
            r'-\w+$',  # -MsMod at end
            r'_\w+$',  # _MsMod at end
            r'\.\w+$',  # .MsMod at end (but not file extension)
        ]
        for pattern in encoder_patterns:
            title = re.sub(pattern, '', title)

        # Remove streaming platform tags (keep for audio_info, not title)
        platform_patterns = [
            r'\bNF\b',  # Netflix
            r'\bAMZN\b',  # Amazon
            r'\bAMZNW\b',  # Amazon Web
            r'\bDSNP\b',  # Disney+
            r'\bHBO\b',  # HBO
            r'\bHULU\b',  # Hulu
            r'\bAPPLE\b',  # Apple TV+
            r'\bATVP\b',  # Apple TV+
            r'\bIMAX\b',  # IMAX
        ]
        for pattern in platform_patterns:
            title = re.sub(pattern, '', title)

        # Remove technical tags
        tech_patterns = [
            r'\bAAC\b',
            r'\bAAC2\.0\b',
            r'\bAAC5\.1\b',
            r'\bAC3\b',
            r'\bDTS\b',
            r'\bDDP5\.1\b',
            r'\bDD5\.1\b',
            r'\bEAC3\b',
            r'\bE-AC-3\b',
            r'\bFLAC\b',
            r'\bMP3\b',
            r'\bOpus\b',
            r'\bPCM\b',
            r'\bTrueHD\b',
            r'\bAtmos\b',
            r'\bMSubs\b',
            r'\bESubs\b',
            r'\bHardSub\b',
            r'\bHardcoded\b',
            r'\bSoftSub\b',
            r'\bSubs\b',
        ]
        for pattern in tech_patterns:
            title = re.sub(pattern, '', title)

        # Remove brackets and parentheses content
        title = re.sub(r'\[.*?\]', '', title)
        title = re.sub(r'\(.*?\)', '', title)

        # Remove country/language codes (keep for audio_info)
        lang_patterns = [
            r'\bKOR\b',  # Korean
            r'\bENG\b',  # English
            r'\bJPN\b',  # Japanese
            r'\bHIN\b',  # Hindi
            r'\bBEN\b',  # Bengali
            r'\bARA\b',  # Arabic
            r'\bCHI\b',  # Chinese
            r'\bSPA\b',  # Spanish
            r'\bFRE\b',  # French
            r'\bGER\b',  # German
            r'\bTUR\b',  # Turkish
            r'\bTHA\b',  # Thai
        ]
        for pattern in lang_patterns:
            title = re.sub(pattern, '', title)

        # Clean up the title
        title = re.sub(r'[-_.]+', ' ', title)  # Replace separators with space
        title = re.sub(r'\s+', ' ', title)  # Remove multiple spaces
        title = title.strip()

        # Add audio info if present
        if audio_info:
            title = f"{title} ({audio_info})"

        # Use title if it's meaningful
        if title and len(title) > 2:
            info['title'] = title
        else:
            # Fallback to "Episode X" if no title found
            if info['episodeNumber'] > 0:
                info['title'] = f"Episode {info['episodeNumber']}"

        return info

    def _extract_audio_info(self, filename):
        """Extract audio/dubbing information from filename"""
        filename_upper = filename.upper()

        # Check for dual audio
        if re.search(r'\bDUAL\s*AUDIO\b', filename_upper):
            return "Dual Audio"

        # Check for specific dub types
        dub_patterns = [
            (r'\bHINDI\s*DUB\b', 'Hindi Dub'),
            (r'\bHINDI\s*DUBBED\b', 'Hindi Dubbed'),
            (r'\bENG\s*DUB\b', 'English Dub'),
            (r'\bENGLISH\s*DUB\b', 'English Dubbed'),
            (r'\bBANGLA\s*DUB\b', 'Bangla Dub'),
            (r'\bBENGALI\s*DUB\b', 'Bengali Dub'),
            (r'\bTAMIL\s*DUB\b', 'Tamil Dub'),
            (r'\bTELUGU\s*DUB\b', 'Telugu Dub'),
            (r'\bARABIC\s*DUB\b', 'Arabic Dub'),
            (r'\bJAPANESE\s*DUB\b', 'Japanese Dub'),
            (r'\bDUBBED\b', 'Dubbed'),
            (r'\bDUB\b', 'Dub'),
        ]

        for pattern, label in dub_patterns:
            if re.search(pattern, filename_upper):
                return label

        # Check for multi-language (multiple language codes)
        lang_codes = re.findall(r'\b(KOR|ENG|JPN|HIN|BEN|ARA|CHI|SPA|FRE|GER|TUR|THA)\b', filename_upper)
        if len(lang_codes) >= 2:
            return f"Multi-Audio ({', '.join(sorted(set(lang_codes)))})"

        return ""

    def _extract_season_number(self, folder_name):
        """Extract season number from folder name"""
        # Patterns: Season 1, S01, Season 01, Series 1
        patterns = [
            r'[Ss]eason\s*(\d+)',
            r'[Ss](\d{1,2})',
            r'Series\s*(\d+)',
        ]

        for pattern in patterns:
            match = re.search(pattern, folder_name, re.IGNORECASE)
            if match:
                return int(match.group(1))

        return 0

    def _extract_quality(self, filename):
        """Extract quality from filename"""
        quality_patterns = [
            r'4K|2160p',
            r'1080p|FHD',
            r'720p|HD',
            r'480p|SD',
        ]

        filename_lower = filename.lower()
        for pattern in quality_patterns:
            if re.search(pattern, filename_lower):
                match = re.search(pattern, filename_lower)
                if match:
                    qual = match.group(0).upper()
                    if qual == '2160P':
                        return '4K'
                    return qual

        return 'HD'

    def _detect_category_from_name(self, name, default_category="ENGLISH"):
        """Detect series category from folder name"""
        name_lower = name.lower()

        # Category detection patterns (ordered by priority)
        category_patterns = {
            'ANIME': [
                r'\banime\b', r'\bjapan\b', r'japanese',
                r'\bnaruto\b', r'\bone piece\b', r'\bdemon slayer\b',
                r'\bdragon ball\b', r'\battack on titan\b',
                r'\bmy hero academia\b', r'\bjujutsu\b',
                r'\btokyo ghoul\b', r'\bdeath note\b',
                r'\bspy x family\b', r'\bchainsaw man\b'
            ],
            'KOREAN': [
                r'\bkorean\b', r'\bk\drama\b', r'\bkdrama\b', r'\bkorea\b',
                r'\bsquid game\b', r'\bvincenzo\b', r'\bcrash landing\b',
                r'\bgoblin\b', r'\bdescendants\b', r'\bmy love\b'
            ],
            'HINDI': [
                r'\bhindi\b', r'\bindian\b', r'\bbollywood\b', r'\bindia\b',
                r'\bhindi dub\b', r'\bvikram\b', r'\brrr\b',
                r'\bbahubali\b', r'\bkabir singh\b'
            ],
            'BENGALI': [
                r'\bbengali\b', r'\bbangla\b', r'\bbangladesh\b',
                r'\bdhaka\b', r'\bkolkata\b'
            ],
            'TURKISH': [
                r'\bturkish\b', r'\bturkey\b',
                r'\berkenci\b', r'\bkurulus\b', r'\bdirilis\b'
            ],
            'THAI': [
                r'\bthai\b', r'\bthailand\b'
            ],
            'WEB_SERIES': [
                r'\bweb.?series\b', r'\bwebseries\b',
                r'\bnetflix\b', r'\bamazon prime\b', r'\bamazon\b',
                r'\bdisney\+\b', r'\bdisney\b', r'\bhbo\b',
                r'\bhulu\b', r'\bapple tv\b', r'\bparamount\b'
            ],
            'ENGLISH': [
                r'\benglish\b', r'\busa\b', r'\bamerica\b', r'\bamerican\b',
                r'\buk\b', r'\bbritish\b', r'\bbritain\b',
                r'\bcana\b', r'\bcanadian\b', r'\baustralia\b',
                r'\bhollywood\b'
            ]
        }

        # Check each category
        for category, patterns in category_patterns.items():
            for pattern in patterns:
                if re.search(pattern, name_lower):
                    return category

        # Return default category if no match found
        return default_category

    def _is_video_file(self, filename):
        """Check if file is a video"""
        return any(filename.lower().endswith(ext) for ext in VIDEO_EXTENSIONS)

    def _is_image_file(self, filename):
        """Check if file is an image"""
        return any(filename.lower().endswith(ext) for ext in IMAGE_EXTENSIONS)


# ============ PUBLIC FUNCTIONS ============

def scrape_all_series(max_series_per_server=200):
    """Scrape all configured series servers"""
    scraper = BdixSeriesScraper()
    return scraper.scrape_all_servers(max_series_per_server)

def scrape_single_server(base_url, category, language, server_name, max_series=200, has_index_folders=False):
    """Scrape a single series server"""
    scraper = BdixSeriesScraper()
    return scraper.scrape_server(base_url, category, language, server_name, max_series, has_index_folders)

def search_series(query, max_results=50):
    """Search series by title (basic implementation)"""
    all_series = scrape_all_series(max_series_per_server=max_results)
    query_lower = query.lower()

    # Filter by query
    filtered = [
        s for s in all_series
        if query_lower in s['title'].lower() or query_lower in s.get('originalTitle', '').lower()
    ]

    return filtered[:max_results]

# For direct Python execution
if __name__ == "__main__":
    print("BDIX Series Scraper")
    print("=" * 50)

    # Scrape all series
    series_list = scrape_all_series(max_series_per_server=50)

    print(f"\nFound {len(series_list)} series:")
    for series in series_list[:10]:
        print(f"  • {series['title']} ({series['year']}) - {series['totalEpisodes']} episodes in {len(series['seasons'])} seasons")

    # Save to JSON
    output = {
        'count': len(series_list),
        'series': series_list
    }

    # Use current directory for cross-platform compatibility
    output_file = os.path.join(os.getcwd(), 'scraped_series.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Saved to: {output_file}")
