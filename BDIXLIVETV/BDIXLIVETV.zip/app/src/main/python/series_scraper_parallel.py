"""
BDIX Series Scraper - Multi-Threaded Parallel Version
Scrapes TV Series with Seasons and Episodes using multiple workers for faster performance
"""

import requests
from bs4 import BeautifulSoup
import json
import re
from urllib.parse import urljoin, unquote
from datetime import datetime
import hashlib
import time
import sys
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
import queue

# ============ CONFIGURATION ============

# Series servers configuration
SERIES_SERVERS = [
    {
        "name": "Korean Dramas",
        "base_url": "http://172.16.50.14/DHAKA-FLIX-14/KOREAN%20TV%20%26%20WEB%20Series/",
        "category": "KOREAN",
        "language": "Korean",
        "enabled": True,
        "has_index_folders": False  # Direct series folders
    },
    {
        "name": "All Series",
        "base_url": "http://172.16.50.12/DHAKA-FLIX-12/TV-WEB-Series/",
        "category": "ALL_SERIES",
        "language": "English",
        "enabled": True,
        "has_index_folders": True  # Has alphabetical index folders (A-L, M-R, S-Z)
    }
]

VIDEO_EXTENSIONS = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.webm', '.m4v', '.ts']
IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp']
POSTER_FILENAMES = ['poster.jpg', 'cover.jpg', 'folder.jpg', 'thumb.jpg',
                    'a_AL_.jpg', 'a11.jpg', 'a20_.jpg', 'a.jpg', 'a_1_.jpg',
                    'season_poster.jpg', 'series_poster.jpg']

REQUEST_TIMEOUT = 15
MAX_DEPTH = 3
VERBOSE = True

# Parallel processing configuration
MAX_WORKERS_SERVERS = 3        # Max workers for scraping servers in parallel
MAX_WORKERS_SERIES = 10        # Max workers for scraping series folders in parallel
MAX_WORKERS_SEASONS = 15       # Max workers for scraping seasons in parallel
ENABLE_PARALLEL_SERVERS = True # Enable parallel server scraping
ENABLE_PARALLEL_SERIES = True  # Enable parallel series folder scraping
ENABLE_PARALLEL_SEASONS = True # Enable parallel season scraping

# Thread-safe logging
print_lock = Lock()

def log(msg):
    """Thread-safe log message"""
    if VERBOSE:
        with print_lock:
            print(msg)
            sys.stdout.flush()

# ============ MAIN SCRAPER CLASS ============

class BdixSeriesScraperParallel:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        })
        self.series_found = 0
        self.progress_queue = queue.Queue()

    def scrape_all_servers(self, max_series_per_server=200):
        """Scrape all servers in parallel and return series sorted by folder modified date"""
        all_series = []

        log(f"[INFO] Starting PARALLEL series scrape of {len(SERIES_SERVERS)} servers...")
        log(f"[CONFIG] Server workers: {MAX_WORKERS_SERVERS if ENABLE_PARALLEL_SERVERS else 1}")
        log(f"[CONFIG] Series workers: {MAX_WORKERS_SERIES if ENABLE_PARALLEL_SERIES else 1}")
        log(f"[CONFIG] Season workers: {MAX_WORKERS_SEASONS if ENABLE_PARALLEL_SEASONS else 1}")

        if ENABLE_PARALLEL_SERVERS:
            # Scrape servers in parallel
            with ThreadPoolExecutor(max_workers=MAX_WORKERS_SERVERS) as executor:
                future_to_server = {}

                for i, server in enumerate(SERIES_SERVERS, 1):
                    if not server.get('enabled', True):
                        continue

                    log(f"[{i}/{len(SERIES_SERVERS)}] Queuing: {server['name']}")

                    future = executor.submit(
                        self.scrape_server,
                        base_url=server['base_url'],
                        category=server['category'],
                        language=server['language'],
                        server_name=server['name'],
                        max_series=max_series_per_server,
                        has_index_folders=server.get('has_index_folders', False)
                    )
                    future_to_server[future] = server

                # Collect results as they complete
                for future in as_completed(future_to_server):
                    server = future_to_server[future]
                    try:
                        series_list = future.result()
                        all_series.extend(series_list)
                        log(f"[✓] {server['name']}: {len(series_list)} series")
                    except Exception as e:
                        log(f"[✗] {server['name']}: Error - {e}")
        else:
            # Sequential server scraping (original behavior)
            for i, server in enumerate(SERIES_SERVERS, 1):
                if not server.get('enabled', True):
                    continue

                log(f"\n[{i}/{len(SERIES_SERVERS)}] {server['name']}")

                try:
                    series_list = self.scrape_server(
                        base_url=server['base_url'],
                        category=server['category'],
                        language=server['language'],
                        server_name=server['name'],
                        max_series=max_series_per_server,
                        has_index_folders=server.get('has_index_folders', False)
                    )
                    all_series.extend(series_list)
                    log(f"[✓] Found {len(series_list)} series")
                except Exception as e:
                    log(f"[✗] Error: {e}")

        # Sort by folder modified timestamp (newest first)
        log(f"\n[INFO] Sorting {len(all_series)} series by folder modified date...")

        all_series.sort(
            key=lambda x: x.get('folder_modified_timestamp', 0),
            reverse=True
        )

        log(f"\n[✓] Total: {len(all_series)} series (sorted by newest added)")

        return all_series

    def scrape_server(self, base_url, category, language, server_name, max_series=200, has_index_folders=False):
        """Scrape a single server for series"""
        series_list = []

        try:
            if has_index_folders:
                # For servers with index folders, first get index folders
                entries = self.get_directory_entries(base_url)
                index_folders = [e for e in entries if e['is_directory']]

                log(f"  → Found {len(index_folders)} index folders")

                # Collect all series from all index folders
                all_series_folders = []
                for idx_folder in index_folders:
                    idx_entries = self.get_directory_entries(idx_folder['url'])
                    series_folders = [e for e in idx_entries if e['is_directory']]
                    all_series_folders.extend(series_folders)

                directories = all_series_folders
            else:
                # Direct series folders
                entries = self.get_directory_entries(base_url)
                directories = [e for e in entries if e['is_directory']]

            # Sort by modified date (newest series first)
            directories.sort(key=lambda x: x.get('last_modified_timestamp', 0), reverse=True)

            log(f"  → {len(directories)} series folders found")

            # Process each series folder
            if ENABLE_PARALLEL_SERIES and len(directories) > 3:
                # Parallel processing for series folders
                series_list = self._process_series_folders_parallel(
                    directories, category, language, server_name, max_series
                )
            else:
                # Sequential processing (for small batches)
                series_list = self._process_series_folders_sequential(
                    directories, category, language, server_name, max_series
                )

        except Exception as e:
            log(f"  [ERROR] {e}")
            import traceback
            traceback.print_exc()

        return series_list

    def _process_series_folders_parallel(self, directories, category, language, server_name, max_series):
        """Process series folders in parallel"""
        series_list = []
        completed = 0

        with ThreadPoolExecutor(max_workers=MAX_WORKERS_SERIES) as executor:
            future_to_folder = {}

            for series_folder in directories[:max_series * 2]:  # Limit to reasonable number
                if len(series_list) >= max_series:
                    break

                future = executor.submit(
                    self._scrape_series_folder,
                    folder_url=series_folder['url'],
                    folder_name=series_folder['name'],
                    category=category,
                    language=language,
                    server_name=server_name,
                    folder_modified=series_folder.get('last_modified', ''),
                    folder_modified_ts=series_folder.get('last_modified_timestamp', 0)
                )
                future_to_folder[future] = series_folder

            # Collect results
            for future in as_completed(future_to_folder):
                completed += 1
                folder = future_to_folder[future]

                # Progress
                pct = (completed / len(future_to_folder)) * 100
                with print_lock:
                    print(f"\r  Processing: [{completed}/{len(future_to_folder)}] {pct:.0f}% - {folder['name']}", end="")
                    sys.stdout.flush()

                try:
                    series = future.result()
                    if series and len(series_list) < max_series:
                        series_list.append(series)
                except Exception as e:
                    log(f"\n    [ERROR] {folder['name']}: {e}")

        with print_lock:
            print()  # New line after progress

        return series_list

    def _process_series_folders_sequential(self, directories, category, language, server_name, max_series):
        """Process series folders sequentially (original behavior)"""
        series_list = []

        for idx, series_folder in enumerate(directories):
            if len(series_list) >= max_series:
                log(f"  → Reached max {max_series} series")
                break

            folder_name = series_folder['name']
            folder_url = series_folder['url']
            folder_modified = series_folder.get('last_modified', '')
            folder_modified_ts = series_folder.get('last_modified_timestamp', 0)

            # Progress
            pct = ((idx + 1) / len(directories)) * 100
            print(f"\r  Processing: [{idx+1}/{len(directories)}] {pct:.0f}% - {folder_name}", end="")
            sys.stdout.flush()

            # Scrape this series
            series = self._scrape_series_folder(
                folder_url=folder_url,
                folder_name=folder_name,
                category=category,
                language=language,
                server_name=server_name,
                folder_modified=folder_modified,
                folder_modified_ts=folder_modified_ts
            )

            if series:
                series_list.append(series)

        print()  # New line after progress

        return series_list

    def _scrape_series_folder(self, folder_url, folder_name, category, language, server_name,
                             folder_modified, folder_modified_ts):
        """Scrape a series folder to find seasons and episodes"""

        try:
            entries = self.get_directory_entries(folder_url)

            # Check if this has season folders (Season 1, Season 2, etc.)
            season_folders = []
            standalone_videos = []

            for entry in entries:
                if entry['is_directory']:
                    season_folders.append(entry)
                elif self._is_video_file(entry['name']):
                    standalone_videos.append(entry)

            # Parse series name
            series_info = self._parse_series_name(folder_name)
            series_id = hashlib.md5(folder_url.encode()).hexdigest()[:12]

            # Determine series structure
            if season_folders:
                # Has season folders - scrape each season
                seasons = self._scrape_seasons(
                    season_folders,
                    folder_url,
                    category,
                    language,
                    server_name,
                    series_info
                )
            elif standalone_videos:
                # Direct videos in series folder - single season
                seasons = [self._create_single_season(
                    standalone_videos,
                    folder_url,
                    series_info,
                    category,
                    language,
                    server_name
                )]
            else:
                # No videos found
                return None

            # Get series poster
            poster = self._find_poster(entries, folder_url) or series_info.get('poster', '')

            # Count total episodes
            total_episodes = sum(len(season.get('episodes', [])) for season in seasons)

            # Create series object
            series = {
                'id': f"series_{series_id}",
                'title': series_info['title'],
                'originalTitle': folder_name,
                'year': series_info.get('year', ''),
                'rating': '',
                'quality': series_info.get('quality', 'HD'),
                'poster': poster,
                'backdrop': '',
                'description': series_info.get('description', ''),
                'genres': series_info.get('genres', ['Drama']),
                'cast': [],
                'director': '',
                'language': language,
                'seasons': seasons,
                'subtitles': [],
                'source': 'BDIX',
                'serverName': server_name,
                'category': category,
                'folderUrl': folder_url,
                'lastModified': folder_modified,
                'lastModifiedTimestamp': folder_modified_ts,
                'folderModified': folder_modified,
                'folderModifiedTimestamp': folder_modified_ts,
                'addedDate': int(time.time() * 1000),
                'isFavorite': False,
                'totalEpisodes': total_episodes,
                'status': 'Completed'
            }

            return series

        except Exception as e:
            log(f"    [ERROR] Series folder: {e}")
            return None

    def _scrape_seasons(self, season_folders, series_url, category, language, server_name, series_info):
        """Scrape all season folders"""
        seasons = []

        # Sort season folders by season number
        season_folders.sort(key=lambda x: self._extract_season_number(x['name']))

        if ENABLE_PARALLEL_SEASONS and len(season_folders) > 2:
            # Parallel season processing
            seasons = self._process_seasons_parallel(
                season_folders, series_url, category, language, server_name, series_info
            )
        else:
            # Sequential season processing
            for season_folder in season_folders:
                season_number = self._extract_season_number(season_folder['name'])
                if season_number == 0:
                    continue

                season_url = season_folder['url']

                # Get episodes in this season
                entries = self.get_directory_entries(season_url)

                # Filter videos
                episode_entries = [e for e in entries if not e['is_directory'] and self._is_video_file(e['name'])]

                if not episode_entries:
                    continue

                # Create episodes
                episodes = []
                for ep_entry in episode_entries:
                    episode = self._create_episode(
                        ep_entry,
                        season_url,
                        season_number,
                        category,
                        language,
                        server_name
                    )
                    if episode:
                        episodes.append(episode)

                # Sort episodes by episode number
                episodes.sort(key=lambda x: x.get('episodeNumber', 0))

                # Get season poster
                season_entries = self.get_directory_entries(season_url)
                season_poster = self._find_poster(season_entries, season_url)

                # Create season
                season = {
                    'seasonNumber': season_number,
                    'title': f"Season {season_number}",
                    'description': '',
                    'poster': season_poster or '',
                    'year': series_info.get('year', ''),
                    'episodeCount': len(episodes),
                    'episodes': episodes,
                    'folderUrl': season_url
                }

                seasons.append(season)

        return seasons

    def _process_seasons_parallel(self, season_folders, series_url, category, language, server_name, series_info):
        """Process season folders in parallel"""
        seasons = []

        with ThreadPoolExecutor(max_workers=MAX_WORKERS_SEASONS) as executor:
            future_to_season = {}

            for season_folder in season_folders:
                season_number = self._extract_season_number(season_folder['name'])
                if season_number == 0:
                    continue

                future = executor.submit(
                    self._process_single_season,
                    season_folder,
                    series_url,
                    season_number,
                    category,
                    language,
                    server_name,
                    series_info
                )
                future_to_season[future] = season_number

            # Collect results
            for future in as_completed(future_to_season):
                try:
                    season = future.result()
                    if season:
                        seasons.append(season)
                except Exception as e:
                    log(f"      [ERROR] Season {future_to_season[future]}: {e}")

        # Sort seasons by season number
        seasons.sort(key=lambda x: x.get('seasonNumber', 0))

        return seasons

    def _process_single_season(self, season_folder, series_url, season_number, category, language, server_name, series_info):
        """Process a single season folder (for parallel execution)"""
        season_url = season_folder['url']

        # Get episodes in this season
        entries = self.get_directory_entries(season_url)

        # Filter videos
        episode_entries = [e for e in entries if not e['is_directory'] and self._is_video_file(e['name'])]

        if not episode_entries:
            return None

        # Create episodes
        episodes = []
        for ep_entry in episode_entries:
            episode = self._create_episode(
                ep_entry,
                season_url,
                season_number,
                category,
                language,
                server_name
            )
            if episode:
                episodes.append(episode)

        # Sort episodes by episode number
        episodes.sort(key=lambda x: x.get('episodeNumber', 0))

        # Get season poster
        season_entries = self.get_directory_entries(season_url)
        season_poster = self._find_poster(season_entries, season_url)

        # Create season
        season = {
            'seasonNumber': season_number,
            'title': f"Season {season_number}",
            'description': '',
            'poster': season_poster or '',
            'year': series_info.get('year', ''),
            'episodeCount': len(episodes),
            'episodes': episodes,
            'folderUrl': season_url
        }

        return season

    def _create_single_season(self, video_entries, series_url, series_info, category, language, server_name):
        """Create a single season from standalone videos"""
        episodes = []

        for video_entry in video_entries:
            episode = self._create_episode(
                video_entry,
                series_url,
                1,  # Single season
                category,
                language,
                server_name
            )
            if episode:
                episodes.append(episode)

        # Sort episodes by name (should extract episode number)
        episodes.sort(key=lambda x: x.get('episodeNumber', 0))

        season = {
            'seasonNumber': 1,
            'title': 'Season 1',
            'description': series_info.get('description', ''),
            'poster': '',
            'year': series_info.get('year', ''),
            'episodeCount': len(episodes),
            'episodes': episodes,
            'folderUrl': series_url
        }

        return season

    def _create_episode(self, video_entry, parent_url, season_number, category, language, server_name):
        """Create an episode from a video file"""
        try:
            file_name = video_entry['name']
            file_url = video_entry['url']

            # Parse episode name
            ep_info = self._parse_episode_name(file_name)
            episode_number = ep_info.get('episodeNumber', 0)

            # Parse quality
            quality = self._extract_quality(file_name)

            episode_id = hashlib.md5(file_url.encode()).hexdigest()[:12]

            episode = {
                'id': f"ep_{episode_id}",
                'episodeNumber': episode_number,
                'title': ep_info.get('title', ''),
                'description': '',
                'duration': '',
                'quality': quality,
                'poster': '',
                'streamUrls': [{
                    'url': file_url,
                    'quality': quality,
                    'server': server_name,
                    'fileName': file_name,
                    'isWorking': True
                }],
                'subtitles': [],
                'airDate': '',
                'folderUrl': parent_url,
                'lastModified': video_entry.get('last_modified', ''),
                'watchProgress': 0.0,
                'lastWatched': 0
            }

            return episode

        except Exception as e:
            return None

    def get_directory_entries(self, url):
        """Fetch and parse directory listing"""
        entries = []

        try:
            response = self.session.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()

            soup = BeautifulSoup(response.text, 'html.parser')

            # Try pre tag first
            pre = soup.find('pre')
            if pre:
                entries = self._parse_pre_listing(pre, url)

            # Fallback to table
            if not entries:
                table = soup.find('table')
                if table:
                    entries = self._parse_table_listing(table, url)

            # Generic fallback
            if not entries:
                entries = self._parse_generic_listing(soup, url)

        except Exception as e:
            pass

        return entries

    def _parse_pre_listing(self, pre, base_url):
        """Parse pre-tag directory listing"""
        entries = []

        # Get all text content
        text = pre.get_text()
        lines = text.split('\n')

        for link in pre.find_all('a', href=True):
            href = link.get('href', '')
            name = unquote(link.text.strip())

            if href in ['../', '../', '/', '?'] or name in ['..', '../', 'Parent Directory']:
                continue

            full_url = urljoin(base_url, href)
            is_directory = href.endswith('/')

            # Extract modification date from the line containing this link
            mod_date, mod_timestamp = self._extract_date_from_text(text, name)

            entries.append({
                'name': name,
                'url': full_url,
                'is_directory': is_directory,
                'last_modified': mod_date,
                'last_modified_timestamp': mod_timestamp
            })

        return entries

    def _parse_table_listing(self, table, base_url):
        """Parse table directory listing"""
        entries = []

        try:
            rows = table.find_all('tr')[1:]  # Skip header row

            for row in rows:
                cells = row.find_all(['td', 'th'])
                if len(cells) < 2:
                    continue

                # Try to find link in cells
                link = None
                for cell in cells:
                    a = cell.find('a', href=True)
                    if a:
                        link = a
                        break

                if not link:
                    continue

                href = link.get('href', '')
                name = unquote(link.text.strip())

                if href in ['../', '../', '/', '?'] or name in ['..', '../', 'Parent Directory']:
                    continue

                full_url = urljoin(base_url, href)
                is_directory = href.endswith('/')

                # Extract date from cells
                mod_date, mod_timestamp = self._extract_date_from_cells(cells, name)

                entries.append({
                    'name': name,
                    'url': full_url,
                    'is_directory': is_directory,
                    'last_modified': mod_date,
                    'last_modified_timestamp': mod_timestamp
                })

        except Exception as e:
            pass

        return entries

    def _parse_generic_listing(self, soup, base_url):
        """Parse generic directory listing (any links)"""
        entries = []

        try:
            for link in soup.find_all('a', href=True):
                href = link.get('href', '')
                name = unquote(link.text.strip())

                if href in ['../', '../', '/', '?'] or name in ['..', '../', 'Parent Directory']:
                    continue

                full_url = urljoin(base_url, href)
                is_directory = href.endswith('/')

                entries.append({
                    'name': name,
                    'url': full_url,
                    'is_directory': is_directory,
                    'last_modified': '',
                    'last_modified_timestamp': 0
                })

        except Exception as e:
            pass

        return entries

    def _extract_date_from_text(self, text, filename):
        """Extract modification date from pre-tag text"""
        lines = text.split('\n')

        # Look for the line containing the filename
        for line in lines:
            if filename in line:
                # Try to extract date from this line
                mod_date, mod_ts = self._parse_date_from_text(line)
                if mod_ts > 0:
                    return mod_date, mod_ts

        return '', 0

    def _extract_date_from_cells(self, cells, filename):
        """Extract modification date from table cells"""
        mod_date = ''
        mod_timestamp = 0

        try:
            # Common patterns: date is in 2nd or 3rd cell
            for cell in cells[1:4]:
                cell_text = cell.get_text().strip()
                mod_date, mod_timestamp = self._parse_date_from_text(cell_text)
                if mod_timestamp > 0:
                    break
        except:
            pass

        return mod_date, mod_timestamp

    def _parse_date_from_text(self, text):
        """Parse date from text (supports multiple formats)"""
        date_formats = [
            '%Y-%m-%d %H:%M',           # 2024-01-15 14:30
            '%Y-%m-%d %H:%M:%S',       # 2024-01-15 14:30:45
            '%d-%b-%Y %H:%M',          # 15-Jan-2024 14:30
            '%d-%b-%Y %H:%M:%S',       # 15-Jan-2024 14:30:45
            '%b %d %H:%M',             # Jan 15 14:30 (assumes current year)
            '%d/%m/%Y %H:%M',          # 15/01/2024 14:30
            '%d/%m/%Y %H:%M:%S',       # 15/01/2024 14:30:45
            '%d.%m.%Y %H:%M',          # 15.01.2024 14:30
            '%d.%m.%Y %H:%M:%S',       # 15.01.2024 14:30:45
        ]

        for fmt in date_formats:
            try:
                parsed_date = datetime.strptime(text, fmt)
                return text, int(parsed_date.timestamp())
            except ValueError:
                continue

        # Try to extract date with regex (Apache format: 15-Jan-2024 14:30)
        apache_pattern = r'(\d{2}-\w{3}-\d{4}\s+\d{2}:\d{2})'
        match = re.search(apache_pattern, text)
        if match:
            try:
                parsed_date = datetime.strptime(match.group(1), '%d-%b-%Y %H:%M')
                return match.group(1), int(parsed_date.timestamp())
            except:
                pass

        return '', 0

    def _is_video_file(self, filename):
        """Check if file is a video based on extension"""
        return any(filename.lower().endswith(ext) for ext in VIDEO_EXTENSIONS)

    def _find_poster(self, entries, base_url):
        """Find poster image in entries"""
        for entry in entries:
            if entry['is_directory']:
                continue

            filename = entry['name'].lower()
            if any(filename == poster.lower() for poster in POSTER_FILENAMES):
                return entry['url']

            # Also check by extension
            if any(filename.endswith(ext) for ext in IMAGE_EXTENSIONS):
                # Prefer common poster filenames
                if any(p in filename for p in ['poster', 'cover', 'folder', 'thumb']):
                    return entry['url']

        return ''

    def _parse_series_name(self, folder_name):
        """Parse series name from folder name"""
        # Remove common prefixes
        name = folder_name

        # Remove year patterns (2024, 2023, etc.)
        year_match = re.search(r'\(?\[?(\d{4})\)?\]?', name)
        year = year_match.group(1) if year_match else ''

        # Remove quality patterns (1080p, 720p, 4K, etc.)
        quality_match = re.search(r'\(?\[?(\d{3,4}[pP]|4K|WebRip|BluRay|DVDRip)\)?\]?', name)
        quality = quality_match.group(1) if quality_match else 'HD'

        # Clean up name
        name = re.sub(r'\(?\[?\d{4}\)?\]?', '', name)  # Remove year
        name = re.sub(r'\(?\[?\d{3,4}[pP]\)?\]?', '', name)  # Remove 1080p etc
        name = re.sub(r'\(?\[?4K\)?\]?', '', name)  # Remove 4K
        name = re.sub(r'\(?\[?(WebRip|BluRay|DVDRip)\)?\]?', '', name)  # Remove source
        name = re.sub(r'[\[\]\(\)\{\}]', ' ', name)  # Remove brackets
        name = re.sub(r'\s+', ' ', name).strip()  # Normalize spaces

        # Extract title
        title = name
        if '(' in title and ')' in title:
            # Keep content inside parentheses as it might be language info
            pass

        return {
            'title': title,
            'year': year,
            'quality': quality,
            'description': '',
            'genres': ['Drama']
        }

    def _parse_episode_name(self, filename):
        """Parse episode name from filename"""
        # Remove extension
        name = filename.rsplit('.', 1)[0]

        episode_number = 0
        title = ''

        # Try various patterns for episode number
        patterns = [
            r'[sS](\d{1,2})[eE](\d{1,2})',  # S01E01
            r'[Ee](\d{1,2})',               # E01, E12
            r'Episode\s*(\d{1,2})',         # Episode 1
            r'Ep\s*(\d{1,2})',              # Ep 1
            r'^(\d{1,2})\s*-',              # 01 - Title
            r'-(\d{1,2})\.',                # Title-01.mkv
        ]

        for pattern in patterns:
            match = re.search(pattern, name)
            if match:
                # Get the last number (for S01E01 pattern, get the episode number)
                episode_number = int(match.groups()[-1])
                break

        # If no pattern found, try to extract from start of filename
        if episode_number == 0:
            start_match = re.match(r'^(\d{1,2})', name)
            if start_match:
                episode_number = int(start_match.group(1))

        # Extract title (remove episode number patterns)
        title = name
        title = re.sub(r'[sS]\d{1,2}[eE]\d{1,2}', '', title)  # Remove S01E01
        title = re.sub(r'[Ee]pisode\s*\d{1,2}', '', title, flags=re.IGNORECASE)  # Remove Episode X
        title = re.sub(r'[Ee]p\s*\d{1,2}', '', title, flags=re.IGNORECASE)  # Remove Ep X
        title = re.sub(r'^\d{1,2}\s*-\s*', '', title)  # Remove 01 - from start
        title = re.sub(r'[\[\]\(\)\{\}]', ' ', title)  # Remove brackets
        title = re.sub(r'\s+', ' ', title).strip()  # Normalize spaces

        return {
            'episodeNumber': episode_number,
            'title': title
        }

    def _extract_season_number(self, folder_name):
        """Extract season number from folder name"""
        patterns = [
            r'[sS]eason\s*(\d{1,2})',      # Season 1, Season 01
            r'[sS](\d{1,2})',               # S1, S01
            r'Season\s*(\d{1,2})',          # Season 1
        ]

        for pattern in patterns:
            match = re.search(pattern, folder_name)
            if match:
                return int(match.group(1))

        # Default to 1 if no season number found
        return 1

    def _extract_quality(self, filename):
        """Extract video quality from filename"""
        filename_lower = filename.lower()

        if '4k' in filename_lower or '2160p' in filename_lower:
            return '4K'
        elif '1080p' in filename_lower:
            return '1080p'
        elif '720p' in filename_lower:
            return '720p'
        elif '480p' in filename_lower:
            return '480p'
        elif 'webrip' in filename_lower:
            return 'WebRip'
        elif 'bluray' in filename_lower:
            return 'BluRay'
        else:
            return 'HD'


# ============ PUBLIC FUNCTIONS ============

def scrape_all_series_parallel(max_series_per_server=200):
    """Scrape all configured series servers using parallel processing"""
    scraper = BdixSeriesScraperParallel()
    return scraper.scrape_all_servers(max_series_per_server)

def scrape_single_server_parallel(base_url, category, language, server_name, max_series=200, has_index_folders=False):
    """Scrape a single series server using parallel processing"""
    scraper = BdixSeriesScraperParallel()
    return scraper.scrape_server(base_url, category, language, server_name, max_series, has_index_folders)

def search_series_parallel(query, max_results=50):
    """Search series by title using parallel scraping"""
    all_series = scrape_all_series_parallel(max_series_per_server=max_results)
    query_lower = query.lower()

    # Filter by query
    filtered = [
        s for s in all_series
        if query_lower in s['title'].lower() or query_lower in s.get('originalTitle', '').lower()
    ]

    return filtered[:max_results]


# For direct Python execution
if __name__ == "__main__":
    print("BDIX Series Scraper - PARALLEL VERSION")
    print("=" * 50)
    print(f"Server Workers: {MAX_WORKERS_SERVERS if ENABLE_PARALLEL_SERVERS else 1}")
    print(f"Series Workers: {MAX_WORKERS_SERIES if ENABLE_PARALLEL_SERIES else 1}")
    print(f"Season Workers: {MAX_WORKERS_SEASONS if ENABLE_PARALLEL_SEASONS else 1}")
    print()

    # Scrape all series
    start_time = time.time()
    series_list = scrape_all_series_parallel(max_series_per_server=50)
    elapsed = time.time() - start_time

    print(f"\nFound {len(series_list)} series in {elapsed:.1f} seconds:")
    for series in series_list[:10]:
        print(f"  • {series['title']} ({series['year']}) - {series['totalEpisodes']} episodes in {len(series['seasons'])} seasons")

    # Save to JSON
    output = {
        'count': len(series_list),
        'scrape_time_seconds': round(elapsed, 2),
        'parallel_config': {
            'server_workers': MAX_WORKERS_SERVERS if ENABLE_PARALLEL_SERVERS else 1,
            'series_workers': MAX_WORKERS_SERIES if ENABLE_PARALLEL_SERIES else 1,
            'season_workers': MAX_WORKERS_SEASONS if ENABLE_PARALLEL_SEASONS else 1
        },
        'series': series_list
    }

    # Use current directory for cross-platform compatibility
    output_file = os.path.join(os.getcwd(), 'scraped_series_parallel.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Saved to: {output_file}")
    print(f"⚡ Speed: {len(series_list)/elapsed:.1f} series/second")
