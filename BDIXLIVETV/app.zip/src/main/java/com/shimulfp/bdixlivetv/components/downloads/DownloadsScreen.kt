package com.shimulfp.bdixlivetv.components.downloads

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.shimulfp.bdixlivetv.manager.DownloadManager
import com.shimulfp.bdixlivetv.models.MovieDownload
import com.shimulfp.bdixlivetv.models.DownloadStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Downloads Screen - Shows all movie downloads with TV-friendly navigation
 * Allows users to view, pause, resume, cancel, and delete downloads
 */
@Composable
fun DownloadsScreen(
    onBack: () -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val downloadManager = remember { DownloadManager.getInstance(context) }
    val downloads by downloadManager.downloadsState.collectAsState()
    val scope = rememberCoroutineScope()

    // Auto-refresh downloads every 5 seconds
    LaunchedEffect(Unit) {
        while(true) {
            delay(5000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0A))
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Text(
                    "Downloads",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Stats
                val downloadingCount = downloads.count { it.status == DownloadStatus.DOWNLOADING }
                val completedCount = downloads.count { it.status == DownloadStatus.COMPLETED }

                if (downloadingCount > 0) {
                    InfoBadge(
                        text = "$downloadingCount downloading",
                        color = Color.Blue
                    )
                }

                if (completedCount > 0) {
                    InfoBadge(
                        text = "$completedCount completed",
                        color = Color.Green
                    )
                }

                // Clear All button
                if (downloads.isNotEmpty()) {
                    Button(
                        onClick = {
                            scope.launch {
                                downloadManager.clearDownloadHistory()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Clear", fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Downloads list
        if (downloads.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.Download,
                        null,
                        tint = Color.Gray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "No downloads yet",
                        color = Color.Gray,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Download movies to watch offline",
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(downloads) { download ->
                    DownloadItem(
                        download = download,
                        downloadManager = downloadManager,
                        scope = scope,
                        onClick = {
                            // Navigate to movie detail or play when completed
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DownloadItem(
    download: MovieDownload,
    downloadManager: DownloadManager,
    scope: CoroutineScope,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = when {
                    download.status == DownloadStatus.COMPLETED -> 2.dp
                    download.status == DownloadStatus.FAILED -> 2.dp
                    else -> 1.dp
                },
                color = when {
                    download.status == DownloadStatus.COMPLETED -> Color.Green
                    download.status == DownloadStatus.FAILED -> Color.Red
                    download.status == DownloadStatus.PAUSED -> Color.Yellow
                    else -> Color(0xFF333333)
                },
                shape = RoundedCornerShape(12.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail/Poster
            Box(
                modifier = Modifier
                    .size(width = 80.dp, height = 120.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1A1A1A))
                    .padding(8.dp)
                    .contentAlignment = Alignment.Center
            ) {
                download.poster?.let {
                    // In a real implementation, load poster image with Coil
                    Icon(
                        Icons.Filled.Movie,
                        null,
                        tint = Color.Gray,
                        modifier = Modifier.size(32.dp)
                    )
                } ?: run {
                    Icon(
                        Icons.Filled.Movie,
                        null,
                        tint = Color.Gray,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            // Status icon overlay
            when (download.status) {
                DownloadStatus.COMPLETED -> {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(4.dp)
                            .size(24.dp)
                            .background(Color.Green, CircleShape)
                            .zIndex(2f)
                    ) {
                        Icon(
                            Icons.Filled.Check,
                            "Completed",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                DownloadStatus.DOWNLOADING -> {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .size(20.dp),
                        color = Color.Red,
                        strokeWidth = 2.dp
                    )
                }
                DownloadStatus.PAUSED -> {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(4.dp)
                            .size(24.dp)
                            .background(Color.Yellow, CircleShape)
                            .zIndex(2f)
                    ) {
                        Icon(
                            Icons.Filled.Pause,
                            "Paused",
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                DownloadStatus.FAILED -> {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(4.dp)
                            .size(24.dp)
                            .background(Color.Red, CircleShape)
                            .zIndex(2f)
                    ) {
                        Icon(
                            Icons.Filled.Close,
                            "Failed",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                else -> {}
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Movie info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    download.title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Progress or status info
                when (download.status) {
                    DownloadStatus.DOWNLOADING -> {
                        // Progress bar
                        LinearProgressIndicator(
                            progress = download.progress / 100f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp),
                            color = Color.Red,
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${download.progress}%",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Text(
                                "${download.getFileSizeText()} / ${download.getTotalSizeText()}",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }
                    DownloadStatus.PAUSED -> {
                        Text(
                            "Paused",
                            color = Color.Yellow,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            "${download.getFileSizeText()} / ${download.getTotalSizeText()}",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                    DownloadStatus.COMPLETED -> {
                        Text(
                            "Ready to watch",
                            color = Color.Green,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            download.getFileSizeText(),
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                    DownloadStatus.FAILED -> {
                        Text(
                            "Failed: ${download.error ?: "Unknown error"}",
                            color = Color.Red,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            download.getProgressText(),
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                    else -> {
                        Text(
                            download.getProgressText(),
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                        Text(
                            download.getQualityLabel(),
                            color = Color(0xFF00BFFF),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Action buttons row
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Play button (for completed downloads)
                    if (download.status == DownloadStatus.COMPLETED && download.filePath != null) {
                        Button(
                            onClick = { /* Play downloaded file */ },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Filled.PlayArrow, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Play", fontSize = 12.sp)
                        }
                    }

                    // Pause/Resume button
                    if (download.status == DownloadStatus.DOWNLOADING) {
                        Button(
                            onClick = {
                                scope.launch {
                                    downloadManager.pauseDownload(download.id)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Yellow),
                            contentColor = Color.Black,
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Filled.Pause, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Pause", fontSize = 12.sp)
                        }
                    }

                    // Cancel button
                    if (download.canCancel()) {
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    downloadManager.cancelDownload(download.id)
                                }
                            },
                            border = BorderStroke(1.dp, Color.Red),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Filled.Close, null, tint = Color.Red, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cancel", fontSize = 12.sp, color = Color.Red)
                        }
                    }

                    // Delete button
                    if (download.filePath != null) {
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    downloadManager.deleteDownload(download.id)
                                }
                            },
                            border = BorderStroke(1.dp, Color.Gray),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Filled.Delete, null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Delete", fontSize = 12.sp)
                        }
                    }

                    // Retry button for failed downloads
                    if (download.status == DownloadStatus.FAILED) {
                        Button(
                            onClick = {
                                scope.launch {
                                    // Need movie and streamUrl data - store in download or fetch from database
                                    // For now, just show the button
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Retry", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InfoBadge(text: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .border(1.dp, color, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
