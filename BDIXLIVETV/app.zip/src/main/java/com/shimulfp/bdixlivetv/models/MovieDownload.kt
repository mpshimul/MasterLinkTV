package com.shimulfp.bdixlivetv.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Represents a movie download with its current state
 */
data class MovieDownload(
    val id: String,                    // Unique download ID (movieId + quality)
    val movieId: String,                // Movie ID from Movie data
    val title: String,                  // Movie title
    val url: String,                    // Stream URL to download
    val quality: Int = 0,                // Quality index
    val poster: String? = null,         // Movie poster URL
    val fileName: String,                // Output filename
    val progress: Int = 0,              // Download progress (0-100)
    val status: DownloadStatus = DownloadStatus.PENDING,  // Current status
    val fileSize: Long = 0,              // Total file size in bytes
    val downloadedSize: Long = 0,        // Downloaded bytes
    val filePath: String? = null,        // Local file path when completed
    val createdAt: Long = System.currentTimeMillis(),  // Download start time
    val completedAt: Long? = null,       // Completion time
    val error: String? = null,          // Error message if failed
) : Parcelable {

    companion object {
        fun fromMovie(
            movie: Movie,
            streamUrl: StreamUrl,
            qualityIndex: Int
        ): MovieDownload {
            val safeQuality = if (streamUrl.quality.isNotEmpty()) streamUrl.quality else "HD"
            val fileExtension = getFileExtension(streamUrl.url)
            val fileName = sanitizeFileName("${movie.title}_$safeQuality.$fileExtension")

            return MovieDownload(
                id = "${movie.id}_${qualityIndex}",
                movieId = movie.id,
                title = movie.title,
                url = streamUrl.url,
                quality = qualityIndex,
                poster = movie.poster,
                fileName = fileName
            )
        }

        private fun getFileExtension(url: String): String {
            return when {
                url.contains(".mp4", ignoreCase = true) -> "mp4"
                url.contains(".mkv", ignoreCase = true) -> "mkv"
                url.contains(".webm", ignoreCase = true) -> "webm"
                url.contains(".avi", ignoreCase = true) -> "avi"
                else -> "mp4" // Default
            }
        }

        private fun sanitizeFileName(name: String): String {
            // Remove invalid characters
            var sanitized = name
            sanitized = sanitized.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            sanitized = sanitized.replace("\\s+".toRegex(), "_")
            return sanitized.trim()
        }
    }

    /**
     * Returns true if download can be resumed
     */
    fun canResume(): Boolean {
        return status == DownloadStatus.PAUSED && filePath == null
    }

    /**
     * Returns true if download can be cancelled
     */
    fun canCancel(): Boolean {
        return status in listOf(
            DownloadStatus.PENDING,
            DownloadStatus.DOWNLOADING,
            DownloadStatus.PAUSED
        )
    }

    /**
     * Returns formatted progress text
     */
    fun getProgressText(): String {
        return when (status) {
            DownloadStatus.COMPLETED -> "Completed"
            DownloadStatus.FAILED -> "Failed: ${error ?: "Unknown error"}"
            DownloadStatus.PAUSED -> "Paused"
            DownloadStatus.DOWNLOADING -> "$progress%"
            DownloadStatus.PENDING -> "Waiting..."
            DownloadStatus.CANCELLED -> "Cancelled"
        }
    }

    /**
     * Returns formatted file size text
     */
    fun getFileSizeText(): String {
        return formatFileSize(downloadedSize)
    }

    /**
     * Returns formatted total file size text
     */
    fun getTotalSizeText(): String {
        return formatFileSize(fileSize)
    }

    /**
     * Returns the quality label based on the index
     */
    fun getQualityLabel(): String {
        // Common quality labels based on quality index
        val labels = listOf("HD", "1080p", "720p", "480p", "360p")
        return if (quality >= 0 && quality < labels.size) labels[quality] else "HD"
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return "%.1f KB".format(kb)
        val mb = kb / 1024.0
        if (mb < 1024) return "%.1f MB".format(mb)
        val gb = mb / 1024.0
        return "%.2f GB".format(gb)
    }
}

/**
 * Download status enum
 */
enum class DownloadStatus {
    PENDING,        // Waiting to start
    DOWNLOADING,    // Currently downloading
    PAUSED,         // Paused by user
    COMPLETED,      // Successfully downloaded
    FAILED,         // Download failed
    CANCELLED       // Cancelled by user
}
