package com.shimulfp.bdixlivetv

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.*
import android.util.Log
import android.util.Rational
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.shimulfp.bdixlivetv.data.MovieRepository
import com.shimulfp.bdixlivetv.models.StreamUrl
import kotlinx.coroutines.launch
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.concurrent.TimeUnit
import kotlin.math.abs

@UnstableApi
class MoviePlayerActivity : ComponentActivity() {

    private lateinit var playerManager: PlayerManager

    private lateinit var exoPlayerView: PlayerView
    private lateinit var vlcVideoLayout: VLCVideoLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var titleText: TextView
    private lateinit var qualityText: TextView
    private lateinit var timeText: TextView
    private lateinit var durationText: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var controlsContainer: View
    private lateinit var serverButton: Button
    private lateinit var audioButton: Button
    private lateinit var backButton: ImageButton
    private lateinit var playPauseButton: ImageButton
    private lateinit var rewindButton: ImageButton
    private lateinit var forwardButton: ImageButton
    private lateinit var bufferingText: TextView
    private lateinit var codecInfoText: TextView
    private lateinit var pipButton: ImageButton
    private lateinit var playerModeText: TextView
    private lateinit var vlcSwitchButton: Button
    private lateinit var exoSwitchButton: Button
    private lateinit var seekTestButton: Button

    // Gesture controls
    private lateinit var gestureOverlay: View
    private lateinit var brightnessSideIndicator: RelativeLayout
    private lateinit var volumeSideIndicator: RelativeLayout
    private lateinit var brightnessIcon: ImageView
    private lateinit var volumeIcon: ImageView
    private lateinit var brightnessText: TextView
    private lateinit var volumeText: TextView
    private lateinit var brightnessBarFill: View
    private lateinit var volumeBarFill: View

    private lateinit var audioManager: AudioManager
    private var maxVolume = 0
    private var currentBrightness = 0.5f
    private val windowManager = WindowManager.LayoutParams()

    private var movieUrl: String = ""
    private var movieTitle: String = ""
    private var movieId: String = ""
    private var movieQuality: String = ""
    private var streamUrls: List<StreamUrl> = emptyList()
    private var currentServerIndex: Int = 0

    private var controlsVisible = true
    private var resumePosition: Long = 0
    private var isUserSeeking = false
    private var isBuffering = false
    private var isSeekable = true

    // Gesture variables
    private var startX = 0f
    private var startY = 0f
    private var isBrightnessControl = false
    private var isVolumeControl = false
    private var gestureStartTime = 0L
    private var lastBrightnessUpdate = 0L
    private var lastVolumeUpdate = 0L
    private val updateCooldown = 16L // ~60fps for smooth updates

    private val hideHandler = Handler(Looper.getMainLooper())
    private val updateHandler = Handler(Looper.getMainLooper())

    private var isPipSupported = false
    private var isInPipMode = false
    private var shouldRestorePlayback = true

    private val hideControlsRunnable = Runnable { hideControls() }
    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            updateHandler.postDelayed(this, 1000)
        }
    }

    companion object {
        private const val TAG = "MoviePlayer"
        private const val HIDE_DELAY = 3000L
        private const val SEEK_INCREMENT = 10000L
        private const val GESTURE_THRESHOLD = 50f // pixels
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setRealFullscreen()
        setContentView(R.layout.activity_movie_player)

        isPipSupported = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        } else false

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        initViews()
        extractIntentData()
        setupListeners()
        initPlayerManager()
        lifecycleScope.launch {
            loadResumePosition()
        }
        loadMovie()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && isPipSupported) {
            buildPipParams()?.let { params ->
                setPictureInPictureParams(params)
            }
        }
    }

    private fun setRealFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Initialize brightness
        val layoutParams = window.attributes
        val screenBrightness = layoutParams.screenBrightness

        if (screenBrightness > 0) {
            currentBrightness = screenBrightness
        } else {
            currentBrightness = 0.5f
        }
    }

    private fun initViews() {
        exoPlayerView = findViewById(R.id.movie_player_view)
        vlcVideoLayout = findViewById(R.id.movie_vlc_view)
        progressBar = findViewById(R.id.movie_progress_bar)
        errorText = findViewById(R.id.movie_error_text)
        titleText = findViewById(R.id.movie_title_text)
        qualityText = findViewById(R.id.movie_quality_text)
        timeText = findViewById(R.id.movie_time_text)
        durationText = findViewById(R.id.movie_duration_text)
        seekBar = findViewById(R.id.movie_seek_bar)
        controlsContainer = findViewById(R.id.movie_controls_container)
        serverButton = findViewById(R.id.movie_server_button)
        audioButton = findViewById(R.id.movie_audio_button)
        backButton = findViewById(R.id.movie_back_button)
        playPauseButton = findViewById(R.id.movie_play_pause_button)
        rewindButton = findViewById(R.id.movie_rewind_button)
        forwardButton = findViewById(R.id.movie_forward_button)
        bufferingText = findViewById(R.id.movie_buffering_text)
        codecInfoText = findViewById(R.id.movie_codec_info)
        pipButton = findViewById(R.id.movie_pip_button)
        playerModeText = findViewById(R.id.movie_player_mode_text)
        vlcSwitchButton = findViewById(R.id.movie_vlc_switch_button)
        exoSwitchButton = findViewById(R.id.movie_exo_switch_button)
        seekTestButton = findViewById(R.id.movie_seek_test_button)

        // Gesture controls
        gestureOverlay = findViewById(R.id.gesture_overlay)
        brightnessSideIndicator = findViewById(R.id.brightness_side_indicator)
        volumeSideIndicator = findViewById(R.id.volume_side_indicator)
        brightnessIcon = findViewById(R.id.brightness_icon)
        volumeIcon = findViewById(R.id.volume_icon)
        brightnessText = findViewById(R.id.brightness_text)
        volumeText = findViewById(R.id.volume_text)
        brightnessBarFill = findViewById(R.id.brightness_bar_fill)
        volumeBarFill = findViewById(R.id.volume_bar_fill)

        codecInfoText.visibility = View.GONE
        bufferingText.visibility = View.GONE
        errorText.visibility = View.GONE
        exoSwitchButton.visibility = View.GONE
        brightnessSideIndicator.visibility = View.GONE
        volumeSideIndicator.visibility = View.GONE

        if (!isPipSupported) {
            pipButton.visibility = View.GONE
        }

        // Make buttons clickable
        playPauseButton.isFocusable = true
        playPauseButton.isClickable = true
        playPauseButton.requestFocus()

        // Initialize UI with actual values
        updateBrightnessUI()
        updateVolumeUI()
    }

    private fun extractIntentData() {
        movieId = intent.getStringExtra("MOVIE_ID") ?: ""
        movieTitle = intent.getStringExtra("MOVIE_TITLE") ?: "Movie"
        movieUrl = intent.getStringExtra("MOVIE_URL") ?: ""
        movieQuality = intent.getStringExtra("MOVIE_QUALITY") ?: "HD"

        @Suppress("DEPRECATION")
        streamUrls = intent.getParcelableArrayListExtra("STREAM_URLS") ?: emptyList()

        titleText.text = movieTitle
        qualityText.text = movieQuality

        if (streamUrls.isNotEmpty()) {
            currentServerIndex = streamUrls.indexOfFirst { it.url == movieUrl }.takeIf { it >= 0 } ?: 0
            serverButton.text = "Server ${currentServerIndex + 1}/${streamUrls.size}"
            serverButton.visibility = if (streamUrls.size > 1) View.VISIBLE else View.GONE
        } else {
            serverButton.visibility = View.GONE
        }
    }

    private fun setupListeners() {
        backButton.setOnClickListener {
            lifecycleScope.launch {
                saveCurrentProgress()
            }
            finish()
        }

        playPauseButton.setOnClickListener {
            togglePlayPause()
            // Don't hide controls immediately after button press
            showControls()
            scheduleHideControls()
        }

        rewindButton.setOnClickListener {
            safeSeekBy(-SEEK_INCREMENT)
            showControls()
            scheduleHideControls()
        }

        forwardButton.setOnClickListener {
            safeSeekBy(SEEK_INCREMENT)
            showControls()
            scheduleHideControls()
        }

        serverButton.setOnClickListener {
            showServerDialog()
            showControls()
            scheduleHideControls()
        }

        audioButton.setOnClickListener {
            showAudioTrackDialog()
            showControls()
            scheduleHideControls()
        }

        pipButton.setOnClickListener {
            if (isPipSupported) {
                enterPictureInPicture()
            }
            showControls()
            scheduleHideControls()
        }

        vlcSwitchButton.setOnClickListener {
            showVLCSwitchDialog()
            showControls()
            scheduleHideControls()
        }

        exoSwitchButton.setOnClickListener {
            showExoSwitchDialog()
            showControls()
            scheduleHideControls()
        }

        seekTestButton.setOnClickListener {
            testSeekFunctionality()
            showControls()
            scheduleHideControls()
        }

        // Single tap on video toggles controls
        exoPlayerView.setOnClickListener {
            if (!isBrightnessControl && !isVolumeControl) {
                toggleControls()
            }
        }

        vlcVideoLayout.setOnClickListener {
            if (!isBrightnessControl && !isVolumeControl) {
                toggleControls()
            }
        }

        // Setup gesture overlay
        gestureOverlay.setOnTouchListener { v, event ->
            handleGesture(event)
            true // Always consume touch events
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val duration = playerManager.getDuration()
                    if (duration > 0) {
                        val position = (duration * progress) / 100
                        timeText.text = formatTime(position)
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = true
                cancelHideControls()
                showControls()
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = false
                val duration = playerManager.getDuration()
                if (duration > 0 && isSeekable) {
                    val position = (duration * (seekBar?.progress ?: 0)) / 100
                    playerManager.seekTo(position)
                }
                scheduleHideControls()
            }
        })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun handleGesture(event: MotionEvent): Boolean {
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                gestureStartTime = System.currentTimeMillis()
                isBrightnessControl = false
                isVolumeControl = false
                cancelHideControls()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val currentTime = System.currentTimeMillis()
                val dx = event.x - startX
                val dy = event.y - startY

                // Only start gesture after a small movement
                if (!isBrightnessControl && !isVolumeControl) {
                    if (abs(dy) > GESTURE_THRESHOLD && abs(dy) > abs(dx)) {
                        // Determine if left or right side
                        if (startX < screenWidth * 0.3) {
                            isBrightnessControl = true
                            showBrightnessSideIndicator()
                        } else if (startX > screenWidth * 0.7) {
                            isVolumeControl = true
                            showVolumeSideIndicator()
                        }
                    }
                }

                // Handle brightness adjustment
                if (isBrightnessControl && currentTime - lastBrightnessUpdate > updateCooldown) {
                    // Natural: Swipe UP = brighter, DOWN = darker
                    adjustBrightness(-dy) // Negative because screen coordinates: up = negative
                    lastBrightnessUpdate = currentTime
                }

                // Handle volume adjustment
                else if (isVolumeControl && currentTime - lastVolumeUpdate > updateCooldown) {
                    // Natural: Swipe UP = louder, DOWN = quieter
                    adjustVolume(-dy) // Negative because screen coordinates: up = negative
                    lastVolumeUpdate = currentTime
                }

                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isBrightnessControl || isVolumeControl) {
                    hideSideIndicators()
                    scheduleHideControls()
                    isBrightnessControl = false
                    isVolumeControl = false
                    return true
                } else {
                    // Check for single tap
                    val elapsedTime = System.currentTimeMillis() - gestureStartTime
                    val movedDistance = abs(event.x - startX) + abs(event.y - startY)

                    if (elapsedTime < 300 && movedDistance < 20) {
                        // Single tap - toggle controls
                        toggleControls()
                    }
                }
                return true
            }
        }
        return true
    }

    private fun adjustBrightness(deltaY: Float) {
        // Convert pixel movement to brightness change (0-1)
        val screenHeight = resources.displayMetrics.heightPixels
        // Full screen swipe = 50% brightness change
        val change = deltaY / (screenHeight * 2)

        currentBrightness = (currentBrightness + change).coerceIn(0.01f, 1.0f)

        try {
            val layoutParams = window.attributes
            layoutParams.screenBrightness = currentBrightness
            window.attributes = layoutParams

            updateBrightnessUI()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to adjust brightness", e)
        }
    }

    private fun adjustVolume(deltaY: Float) {
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val screenHeight = resources.displayMetrics.heightPixels
        // Full screen swipe = 5 volume steps
        val steps = maxVolume / 5
        val change = (-deltaY / (screenHeight / steps)).toInt()

        val newVolume = (currentVolume + change).coerceIn(0, maxVolume)
        if (newVolume != currentVolume) {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                newVolume,
                AudioManager.FLAG_SHOW_UI
            )
            updateVolumeUI()
        }
    }

    private fun showBrightnessSideIndicator() {
        brightnessSideIndicator.visibility = View.VISIBLE
        updateBrightnessUI()
    }

    private fun showVolumeSideIndicator() {
        volumeSideIndicator.visibility = View.VISIBLE
        updateVolumeUI()
    }

    private fun updateBrightnessUI() {
        val percentage = (currentBrightness * 100).toInt()
        brightnessText.text = "$percentage%"

        // Update icon
        val iconRes = when {
            percentage > 66 -> R.drawable.ic_brightness_high
            percentage > 33 -> R.drawable.ic_brightness_medium
            else -> R.drawable.ic_brightness_low
        }
        brightnessIcon.setImageResource(iconRes)

        // Update bar - assuming parent is 100dp
        val barHeight = (percentage / 100f) * resources.getDimension(R.dimen.gesture_bar_max_height)
        val layoutParams = brightnessBarFill.layoutParams
        layoutParams.height = barHeight.toInt()
        brightnessBarFill.layoutParams = layoutParams
    }

    private fun updateVolumeUI() {
        val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val percentage = (currentVolume * 100 / maxVolume)
        volumeText.text = "$percentage%"

        // Update icon
        val iconRes = when {
            currentVolume == 0 -> R.drawable.ic_volume_off
            currentVolume < maxVolume / 3 -> R.drawable.ic_volume_down
            else -> R.drawable.ic_volume_up
        }
        volumeIcon.setImageResource(iconRes)

        // Update bar
        val barHeight = (percentage / 100f) * resources.getDimension(R.dimen.gesture_bar_max_height)
        val layoutParams = volumeBarFill.layoutParams
        layoutParams.height = barHeight.toInt()
        volumeBarFill.layoutParams = layoutParams
    }

    private fun hideSideIndicators() {
        brightnessSideIndicator.visibility = View.GONE
        volumeSideIndicator.visibility = View.GONE
    }

    // ... [Rest of the PlayerManager initialization remains the same - from line 478 to 718] ...

    private fun initPlayerManager() {
        playerManager = PlayerManager(
            context = this,
            exoPlayerView = exoPlayerView,
            vlcVideoLayout = vlcVideoLayout,
            listener = object : PlayerManager.PlayerListener {
                override fun onPlayerReady() {
                    progressBar.visibility = View.GONE
                    errorText.visibility = View.GONE
                    updateDuration()
                    updatePlayPauseButton()

                    val playerType = playerManager.getPlayerType()
                    playerModeText.text = when (playerType) {
                        PlayerManager.PlayerType.EXOPLAYER -> "ExoPlayer"
                        PlayerManager.PlayerType.VLC -> "VLC"
                    }
                    playerModeText.setTextColor(
                        if (playerType == PlayerManager.PlayerType.VLC)
                            0xFFFF9800.toInt() else 0xFF4CAF50.toInt()
                    )

                    if (playerType == PlayerManager.PlayerType.VLC) {
                        vlcSwitchButton.visibility = View.GONE
                        exoSwitchButton.visibility = View.VISIBLE
                    } else {
                        vlcSwitchButton.visibility = View.VISIBLE
                        exoSwitchButton.visibility = View.GONE
                    }

                    if (resumePosition > 0 && playerManager.isSeekable() && shouldRestorePlayback) {
                        playerManager.seekTo(resumePosition)
                        resumePosition = 0
                        Toast.makeText(
                            this@MoviePlayerActivity,
                            "Resuming playback",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    showCodecInfo()
                    scheduleHideControls()
                }

                override fun onPlayerError(error: String, isFatal: Boolean) {
                    if (isFatal) {
                        progressBar.visibility = View.GONE
                        errorText.visibility = View.VISIBLE
                        errorText.text = error

                        if (streamUrls.size > 1) {
                            errorText.append("\n\nTrying next server...")
                            Handler(Looper.getMainLooper()).postDelayed({
                                tryNextServer()
                            }, 2000)
                        }
                    } else {
                        Toast.makeText(this@MoviePlayerActivity, error, Toast.LENGTH_LONG).show()

                        val playerType = playerManager.getPlayerType()
                        if (playerType == PlayerManager.PlayerType.VLC) {
                            vlcSwitchButton.visibility = View.GONE
                            exoSwitchButton.visibility = View.VISIBLE
                        } else {
                            vlcSwitchButton.visibility = View.VISIBLE
                            exoSwitchButton.visibility = View.GONE
                        }
                    }
                }

                override fun onBuffering(isBuffering: Boolean, percentage: Int) {
                    this@MoviePlayerActivity.isBuffering = isBuffering
                    progressBar.visibility = if (isBuffering) View.VISIBLE else View.GONE
                    bufferingText.visibility = if (isBuffering) View.VISIBLE else View.GONE

                    if (isBuffering && percentage > 0) {
                        bufferingText.text = "Buffering... $percentage%"
                    } else if (isBuffering) {
                        bufferingText.text = "Buffering..."
                    }

                    if (!isBuffering) {
                        scheduleHideControls()
                    }
                }

                override fun onPlaybackStateChanged(isPlaying: Boolean) {
                    updatePlayPauseButton()
                    if (isPlaying) {
                        scheduleHideControls()
                    } else {
                        cancelHideControls()
                        showControls()
                    }
                }

                override fun onDurationChanged(duration: Long) {
                    updateDuration()
                }

                override fun onPositionChanged(position: Long) {
                    // Handled in updateProgress()
                }

                override fun onSeekableChanged(isSeekable: Boolean) {
                    this@MoviePlayerActivity.isSeekable = isSeekable
                    seekBar.isEnabled = isSeekable

                    val duration = playerManager.getDuration()
                    val playerType = playerManager.getPlayerType()

                    Log.d(TAG, "Seekable changed: $isSeekable, Duration: $duration, Player: $playerType")

                    if (!isSeekable && duration > 0) {
                        Log.w(TAG, "⚠️ Video has duration but marked as unseekable!")

                        if (playerType == PlayerManager.PlayerType.EXOPLAYER) {
                            Handler(Looper.getMainLooper()).postDelayed({
                                showNonSeekableDialog()
                            }, 2000)
                        }
                    } else if (!isSeekable && duration <= 0) {
                        Toast.makeText(
                            this@MoviePlayerActivity,
                            "Live stream - seeking unavailable",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onTracksChanged() {
                    val audioTracks = playerManager.getAvailableAudioTracks()
                    audioButton.visibility = if (audioTracks.size > 1) View.VISIBLE else View.GONE
                    if (audioTracks.size > 1) {
                        audioButton.text = "Audio (${audioTracks.size})"
                    }
                }

                override fun onProblematicCodecDetected(codecInfo: String) {
                    Log.w(TAG, "Problematic codec detected: $codecInfo")

                    Handler(Looper.getMainLooper()).postDelayed({
                        if (playerManager.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
                            showAC3DetectedDialog(codecInfo)
                        }
                    }, 1000)
                }
            }
        )
    }

    // ... [Rest of the methods remain the same - from loadMovie() to the end] ...

    private fun loadMovie(url: String = movieUrl) {
        if (url.isEmpty()) {
            errorText.visibility = View.VISIBLE
            errorText.text = "No video URL provided"
            return
        }

        errorText.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        shouldRestorePlayback = true

        val urlLower = url.lowercase()
        val forceVLC = (urlLower.contains(".mkv") &&
                (urlLower.contains("ac3") ||
                        urlLower.contains("dts") ||
                        urlLower.contains("dd5.1") ||
                        urlLower.contains("dd+") ||
                        urlLower.contains("eac3"))) ||
                urlLower.contains(".avi") ||
                urlLower.contains(".hevc") ||
                urlLower.contains("h265") ||
                urlLower.contains("x265")

        if (forceVLC) {
            Log.d(TAG, "⚠️ Auto-forcing VLC for: $url")
            Toast.makeText(
                this,
                "Using VLC player for better format support",
                Toast.LENGTH_LONG
            ).show()
        }

        playerManager.load(url, autoPlay = true, forceVLC = forceVLC)
    }

    private fun showCodecInfo() {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
            playerManager.getExoPlayer()?.let { p ->
                val videoFormat = p.videoFormat
                val audioFormat = p.audioFormat

                if (videoFormat != null) {
                    val codecInfo = buildString {
                        append("Video: ${videoFormat.sampleMimeType ?: "Unknown"}")
                        append(" ${videoFormat.width}x${videoFormat.height}")
                        if (videoFormat.frameRate > 0) append(" ${videoFormat.frameRate.toInt()}fps")

                        if (audioFormat != null) {
                            append("\nAudio: ${audioFormat.sampleMimeType ?: "Unknown"}")
                            if (audioFormat.channelCount > 0) append(" ${audioFormat.channelCount}ch")
                            if (audioFormat.sampleRate > 0) append(" ${audioFormat.sampleRate}Hz")
                        }
                    }

                    codecInfoText.text = codecInfo
                    codecInfoText.visibility = View.VISIBLE

                    Handler(Looper.getMainLooper()).postDelayed({
                        codecInfoText.visibility = View.GONE
                    }, 5000)
                }
            }
        } else {
            codecInfoText.text = "VLC Player - All codecs supported"
            codecInfoText.visibility = View.VISIBLE
            Handler(Looper.getMainLooper()).postDelayed({
                codecInfoText.visibility = View.GONE
            }, 3000)
        }
    }

    private fun showAudioTrackDialog() {
        val audioTracks = playerManager.getAvailableAudioTracks()

        if (audioTracks.isEmpty()) {
            Toast.makeText(this, "No audio tracks available", Toast.LENGTH_SHORT).show()
            return
        }

        if (audioTracks.size == 1) {
            Toast.makeText(this, "Only one audio track available", Toast.LENGTH_SHORT).show()
            return
        }

        val trackLabels = audioTracks.map { track ->
            buildString {
                append(track.label)
                if (track.language.isNotEmpty() && track.language != "und" && track.language != "Unknown") {
                    append(" [${track.language}]")
                }
                if (track.channels > 0 && track.channels != 2) {
                    append(" - ${track.channels}ch")
                }
                if (track.isSelected) {
                    append(" ✓")
                }
            }
        }.toTypedArray()

        val selectedIndex = audioTracks.indexOfFirst { it.isSelected }.takeIf { it >= 0 } ?: 0

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Select Audio Track")
            .setSingleChoiceItems(trackLabels, selectedIndex) { dialog, which ->
                if (which != selectedIndex && which < audioTracks.size) {
                    val success = playerManager.setAudioTrack(audioTracks[which].trackIndex)
                    if (success) {
                        Toast.makeText(this, "Audio track switched", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Failed to switch audio track", Toast.LENGTH_SHORT).show()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun showServerDialog() {
        if (streamUrls.isEmpty() || streamUrls.size == 1) {
            Toast.makeText(this, "No alternative servers available", Toast.LENGTH_SHORT).show()
            return
        }

        val serverNames = streamUrls.mapIndexed { index, url ->
            buildString {
                append("Server ${index + 1}")
                if (url.server.isNotEmpty()) append(" - ${url.server}")
                if (url.quality.isNotEmpty()) append(" (${url.quality})")
                if (index == currentServerIndex) append(" ✓")
            }
        }.toTypedArray()

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Select Server")
            .setSingleChoiceItems(serverNames, currentServerIndex) { dialog, which ->
                if (which != currentServerIndex && which < streamUrls.size) {
                    switchToServer(which)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun switchToServer(serverIndex: Int) {
        if (serverIndex < 0 || serverIndex >= streamUrls.size) return

        val currentPos = playerManager.getCurrentPosition()
        currentServerIndex = serverIndex

        serverButton.text = "Server ${serverIndex + 1}/${streamUrls.size}"
        qualityText.text = streamUrls[serverIndex].quality

        movieUrl = streamUrls[serverIndex].url
        loadMovie(movieUrl)

        resumePosition = currentPos
        shouldRestorePlayback = true
    }

    private fun tryNextServer() {
        if (streamUrls.size <= 1) return

        val nextIndex = (currentServerIndex + 1) % streamUrls.size
        Toast.makeText(this, "Trying server ${nextIndex + 1}...", Toast.LENGTH_SHORT).show()
        switchToServer(nextIndex)
    }

    private fun testSeekFunctionality() {
        val duration = playerManager.getDuration()
        val currentPosition = playerManager.getCurrentPosition()
        val isSeekable = playerManager.isSeekable()
        val playerType = playerManager.getPlayerType()

        val message = """
            Seek Test Results:
            Player: $playerType
            Duration: ${formatTime(duration)}
            Current: ${formatTime(currentPosition)}
            Seekable: $isSeekable
            Live Stream: ${duration <= 0}
        """.trimIndent()

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Seek Test")
            .setMessage(message)
            .setPositiveButton("Test Seek Forward") { _, _ ->
                playerManager.seekBy(30000) // 30 seconds forward
            }
            .setNegativeButton("Test Seek Back") { _, _ ->
                playerManager.seekBy(-15000) // 15 seconds back
            }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun showAC3DetectedDialog(codecInfo: String) {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.VLC) {
            return
        }

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("⚠️ AC3/DTS Audio Detected")
            .setMessage("$codecInfo\n\n" +
                    "This audio format may not play correctly with ExoPlayer.\n\n" +
                    "Switch to VLC player for full compatibility?")
            .setPositiveButton("Switch to VLC") { _, _ ->
                val currentPos = playerManager.getCurrentPosition()
                playerManager.switchToVLC(movieUrl, currentPos, autoSwitch = false)
            }
            .setNegativeButton("Continue with ExoPlayer") { _, _ ->
                Toast.makeText(
                    this,
                    "Audio may not play. Use 'Use VLC' button if needed.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .setCancelable(true)
            .show()
    }

    private fun showNonSeekableDialog() {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.VLC) {
            return
        }

        if (!isSeekable) {
            android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("⚠️ Seeking Not Available")
                .setMessage("This video doesn't support seeking with ExoPlayer.\n\n" +
                        "VLC player may provide better seeking support.\n\n" +
                        "Switch to VLC?")
                .setPositiveButton("Switch to VLC") { _, _ ->
                    val currentPos = playerManager.getCurrentPosition()
                    playerManager.switchToVLC(movieUrl, currentPos, autoSwitch = false)
                }
                .setNegativeButton("Continue", null)
                .setCancelable(true)
                .show()
        }
    }

    private fun showVLCSwitchDialog() {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.VLC) {
            Toast.makeText(this, "Already using VLC player", Toast.LENGTH_SHORT).show()
            return
        }

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Switch to VLC Player")
            .setMessage("VLC player supports:\n\n" +
                    "✓ AC3/DTS audio\n" +
                    "✓ Better seeking\n" +
                    "✓ All video formats\n" +
                    "✓ HEVC/H.265\n" +
                    "✓ Better network handling\n\n" +
                    "Current position will be preserved.")
            .setPositiveButton("Switch to VLC") { _, _ ->
                val currentPos = playerManager.getCurrentPosition()
                playerManager.switchToVLC(movieUrl, currentPos, autoSwitch = false)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExoSwitchDialog() {
        if (playerManager.getPlayerType() == PlayerManager.PlayerType.EXOPLAYER) {
            Toast.makeText(this, "Already using ExoPlayer", Toast.LENGTH_SHORT).show()
            return
        }

        android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Switch to ExoPlayer")
            .setMessage("ExoPlayer supports:\n\n" +
                    "✓ Better battery efficiency\n" +
                    "✓ Smoother UI integration\n" +
                    "✓ Native Android features\n" +
                    "✓ Better HLS/DASH streaming\n\n" +
                    "Current position will be preserved.")
            .setPositiveButton("Switch to ExoPlayer") { _, _ ->
                val currentPos = playerManager.getCurrentPosition()
                playerManager.switchToExoPlayer(movieUrl, currentPos)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun togglePlayPause() {
        if (playerManager.isPlaying()) {
            playerManager.pause()
        } else {
            playerManager.play()
        }
        updatePlayPauseButton()
    }

    private fun updatePlayPauseButton() {
        playPauseButton.setImageResource(
            if (playerManager.isPlaying()) android.R.drawable.ic_media_pause
            else android.R.drawable.ic_media_play
        )
    }

    private fun safeSeekBy(incrementMs: Long) {
        if (!playerManager.isSeekable()) {
            Toast.makeText(this, "Seeking not supported", Toast.LENGTH_SHORT).show()
            return
        }

        playerManager.seekBy(incrementMs)
        showControls()
        scheduleHideControls()
    }

    private fun toggleControls() {
        if (isInPipMode) return

        if (controlsVisible) {
            hideControls()
        } else {
            showControls()
            scheduleHideControls()
        }
    }

    private fun showControls() {
        if (isInPipMode) return
        controlsContainer.visibility = View.VISIBLE
        controlsVisible = true
        cancelHideControls()
    }

    private fun hideControls() {
        if (playerManager.isPlaying() && !isBuffering && !isInPipMode) {
            controlsContainer.visibility = View.GONE
            controlsVisible = false
        }
    }

    private fun scheduleHideControls() {
        if (isInPipMode) return
        cancelHideControls()
        if (playerManager.isPlaying() && !isBuffering) {
            hideHandler.postDelayed(hideControlsRunnable, HIDE_DELAY)
        }
    }

    private fun cancelHideControls() {
        hideHandler.removeCallbacks(hideControlsRunnable)
    }

    private fun updateProgress() {
        if (!isUserSeeking) {
            val duration = playerManager.getDuration()
            if (duration > 0) {
                val position = playerManager.getCurrentPosition()
                val progress = ((position * 100) / duration).toInt()

                seekBar.progress = progress
                timeText.text = formatTime(position)

                val bufferedPosition = playerManager.getBufferedPosition()
                val bufferedProgress = ((bufferedPosition * 100) / duration).toInt()
                seekBar.secondaryProgress = bufferedProgress
            }
        }
    }

    private fun updateDuration() {
        val duration = playerManager.getDuration()
        if (duration > 0) {
            durationText.text = formatTime(duration)
            seekBar.max = 100
        }
    }

    private fun formatTime(milliseconds: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(milliseconds)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(milliseconds) % 60

        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    private suspend fun loadResumePosition() {
        if (movieId.isNotEmpty()) {
            val repository = MovieRepository.getInstance(this)
            val record = repository.getWatchProgress(movieId)

            if (record != null && record.progress < 0.95f) {
                resumePosition = record.position
                Log.d(TAG, "Resume position loaded: $resumePosition")
            }
        }
    }

    private suspend fun saveCurrentProgress() {
        if (movieId.isEmpty()) return

        val duration = playerManager.getDuration()
        if (duration > 0) {
            val position = playerManager.getCurrentPosition()
            val progress = position.toFloat() / duration.toFloat()

            val repository = MovieRepository.getInstance(this)
            repository.saveWatchProgress(movieId, progress, position)

            Log.d(TAG, "Progress saved: ${progress * 100}% at $position ms")
        }
    }

    @Suppress("DEPRECATION")
    private fun buildPipParams(): PictureInPictureParams? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val aspectRatio = Rational(16, 9)
            PictureInPictureParams.Builder()
                .setAspectRatio(aspectRatio)
                .build()
        } else null
    }

    private fun enterPictureInPicture() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isPipSupported) {
            buildPipParams()?.let { params ->
                enterPictureInPictureMode(params)
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode)
        isInPipMode = isInPictureInPictureMode

        if (isInPictureInPictureMode) {
            hideControls()
        } else {
            showControls()
            scheduleHideControls()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isInPipMode) {
            return super.onKeyDown(keyCode, event)
        }

        showControls()
        scheduleHideControls()

        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_BUTTON_A -> {
                togglePlayPause()
                true
            }

            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_BUTTON_L1 -> {
                safeSeekBy(-SEEK_INCREMENT)
                true
            }

            KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_BUTTON_R1 -> {
                safeSeekBy(SEEK_INCREMENT)
                true
            }

            KeyEvent.KEYCODE_DPAD_UP -> {
                // Don't use for volume - let TV remote volume buttons handle it
                false
            }

            KeyEvent.KEYCODE_DPAD_DOWN -> {
                // Don't use for volume - let TV remote volume buttons handle it
                false
            }

            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                togglePlayPause()
                true
            }

            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                playerManager.play()
                true
            }

            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                playerManager.pause()
                true
            }

            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                safeSeekBy(-SEEK_INCREMENT)
                true
            }

            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                safeSeekBy(SEEK_INCREMENT)
                true
            }

            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_BUTTON_B -> {
                lifecycleScope.launch {
                    saveCurrentProgress()
                }
                finish()
                true
            }

            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_BUTTON_START -> {
                toggleControls()
                true
            }

            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onStart() {
        super.onStart()
        updateHandler.post(updateProgressRunnable)
    }

    override fun onResume() {
        super.onResume()
        setRealFullscreen()
        if (!isInPipMode) {
            playerManager.play()
        }
    }

    override fun onPause() {
        super.onPause()
        if (!isInPipMode) {
            playerManager.pause()
        }
        lifecycleScope.launch {
            saveCurrentProgress()
        }
    }

    override fun onStop() {
        super.onStop()
        updateHandler.removeCallbacks(updateProgressRunnable)
        cancelHideControls()
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleScope.launch {
            saveCurrentProgress()
        }

        hideHandler.removeCallbacksAndMessages(null)
        updateHandler.removeCallbacksAndMessages(null)

        playerManager.release()
    }
}